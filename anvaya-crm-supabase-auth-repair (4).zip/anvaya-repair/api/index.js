import { createApp } from '../backend/src/app.js';
import { initDb } from '../backend/src/db.js';
import serverless from 'serverless-http';

const app = createApp();
const handler = serverless(app);
let initialization;

export default async function apiHandler(req, res) {
  if (!initialization) {
    initialization = initDb().catch(err => {
      initialization = null; // allow a later warm invocation to recover
      throw err;
    });
  }
  try {
    await initialization;
  } catch (err) {
    console.error('[db] serverless initialization failed', {
      code: err.code || 'DB_INIT_FAILED',
      message: err.message
    });
    return res.status(503).json({
      ok: false,
      error: 'Anvaya CRM is temporarily unable to connect to its database.',
      code: 'DATABASE_UNAVAILABLE'
    });
  }
  return handler(req, res);
}
