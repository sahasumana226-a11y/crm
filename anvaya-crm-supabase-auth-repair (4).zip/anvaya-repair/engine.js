/* ============================================================================
   Anvaya CRM — local data engine
   ---------------------------------------------------------------------------
   This replaces the HTTP API with an in-browser implementation of the same
   routes. It exists so the whole product can ship as one .html file that runs
   with no server. Records live in localStorage on this device.

   What is the same: every screen, every route, the workflows, the copilot,
   the permission-shaped UI.
   What is different: no multi-user accounts, no server, and no PostgreSQL row
   level security — in this build the browser holds all the data, so treat it
   as a demo workspace, not a place for real customer information.
   ========================================================================== */
(function () {
  'use strict';

  const KEY = 'anvaya-single-v1';
  const uid = (p) => p + '-' + Math.random().toString(36).slice(2, 9);
  const now = () => new Date().toISOString();
  const day = 86400000;
  const iso = (offsetDays) => new Date(Date.now() + offsetDays * day).toISOString();
  const dateOnly = (offsetDays) => iso(offsetDays).slice(0, 10);

  /* ------------------------------------------------------------------ seed -- */
  function seed() {
    const stages = [
      { id: 'st-1', name: 'Discovery', position: 0, probability: 10, is_won: false, is_lost: false },
      { id: 'st-2', name: 'Site survey', position: 1, probability: 25, is_won: false, is_lost: false },
      { id: 'st-3', name: 'Proposal sent', position: 2, probability: 45, is_won: false, is_lost: false },
      { id: 'st-4', name: 'Negotiation', position: 3, probability: 70, is_won: false, is_lost: false },
      { id: 'st-5', name: 'Closed won', position: 4, probability: 100, is_won: true, is_lost: false },
      { id: 'st-6', name: 'Closed lost', position: 5, probability: 0, is_won: false, is_lost: true }
    ];

    const members = [
      { id: 'mb-1', full_name: 'Snehasis Saha', email: 'sneha@brightline.in', role_name: 'Owner', role_key: 'owner', status: 'active', title: 'Managing Director', permissions: ['*'], joined_at: iso(-240) },
      { id: 'mb-2', full_name: 'Rohit Kapoor', email: 'rohit@brightline.in', role_name: 'Manager', role_key: 'manager', status: 'active', title: 'Sales Manager', permissions: ['deal.write', 'lead.write', 'report.read'], joined_at: iso(-230) },
      { id: 'mb-3', full_name: 'Aarti Sharma', email: 'aarti@brightline.in', role_name: 'Sales representative', role_key: 'sales', status: 'active', title: 'Account Executive', permissions: ['deal.write', 'lead.write'], joined_at: iso(-200) },
      { id: 'mb-4', full_name: 'Prakash Kamath', email: 'prakash@brightline.in', role_name: 'Support agent', role_key: 'support', status: 'active', title: 'Service Lead', permissions: ['ticket.write'], joined_at: iso(-150) },
      { id: 'mb-5', full_name: 'Sana Pillai', email: 'sana@brightline.in', role_name: 'Finance', role_key: 'finance', status: 'active', title: 'Finance', permissions: ['invoice.write'], joined_at: iso(-120) }
    ];

    const companies = [
      { id: 'co-1', name: 'Meridian Retail Group', industry: 'Retail', city: 'Bengaluru', owner_id: 'mb-1', health_score: 78, size_band: '500-1000', annual_revenue: 48000000, created_at: iso(-210) },
      { id: 'co-2', name: 'Sunrise Hospitals', industry: 'Healthcare', city: 'Hyderabad', owner_id: 'mb-1', health_score: 64, size_band: '1000+', annual_revenue: 96000000, created_at: iso(-190) },
      { id: 'co-3', name: 'Deccan Precision Works', industry: 'Manufacturing', city: 'Pune', owner_id: 'mb-2', health_score: 71, size_band: '250-500', annual_revenue: 32000000, created_at: iso(-120) },
      { id: 'co-4', name: 'Fresco Foods', industry: 'Cold chain', city: 'Nashik', owner_id: 'mb-3', health_score: 52, size_band: '100-250', annual_revenue: 14000000, created_at: iso(-90) },
      { id: 'co-5', name: 'Palm Grove Resorts', industry: 'Hospitality', city: 'Coorg', owner_id: 'mb-3', health_score: 88, size_band: '50-100', annual_revenue: 8000000, created_at: iso(-80) },
      { id: 'co-6', name: 'Skyline Cargo', industry: 'Logistics', city: 'Mumbai', owner_id: 'mb-1', health_score: 59, size_band: '500-1000', annual_revenue: 55000000, created_at: iso(-60) }
    ];

    const contacts = [
      { id: 'ct-1', company_id: 'co-1', first_name: 'Rahul', last_name: 'Menon', title: 'Head of Projects', email: 'rahul.menon@meridianretail.in', phone: '+91 98450 21188', city: 'Bengaluru', owner_id: 'mb-1', health_score: 78, tags: ['decision-maker', 'key account'], consent: { email: true, whatsapp: true, calls: true }, created_at: iso(-1) },
      { id: 'ct-2', company_id: 'co-2', first_name: 'Kavita', last_name: 'Rao', title: 'Chief Information Officer', email: 'kavita.rao@sunrisehospitals.in', phone: '+91 90080 33214', city: 'Hyderabad', owner_id: 'mb-1', health_score: 64, tags: ['decision-maker'], consent: { email: true, whatsapp: false, calls: true }, created_at: iso(-5) },
      { id: 'ct-3', company_id: 'co-3', first_name: 'Arjun', last_name: 'Deshmukh', title: 'Plant Head', email: 'a.deshmukh@deccanprecision.in', phone: '+91 98220 67315', city: 'Pune', owner_id: 'mb-2', health_score: 71, tags: ['decision-maker'], consent: { email: true, whatsapp: false, calls: true }, created_at: iso(-9) },
      { id: 'ct-4', company_id: 'co-4', first_name: 'Neha', last_name: 'Kulkarni', title: 'Operations Manager', email: 'neha.k@frescofoods.in', phone: '+91 97650 40931', city: 'Nashik', owner_id: 'mb-3', health_score: 52, tags: [], consent: { email: true, whatsapp: false, calls: true }, created_at: iso(-14) },
      { id: 'ct-5', company_id: 'co-5', first_name: 'Anita', last_name: 'Bose', title: 'General Manager', email: 'anita.bose@palmgroveresorts.com', phone: '+91 98860 22317', city: 'Coorg', owner_id: 'mb-3', health_score: 88, tags: ['reference'], consent: { email: true, whatsapp: true, calls: true }, created_at: iso(-21) },
      { id: 'ct-6', company_id: 'co-6', first_name: 'Imran', last_name: 'Shaikh', title: 'Logistics Director', email: 'imran.shaikh@skylinecargo.co.in', phone: '+91 98333 90127', city: 'Mumbai', owner_id: 'mb-1', health_score: 59, tags: [], consent: { email: true, whatsapp: false, calls: true }, created_at: iso(-30) },
      { id: 'ct-7', company_id: 'co-1', first_name: 'Priya', last_name: 'Nair', title: 'Facilities Head', email: 'priya@meridianretail.in', phone: '+91 99001 44720', city: 'Bengaluru', owner_id: 'mb-2', health_score: 66, tags: [], consent: { email: true, whatsapp: false, calls: true }, created_at: iso(-45) },
      { id: 'ct-8', company_id: 'co-2', first_name: 'Meera', last_name: 'Iyer', title: 'Administrative Officer', email: 'meera.iyer@sunrisehospitals.in', phone: '+91 94480 51206', city: 'Chennai', owner_id: 'mb-2', health_score: 61, tags: [], consent: { email: true, whatsapp: false, calls: true }, created_at: iso(-60) }
    ];

    const leads = [
      { id: 'ld-1', name: 'Rahul Menon', company_name: 'Meridian Retail Group', email: 'rahul.menon@meridianretail.in', phone: '+91 98450 21188', source: 'website', status: 'qualified', score: 86, estimated_value: 4280000, owner_id: 'mb-1', created_at: iso(-12), last_contacted_at: iso(-2) },
      { id: 'ld-2', name: 'Priya Nair', company_name: 'Meridian Retail Group', email: 'priya@meridianretail.in', phone: '+91 99001 44720', source: 'referral', status: 'new', score: 72, estimated_value: 1860000, owner_id: 'mb-2', created_at: iso(-6), last_contacted_at: null },
      { id: 'ld-3', name: 'Arjun Deshmukh', company_name: 'Deccan Precision Works', email: 'a.deshmukh@deccanprecision.in', phone: '+91 98220 67315', source: 'exhibition', status: 'proposal', score: 91, estimated_value: 5240000, owner_id: 'mb-2', created_at: iso(-33), last_contacted_at: iso(0) },
      { id: 'ld-4', name: 'Kavita Rao', company_name: 'Sunrise Hospitals', email: 'kavita.rao@sunrisehospitals.in', phone: '+91 90080 33214', source: 'cold_call', status: 'qualified', score: 64, estimated_value: 940000, owner_id: 'mb-1', created_at: iso(-15), last_contacted_at: iso(-9) },
      { id: 'ld-5', name: 'Imran Shaikh', company_name: 'Skyline Cargo', email: 'imran.shaikh@skylinecargo.co.in', phone: '+91 98333 90127', source: 'linkedin', status: 'contacted', score: 78, estimated_value: 8900000, owner_id: 'mb-1', created_at: iso(-11), last_contacted_at: iso(-1) },
      { id: 'ld-6', name: 'Meera Iyer', company_name: 'Sunrise Hospitals', email: 'meera.iyer@sunrisehospitals.in', phone: '+91 94480 51206', source: 'website', status: 'contacted', score: 58, estimated_value: 2760000, owner_id: 'mb-3', created_at: iso(-9), last_contacted_at: iso(-4) },
      { id: 'ld-7', name: 'Neha Kulkarni', company_name: 'Fresco Foods', email: 'neha.k@frescofoods.in', phone: '+91 97650 40931', source: 'outbound', status: 'qualified', score: 81, estimated_value: 1150000, owner_id: 'mb-3', created_at: iso(-24), last_contacted_at: iso(-12) },
      { id: 'ld-8', name: 'Sanjay Patil', company_name: 'Palm Grove Resorts', email: 'sanjay.patil@palmgroveresorts.com', phone: '+91 99700 18842', source: 'referral', status: 'new', score: 45, estimated_value: 620000, owner_id: 'mb-3', created_at: iso(-4), last_contacted_at: null }
    ];

    const deals = [
      { id: 'dl-1', title: '350-camera rollout — Phase 2', company_id: 'co-1', contact_id: 'ct-1', stage_id: 'st-4', value: 4280000, probability: 75, expected_close_date: dateOnly(26), owner_id: 'mb-1', status: 'open', stage_changed_at: iso(-6), created_at: iso(-40) },
      { id: 'dl-2', title: 'Warehouse perimeter upgrade', company_id: 'co-6', contact_id: 'ct-6', stage_id: 'st-3', value: 1860000, probability: 55, expected_close_date: dateOnly(33), owner_id: 'mb-2', status: 'open', stage_changed_at: iso(-19), created_at: iso(-35) },
      { id: 'dl-3', title: 'AMC renewal — 3 sites', company_id: 'co-2', contact_id: 'ct-2', stage_id: 'st-4', value: 940000, probability: 80, expected_close_date: dateOnly(13), owner_id: 'mb-1', status: 'open', stage_changed_at: iso(-11), created_at: iso(-50) },
      { id: 'dl-4', title: 'Plant CCTV + fire alarm', company_id: 'co-3', contact_id: 'ct-3', stage_id: 'st-3', value: 5240000, probability: 60, expected_close_date: dateOnly(40), owner_id: 'mb-2', status: 'open', stage_changed_at: iso(-2), created_at: iso(-28) },
      { id: 'dl-5', title: 'Cold storage monitoring', company_id: 'co-4', contact_id: 'ct-4', stage_id: 'st-4', value: 1150000, probability: 70, expected_close_date: dateOnly(28), owner_id: 'mb-3', status: 'open', stage_changed_at: iso(-9), created_at: iso(-31) },
      { id: 'dl-6', title: 'Cargo terminal — pilot', company_id: 'co-6', contact_id: 'ct-6', stage_id: 'st-3', value: 8900000, probability: 50, expected_close_date: dateOnly(56), owner_id: 'mb-1', status: 'open', stage_changed_at: iso(-1), created_at: iso(-20) },
      { id: 'dl-7', title: 'Lobby & parking coverage', company_id: 'co-5', contact_id: 'ct-5', stage_id: 'st-5', value: 780000, probability: 100, expected_close_date: dateOnly(-15), owner_id: 'mb-3', status: 'won', stage_changed_at: iso(-15), created_at: iso(-45) },
      { id: 'dl-8', title: 'School bus GPS package', company_id: 'co-2', contact_id: 'ct-2', stage_id: 'st-5', value: 340000, probability: 100, expected_close_date: dateOnly(-24), owner_id: 'mb-3', status: 'won', stage_changed_at: iso(-24), created_at: iso(-55) },
      { id: 'dl-9', title: 'Showroom chain refresh', company_id: 'co-1', contact_id: 'ct-7', stage_id: 'st-6', value: 560000, probability: 0, expected_close_date: dateOnly(-35), owner_id: 'mb-3', status: 'lost', lost_reason: 'Incumbent vendor held the AMC', stage_changed_at: iso(-35), created_at: iso(-70) },
      { id: 'dl-10', title: 'Retail chain — 14 outlets', company_id: 'co-1', contact_id: 'ct-7', stage_id: 'st-1', value: 3120000, probability: 20, expected_close_date: dateOnly(74), owner_id: 'mb-2', status: 'open', stage_changed_at: iso(-3), created_at: iso(-9) },
      { id: 'dl-11', title: 'Resort staff quarters — Phase 2', company_id: 'co-5', contact_id: 'ct-5', stage_id: 'st-5', value: 920000, probability: 100, expected_close_date: dateOnly(-78), owner_id: 'mb-3', status: 'won', stage_changed_at: iso(-78), created_at: iso(-110) },
      { id: 'dl-12', title: 'Bank branch surveillance', company_id: 'co-2', contact_id: 'ct-2', stage_id: 'st-5', value: 1480000, probability: 100, expected_close_date: dateOnly(-112), owner_id: 'mb-1', status: 'won', stage_changed_at: iso(-112), created_at: iso(-140) },
      { id: 'dl-13', title: 'Cold store retrofit — 2 sites', company_id: 'co-4', contact_id: 'ct-4', stage_id: 'st-5', value: 640000, probability: 100, expected_close_date: dateOnly(-46), owner_id: 'mb-2', status: 'won', stage_changed_at: iso(-46), created_at: iso(-80) }
    ];

    const activities = [
      { id: 'ac-1', type: 'call', subject: 'Outbound call — 12 min', body: 'Confirmed Whitefield and Indiranagar go live first. Night-shift staff need training.', contact_id: 'ct-1', company_id: 'co-1', deal_id: 'dl-1', owner_id: 'mb-1', occurred_at: iso(-2) },
      { id: 'ac-2', type: 'email', subject: 'Proposal v3 sent', body: 'Revised BOQ with 350 cameras across 14 stores, 3-year AMC bundled.', contact_id: 'ct-1', company_id: 'co-1', deal_id: 'dl-1', owner_id: 'mb-1', occurred_at: iso(-4) },
      { id: 'ac-3', type: 'meeting', subject: 'Quarterly business review', body: 'Reviewed uptime 99.2%, tuned two false-alarm clusters.', contact_id: 'ct-1', company_id: 'co-1', deal_id: 'dl-1', owner_id: 'mb-1', occurred_at: iso(-20) },
      { id: 'ac-4', type: 'note', subject: 'Scope gap flagged', body: 'Site 3 (Kukatpally) has been serviced since June but is not on the AMC agreement.', contact_id: 'ct-2', company_id: 'co-2', deal_id: 'dl-3', owner_id: 'mb-1', occurred_at: iso(-1) },
      { id: 'ac-5', type: 'call', subject: 'Renewal discussion', body: 'Kavita asked for the retention log format before signing.', contact_id: 'ct-2', company_id: 'co-2', deal_id: 'dl-3', owner_id: 'mb-1', occurred_at: iso(-6) },
      { id: 'ac-6', type: 'meeting', subject: 'Technical evaluation walkthrough', body: '42 camera positions walked. IP66 housings quoted for the paint shop.', contact_id: 'ct-3', company_id: 'co-3', deal_id: 'dl-4', owner_id: 'mb-2', occurred_at: iso(-3) },
      { id: 'ac-7', type: 'email', subject: 'Proposal v2 sent', body: 'Added fire alarm panel integration and 5-year support.', contact_id: 'ct-3', company_id: 'co-3', deal_id: 'dl-4', owner_id: 'mb-2', occurred_at: iso(-2) },
      { id: 'ac-8', type: 'call', subject: 'Demo call — 25 min', body: 'Walked through temperature alerting and the ERP integration question.', contact_id: 'ct-4', company_id: 'co-4', deal_id: 'dl-5', owner_id: 'mb-3', occurred_at: iso(-8) },
      { id: 'ac-9', type: 'note', subject: 'Deal health dropped', body: 'Nine days in negotiation, no reply, price pressure from a local installer.', contact_id: 'ct-4', company_id: 'co-4', deal_id: 'dl-5', owner_id: 'mb-3', occurred_at: iso(-7) },
      { id: 'ac-10', type: 'note', subject: 'Reference call agreed', body: 'Anita will speak to two hospitality prospects in November.', contact_id: 'ct-5', company_id: 'co-5', deal_id: 'dl-7', owner_id: 'mb-3', occurred_at: iso(-2) },
      { id: 'ac-11', type: 'meeting', subject: 'Installation handover', body: 'Walkthrough with the resort security team, two positions adjusted.', contact_id: 'ct-5', company_id: 'co-5', deal_id: 'dl-7', owner_id: 'mb-3', occurred_at: iso(-15) },
      { id: 'ac-12', type: 'call', subject: 'Pilot scoping call', body: 'Agreed a single-terminal pilot. Site plan to follow this week.', contact_id: 'ct-6', company_id: 'co-6', deal_id: 'dl-6', owner_id: 'mb-1', occurred_at: iso(-2) },
      { id: 'ac-13', type: 'email', subject: 'Capability deck sent', body: 'Thermal camera and analytics deck forwarded to IT security.', contact_id: 'ct-6', company_id: 'co-6', deal_id: 'dl-6', owner_id: 'mb-1', occurred_at: iso(-6) },
      { id: 'ac-14', type: 'note', subject: 'Inbound enquiry from website', body: 'Asked about multi-site coverage across 14 outlets.', contact_id: 'ct-7', company_id: 'co-1', deal_id: 'dl-10', owner_id: 'mb-2', occurred_at: iso(-9) }
    ];

    const tasks = [
      { id: 'ts-1', title: 'Call Kavita Rao about AMC scope for site 3', priority: 'high', status: 'open', assignee_id: 'mb-1', due_date: dateOnly(-1), related_type: 'contact', related_id: 'ct-2' },
      { id: 'ts-2', title: 'Send revised proposal to Deccan Precision', priority: 'high', status: 'open', assignee_id: 'mb-2', due_date: dateOnly(0), related_type: 'deal', related_id: 'dl-4' },
      { id: 'ts-3', title: 'Site survey — new academic block', priority: 'medium', status: 'open', assignee_id: 'mb-3', due_date: dateOnly(1), related_type: 'deal', related_id: 'dl-4' },
      { id: 'ts-4', title: 'Chase invoice INV-2291 (overdue)', priority: 'high', status: 'open', assignee_id: 'mb-5', due_date: dateOnly(-2), related_type: 'general', related_id: null },
      { id: 'ts-5', title: 'Prepare QBR deck for Meridian Retail', priority: 'medium', status: 'in_progress', assignee_id: 'mb-1', due_date: dateOnly(4), related_type: 'company', related_id: 'co-1' },
      { id: 'ts-6', title: 'Approve 6% discount request — Meridian', priority: 'high', status: 'open', assignee_id: 'mb-1', due_date: dateOnly(0), related_type: 'deal', related_id: 'dl-1' },
      { id: 'ts-7', title: 'Update lead source mapping for imports', priority: 'low', status: 'done', assignee_id: 'mb-1', due_date: dateOnly(-6), completed_at: iso(-5), related_type: 'general', related_id: null }
    ];

    const tickets = [
      { id: 'tk-1', number: 'TKT-1084', subject: 'NVR offline at Whitefield store', description: 'Recorder has been down since 07:10.', contact_id: 'ct-1', company_id: 'co-1', priority: 'critical', status: 'open', category: 'Installation', assignee_id: 'mb-4', sla_due_at: iso(-0.06), created_at: iso(-1) },
      { id: 'tk-2', number: 'TKT-1081', subject: 'Camera 12 flickering at night', description: 'Flickers after 22:00 in the ICU corridor.', contact_id: 'ct-2', company_id: 'co-2', priority: 'high', status: 'in_progress', category: 'Hardware', assignee_id: 'mb-4', sla_due_at: iso(0.3), created_at: iso(-1) },
      { id: 'tk-3', number: 'TKT-1079', subject: 'Add 4 users to mobile app', description: 'New operations staff need access.', contact_id: 'ct-4', company_id: 'co-4', priority: 'medium', status: 'in_progress', category: 'Access', assignee_id: 'mb-4', sla_due_at: iso(1.2), created_at: iso(-2) },
      { id: 'tk-4', number: 'TKT-1076', subject: 'AMC invoice mismatch — Q3', description: 'Invoice does not match the agreed AMC value.', contact_id: 'ct-5', company_id: 'co-5', priority: 'medium', status: 'open', category: 'Billing', assignee_id: 'mb-5', sla_due_at: iso(2), created_at: iso(-2) },
      { id: 'tk-5', number: 'TKT-1072', subject: 'Access card not working — gate 2', description: 'Trial card stopped working.', contact_id: 'ct-3', company_id: 'co-3', priority: 'high', status: 'open', category: 'Access', assignee_id: 'mb-4', sla_due_at: iso(0.1), created_at: iso(-2) },
      { id: 'tk-6', number: 'TKT-1061', subject: 'DVR replacement under warranty', description: 'Replaced the unit, no charge.', contact_id: 'ct-6', company_id: 'co-6', priority: 'high', status: 'resolved', category: 'Hardware', assignee_id: 'mb-4', sla_due_at: iso(-6), resolved_at: iso(-6), csat: 5, created_at: iso(-9) }
    ];

    const products = [
      { id: 'pr-1', sku: 'CAM-IP-4MP', name: '4MP IP dome camera', category: 'Cameras', unit_price: 6400, tax_rate: 18, stock_qty: 120, reorder_point: 30 },
      { id: 'pr-2', sku: 'CAM-PTZ-2MP', name: '2MP PTZ camera, 25x zoom', category: 'Cameras', unit_price: 24500, tax_rate: 18, stock_qty: 18, reorder_point: 6 },
      { id: 'pr-3', sku: 'NVR-32CH', name: '32-channel NVR with 8TB storage', category: 'Recorders', unit_price: 68000, tax_rate: 18, stock_qty: 12, reorder_point: 4 },
      { id: 'pr-4', sku: 'AMC-STD', name: 'Annual maintenance — standard site', category: 'Services', unit_price: 96000, tax_rate: 18, stock_qty: 999, reorder_point: 0 }
    ];

    const quotations = [
      { id: 'qt-1', number: 'QT-2026-0114', company_id: 'co-3', deal_id: 'dl-4', status: 'sent', issue_date: dateOnly(-6), valid_until: dateOnly(24), subtotal: 594000, tax_total: 106920, total: 700920, terms: 'Payment 40% advance, 60% on handover. Validity 30 days.' },
      { id: 'qt-2', number: 'QT-2026-0111', company_id: 'co-5', deal_id: 'dl-7', status: 'accepted', issue_date: dateOnly(-30), valid_until: dateOnly(-1), subtotal: 661017, tax_total: 118983, total: 780000, terms: 'Payment on handover.' }
    ];

    const invoices = [
      { id: 'in-1', number: 'INV-2291', company_id: 'co-5', deal_id: 'dl-7', status: 'partially_paid', issue_date: dateOnly(-32), due_date: dateOnly(-2), subtotal: 661017, tax_total: 118983, total: 780000, amount_paid: 312000 },
      { id: 'in-2', number: 'INV-2288', company_id: 'co-2', deal_id: 'dl-8', status: 'paid', issue_date: dateOnly(-40), due_date: dateOnly(-10), subtotal: 288136, tax_total: 51864, total: 340000, amount_paid: 340000, paid_at: iso(-12) }
    ];

    const projects = [
      { id: 'pj-1', name: 'Meridian Phase 1 — 6 stores', company_id: 'co-1', deal_id: 'dl-7', status: 'active', start_date: dateOnly(-40), end_date: dateOnly(20), budget: 2400000, spent: 1610000, progress: 68, manager_id: 'mb-3' }
    ];

    const workflows = [
      { id: 'wf-1', name: 'New website lead — assign and set a first response task', description: 'Every inbound website lead gets a task within a day.', status: 'active', version: 1, trigger: { event: 'lead.created', entity: 'lead' }, conditions: [{ field: 'source', op: 'eq', value: 'website' }], actions: [{ type: 'create_task', title: 'First response to {{name}}', dueInDays: 1, priority: 'high' }, { type: 'notify', title: 'New website lead' }], run_count: 3, last_run_at: iso(-6) },
      { id: 'wf-2', name: 'Deal won — kick off delivery', description: 'Creates the onboarding task and a handover note.', status: 'active', version: 1, trigger: { event: 'deal.won', entity: 'deal' }, conditions: [], actions: [{ type: 'create_task', title: 'Kick off delivery for {{title}}', dueInDays: 3, priority: 'high' }, { type: 'log_activity', subject: 'Deal won — handover to delivery' }], run_count: 5, last_run_at: iso(-15) }
    ];

    const customFields = [
      { id: 'cf-1', entity: 'deal', key: 'site_count', label: 'Number of sites', type: 'number', required: false, position: 0 },
      { id: 'cf-2', entity: 'deal', key: 'camera_count', label: 'Camera count', type: 'number', required: false, position: 1 },
      { id: 'cf-3', entity: 'contact', key: 'preferred_language', label: 'Preferred language', type: 'select', options: ['English', 'Hindi', 'Kannada'], required: false, position: 0 }
    ];

    return {
      version: 1,
      org: { id: 'org-1', name: 'Brightline Security Solutions', industry: 'Security systems integrator', currency: 'INR', timezone: 'Asia/Kolkata', plan: 'professional' },
      user: { id: 'us-1', full_name: 'Snehasis Saha', email: 'sneha@brightline.in', role_name: 'Owner', role_key: 'owner' },
      subscription: { plan: 'professional', status: 'active', seats: 20, limits: { seats: 20, ai_credits: 2000, emails: 5000 }, usage: { ai_credits: 680, emails: 1240 } },
      members, companies, contacts, leads, deals, activities, tasks, tickets, products,
      quotations, invoices, projects, workflows,
      pipelines: [{ id: 'pl-1', name: 'Enterprise security', is_default: true, stages }],
      workflowRuns: [], workflowSteps: {}, customFields, notifications: [
        { id: 'nt-1', type: 'alert', title: 'SLA breach on TKT-1084', body: 'NVR offline at Meridian Whitefield for over 2 hours.', read_at: null, created_at: iso(-0.1) }
      ],
      audit: [{ id: 'au-1', actor_name: 'Seed', action: 'org.created', entity: 'organisation', created_at: iso(-240) }],
      aiRuns: [], aiActions: []
    };
  }

  /* --------------------------------------------------------------- storage -- */
  let DB = null;
  function load() {
    if (DB) return DB;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { DB = JSON.parse(raw); return DB; }
    } catch (e) { /* private mode or corrupt */ }
    DB = seed();
    save();
    return DB;
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(DB)); } catch (e) { console.warn('[anvaya] could not save', e); }
  }
  function reset() {
    DB = seed();
    save();
  }

  /* ---------------------------------------------------------------- helpers -- */
  const byId = (list, id) => (list || []).find(x => x.id === id);
  const memberName = (id) => (byId(load().members, id) || {}).full_name || 'Unassigned';
  const companyName = (id) => (byId(load().companies, id) || {}).name || '';
  const contactName = (id) => {
    const c = byId(load().contacts, id);
    return c ? `${c.first_name} ${c.last_name || ''}`.trim() : '';
  };
  const stageOf = (id) => {
    for (const p of load().pipelines) {
      const s = p.stages.find(x => x.id === id);
      if (s) return s;
    }
    return null;
  };
  const daysBetween = (a, b) => Math.floor((new Date(b) - new Date(a)) / day);
  const audit = (action, entity, entityId, extra = {}) => {
    load().audit.unshift({
      id: uid('au'), actor_name: load().user.full_name, action, entity, entity_id: entityId || null,
      created_at: now(), ...extra
    });
    load().audit = load().audit.slice(0, 400);
  };

  /* ------------------------------------------------------------ enrichment -- */
  function enrich(resource, row) {
    const db = load();
    switch (resource) {
      case 'leads':
        return { ...row, owner_name: memberName(row.owner_id) };
      case 'contacts':
        return { ...row, full_name: `${row.first_name} ${row.last_name || ''}`.trim(), company_name: companyName(row.company_id), owner_name: memberName(row.owner_id) };
      case 'companies':
        return { ...row, owner_name: memberName(row.owner_id) };
      case 'deals': {
        const st = stageOf(row.stage_id) || {};
        return {
          ...row,
          stage_name: st.name, stage_position: st.position, probability: row.probability ?? st.probability,
          is_won: !!st.is_won, is_lost: !!st.is_lost,
          company_name: companyName(row.company_id), contact_name: contactName(row.contact_id),
          owner_name: memberName(row.owner_id),
          days_in_stage: Math.max(0, daysBetween(row.stage_changed_at || row.created_at, now()))
        };
      }
      case 'tasks':
        return { ...row, assignee_name: memberName(row.assignee_id) };
      case 'activities':
        return { ...row, owner_name: memberName(row.owner_id), contact_name: contactName(row.contact_id) };
      case 'tickets': {
        const due = row.sla_due_at ? new Date(row.sla_due_at) : null;
        const state = row.resolved_at ? 'met' : due && due < new Date() ? 'breached'
          : due && due - new Date() < 4 * 3600000 ? 'at_risk' : 'on_track';
        return {
          ...row, sla_state: state, assignee_name: memberName(row.assignee_id),
          company_name: companyName(row.company_id), contact_name: contactName(row.contact_id)
        };
      }
      case 'members':
        return { ...row, permissions: row.permissions || [] };
      default:
        return { ...row };
    }
  }

  const SEARCH_FIELDS = {
    leads: ['name', 'company_name', 'email', 'phone'],
    contacts: ['first_name', 'last_name', 'email', 'phone'],
    companies: ['name', 'industry', 'city'],
    deals: ['title'],
    tasks: ['title', 'notes'],
    activities: ['subject', 'body'],
    tickets: ['subject', 'number'],
    products: ['name', 'sku', 'category'],
    campaigns: ['name', 'subject'],
    quotations: ['number'],
    invoices: ['number'],
    projects: ['name'],
    workflows: ['name', 'description'],
    members: ['full_name', 'email'],
    'custom-fields': ['label', 'key'],
    notifications: ['title', 'body']
  };
  const FILTERS = {
    leads: { status: 'status', source: 'source', owner_id: 'owner_id' },
    contacts: { company_id: 'company_id', owner_id: 'owner_id' },
    companies: { industry: 'industry', owner_id: 'owner_id' },
    deals: { status: 'status', stage_id: 'stage_id', pipeline_id: 'pipeline_id', owner_id: 'owner_id', company_id: 'company_id' },
    tasks: { status: 'status', priority: 'priority', assignee_id: 'assignee_id', related_id: 'related_id' },
    activities: { type: 'type', contact_id: 'contact_id', company_id: 'company_id', deal_id: 'deal_id' },
    tickets: { status: 'status', priority: 'priority', assignee_id: 'assignee_id', contact_id: 'contact_id' },
    products: { category: 'category' },
    campaigns: { status: 'status', channel: 'channel' },
    quotations: { status: 'status', company_id: 'company_id' },
    invoices: { status: 'status', company_id: 'company_id' },
    projects: { status: 'status', company_id: 'company_id' },
    workflows: { status: 'status' },
    members: { status: 'status' },
    'custom-fields': { entity: 'entity' },
    notifications: { type: 'type' }
  };
  const SORTS = {
    leads: 'created_at', contacts: 'created_at', companies: 'name', deals: 'created_at', tasks: 'due_date',
    activities: 'occurred_at', tickets: 'created_at', products: 'name', campaigns: 'created_at',
    quotations: 'created_at', invoices: 'created_at', projects: 'created_at', workflows: 'created_at',
    members: 'joined_at', 'custom-fields': 'position', notifications: 'created_at'
  };
  const TABLE = {
    leads: 'leads', contacts: 'contacts', companies: 'companies', deals: 'deals', tasks: 'tasks',
    activities: 'activities', tickets: 'tickets', products: 'products', campaigns: 'campaigns',
    quotations: 'quotations', invoices: 'invoices', projects: 'projects', workflows: 'workflows',
    members: 'members', 'custom-fields': 'customFields', notifications: 'notifications'
  };
  const WRITABLE = {
    leads: ['name', 'company_name', 'email', 'phone', 'source', 'status', 'score', 'owner_id', 'estimated_value', 'notes', 'lost_reason', 'custom'],
    contacts: ['first_name', 'last_name', 'email', 'phone', 'title', 'city', 'company_id', 'owner_id', 'tags', 'consent', 'health_score', 'custom'],
    companies: ['name', 'domain', 'industry', 'size_band', 'annual_revenue', 'phone', 'website', 'city', 'owner_id', 'health_score', 'tags', 'custom'],
    deals: ['title', 'value', 'currency', 'stage_id', 'pipeline_id', 'company_id', 'contact_id', 'probability', 'expected_close_date', 'owner_id', 'status', 'lost_reason', 'competitor', 'custom'],
    tasks: ['title', 'notes', 'due_date', 'priority', 'status', 'assignee_id', 'related_type', 'related_id', 'completed_at'],
    activities: ['type', 'subject', 'body', 'contact_id', 'company_id', 'deal_id', 'owner_id', 'occurred_at', 'duration_min'],
    tickets: ['number', 'subject', 'description', 'contact_id', 'company_id', 'deal_id', 'priority', 'status', 'category', 'assignee_id', 'sla_due_at', 'csat', 'resolved_at'],
    products: ['sku', 'name', 'category', 'unit_price', 'tax_rate', 'stock_qty', 'reorder_point'],
    campaigns: ['name', 'channel', 'status', 'subject', 'body'],
    quotations: ['number', 'deal_id', 'company_id', 'status', 'issue_date', 'valid_until', 'subtotal', 'tax_total', 'total', 'terms'],
    invoices: ['number', 'deal_id', 'company_id', 'status', 'issue_date', 'due_date', 'subtotal', 'tax_total', 'total', 'amount_paid'],
    projects: ['name', 'company_id', 'status', 'start_date', 'end_date', 'budget', 'spent', 'progress', 'manager_id'],
    workflows: ['name', 'description', 'status', 'trigger', 'conditions', 'actions'],
    members: ['role_name', 'role_key', 'status', 'title'],
    'custom-fields': ['entity', 'key', 'label', 'type', 'options', 'required', 'position'],
    notifications: ['read_at']
  };

  /* ------------------------------------------------------------- workflows -- */
  const OPS = {
    eq: (a, b) => String(a) === String(b),
    neq: (a, b) => String(a) !== String(b),
    gt: (a, b) => Number(a) > Number(b),
    lt: (a, b) => Number(a) < Number(b),
    contains: (a, b) => String(a || '').toLowerCase().includes(String(b).toLowerCase()),
    is_empty: (a) => a === null || a === undefined || a === ''
  };

  function runWorkflows(event, record) {
    const db = load();
    const results = [];
    db.workflows.filter(w => w.status === 'active' && w.trigger?.event === event).forEach(wf => {
      const pass = (wf.conditions || []).every(c => (OPS[c.op] || OPS.eq)(record[c.field], c.value));
      const run = {
        id: uid('wr'), workflow_id: wf.id, workflow_name: wf.name, status: pass ? 'succeeded' : 'skipped',
        started_at: now(), context: { record: record.id || null }
      };
      if (pass) {
        (wf.actions || []).forEach((a, i) => {
          const steps = db.workflowSteps[run.id] = db.workflowSteps[run.id] || [];
          const fill = (t) => String(t || '').replace(/\{\{(\w+)\}\}/g, (_, k) => record[k] ?? '');
          if (a.type === 'create_task') {
            db.tasks.unshift({
              id: uid('ts'), title: fill(a.title || 'Follow up'), priority: a.priority || 'medium', status: 'open',
              assignee_id: record.owner_id || 'mb-1', due_date: dateOnly(Number(a.dueInDays ?? 2)),
              related_type: 'workflow', related_id: record.id || null
            });
            steps.push({ step_index: i, node_type: 'create_task', status: 'succeeded', output: { title: fill(a.title) } });
          } else if (a.type === 'notify') {
            db.notifications.unshift({
              id: uid('nt'), type: 'workflow', title: fill(a.title || 'Workflow'), body: fill(a.body || ''),
              read_at: null, created_at: now()
            });
            steps.push({ step_index: i, node_type: 'notify', status: 'succeeded', output: {} });
          } else if (a.type === 'log_activity') {
            db.activities.unshift({
              id: uid('ac'), type: 'note', subject: fill(a.subject || 'Workflow activity'), body: '',
              contact_id: record.contact_id || null, company_id: record.company_id || null,
              deal_id: record.id && record.title ? record.id : null, owner_id: record.owner_id || 'mb-1', occurred_at: now()
            });
            steps.push({ step_index: i, node_type: 'log_activity', status: 'succeeded', output: {} });
          } else if (a.type === 'send_email') {
            run.status = 'awaiting_approval';
            db.aiActions.unshift({
              id: uid('aa'), action: 'send_email', status: 'proposed', created_at: now(),
              payload: { subject: a.subject, to: a.to }, note: 'Email held for approval — nothing was sent.'
            });
            steps.push({ step_index: i, node_type: 'send_email', status: 'awaiting_approval', output: { note: 'Held for human approval' } });
          } else {
            steps.push({ step_index: i, node_type: a.type, status: 'succeeded', output: {} });
          }
        });
      }
      db.workflowRuns.unshift(run);
      wf.run_count = (wf.run_count || 0) + 1;
      wf.last_run_at = now();
      results.push(run);
    });
    if (results.length) save();
    return results;
  }

  /* -------------------------------------------------------------- dashboard -- */
  function dashboard() {
    const db = load();
    const deals = db.deals;
    const open = deals.filter(d => d.status === 'open');
    const won = deals.filter(d => d.status === 'won');
    const lost = deals.filter(d => d.status === 'lost');
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
    const quarterStart = new Date(monthStart);
    quarterStart.setMonth(Math.floor(monthStart.getMonth() / 3) * 3);
    const inQuarter = (d) => new Date(d.stage_changed_at || d.created_at) >= quarterStart;

    const today = dateOnly(0);
    const kpi = {
      pipeline_value: open.reduce((a, d) => a + Number(d.value), 0),
      open_deals: open.length,
      weighted_value: open.reduce((a, d) => a + Number(d.value) * (Number(d.probability) || 0) / 100, 0),
      won_value: won.filter(inQuarter).reduce((a, d) => a + Number(d.value), 0),
      won_count: won.filter(inQuarter).length,
      lost_count: lost.filter(inQuarter).length,
      avg_deal: open.length ? open.reduce((a, d) => a + Number(d.value), 0) / open.length : 0,
      new_leads: db.leads.filter(l => ['new', 'contacted'].includes(l.status)).length,
      total_leads: db.leads.length,
      open_tickets: db.tickets.filter(t => !['resolved', 'closed'].includes(t.status)).length,
      sla_breaches: db.tickets.filter(t => !['resolved', 'closed'].includes(t.status) && t.sla_due_at && new Date(t.sla_due_at) < new Date()).length,
      open_tasks: db.tasks.filter(t => t.status !== 'done').length,
      overdue_tasks: db.tasks.filter(t => t.status !== 'done' && t.due_date && t.due_date < today).length,
      outstanding: db.invoices.reduce((a, i) => a + Math.max(0, Number(i.total) - Number(i.amount_paid || 0)), 0)
    };

    const stages = db.pipelines[0].stages.map(s => {
      const ds = deals.filter(d => d.stage_id === s.id);
      return { ...s, deals: ds.length, value: ds.reduce((a, d) => a + Number(d.value), 0) };
    });

    const byMonth = {};
    won.forEach(d => {
      const when = new Date(d.expected_close_date || d.stage_changed_at || d.created_at);
      if (when < new Date(Date.now() - 365 * day)) return;
      const key = when.toISOString().slice(0, 7);
      byMonth[key] = (byMonth[key] || 0) + Number(d.value);
    });
    const revenue = Object.keys(byMonth).sort().map(m => ({ month: m, value: byMonth[m] }));

    const sources = Object.entries(db.leads.reduce((acc, l) => {
      acc[l.source] = (acc[l.source] || 0) + 1; return acc;
    }, {})).map(([source, n]) => ({ source, n })).sort((a, b) => b.n - a.n);

    const team = Object.entries(won.reduce((acc, d) => {
      const name = memberName(d.owner_id);
      acc[name] = acc[name] || { full_name: name, won: 0, value: 0 };
      acc[name].won += 1; acc[name].value += Number(d.value);
      return acc;
    }, {})).map(([, v]) => v).sort((a, b) => b.value - a.value);

    const recent = [...db.activities].sort((a, b) => new Date(b.occurred_at) - new Date(a.occurred_at))
      .slice(0, 8).map(a => ({ ...a, contact_name: contactName(a.contact_id) }));

    return { kpi, stages, revenue, sources, team, recent };
  }

  /* ----------------------------------------------------------------- copilot -- */
  const INTENTS = [
    ['at_risk', /(risk|lose|losing|stalled)/i],
    ['stale', /(not contacted|no contact|inactive|stale|quiet)/i],
    ['qualified', /(qualified|hot lead|best lead)/i],
    ['overdue', /(overdue|follow.?up task|create tasks)/i],
    ['summary', /(summar|brief|tell me about|360)/i],
    ['tickets', /(ticket|support|sla)/i],
    ['forecast', /(forecast|report|pipeline|revenue|month)/i]
  ];
  const money = (n) => {
    const v = Number(n || 0);
    if (v >= 1e7) return '₹' + (v / 1e7).toFixed(2) + ' Cr';
    if (v >= 1e5) return '₹' + (v / 1e5).toFixed(1) + ' L';
    return '₹' + Math.round(v).toLocaleString('en-IN');
  };

  function copilot(message) {
    const db = load();
    const intent = (INTENTS.find(([, re]) => re.test(message)) || ['forecast'])[0];
    let answer = '', bullets = [], basis = '', proposed = [];

    if (intent === 'at_risk') {
      const rows = db.deals.filter(d => d.status === 'open').map(d => ({ ...d, ...enrich('deals', d) }))
        .filter(d => d.days_in_stage > 14 || (new Date(d.expected_close_date) < new Date(Date.now() + 7 * day) && d.probability < 50))
        .sort((a, b) => b.value - a.value);
      answer = rows.length
        ? `${rows.length} open deal${rows.length === 1 ? '' : 's'} look stuck — more than 14 days without a stage change, or a close date inside a week with low confidence. Together worth ${money(rows.reduce((a, r) => a + Number(r.value), 0))}.`
        : 'No open deal is stalled past 14 days or closing inside a week at low confidence.';
      bullets = rows.slice(0, 6).map(r => `${r.title} · ${r.company_name} · ${money(r.value)} · ${r.days_in_stage}d in ${r.stage_name}`);
      basis = 'Rule: stage unchanged for 14+ days, or close date within 7 days with probability under 50. A filter over your records, not a prediction.';
    } else if (intent === 'stale') {
      const rows = db.contacts.map(c => {
        const last = db.activities.filter(a => a.contact_id === c.id).map(a => a.occurred_at).sort().pop();
        return { c, days: daysBetween(last || c.created_at, now()), last };
      }).filter(x => x.days >= 7).sort((a, b) => b.days - a.days);
      answer = rows.length
        ? `${rows.length} contact${rows.length === 1 ? '' : 's'} have no logged activity in the last week. The longest silence is ${rows[0].days} days.`
        : 'Everyone has activity logged in the last 7 days.';
      bullets = rows.slice(0, 6).map(x => `${x.c.first_name} ${x.c.last_name || ''} · ${companyName(x.c.company_id)} · ${x.days}d ago`);
      basis = 'Days since the most recent call, email, meeting or note on that contact.';
    } else if (intent === 'qualified') {
      const rows = db.leads.filter(l => ['qualified', 'proposal'].includes(l.status)).sort((a, b) => (b.score || 0) - (a.score || 0));
      answer = rows.length
        ? `${rows.length} qualified or proposal-stage lead${rows.length === 1 ? '' : 's'}, worth ${money(rows.reduce((a, r) => a + Number(r.estimated_value), 0))} in estimated value.`
        : 'There are no qualified or proposal-stage leads right now.';
      bullets = rows.slice(0, 6).map(r => `${r.name} · ${r.company_name} · score ${r.score ?? '—'} · ${money(r.estimated_value)}`);
      basis = 'Leads with status qualified or proposal, ordered by score. Scores are heuristic, not probabilities.';
    } else if (intent === 'overdue') {
      const rows = db.tasks.filter(t => t.status !== 'done' && t.due_date && t.due_date < dateOnly(0));
      answer = rows.length
        ? `${rows.length} task${rows.length === 1 ? '' : 's'} are past their due date. I can create follow-up tasks for the linked records once you approve.`
        : 'No tasks are overdue.';
      bullets = rows.slice(0, 6).map(r => `${r.title} · was due ${r.due_date} · ${r.priority}`);
      basis = 'Tasks with status open or in progress and a due date before today.';
      if (rows.length) {
        const action = { id: uid('aa'), action: 'create_followup_tasks', status: 'proposed', created_at: now(), payload: { taskIds: rows.slice(0, 5).map(r => r.id) } };
        db.aiActions.unshift(action);
        proposed.push(action);
      }
    } else if (intent === 'summary') {
      const c = db.contacts[0];
      const acts = db.activities.filter(a => a.contact_id === c.id).slice(0, 4);
      const ds = db.deals.filter(d => d.contact_id === c.id);
      const ts = db.tickets.filter(t => t.contact_id === c.id);
      answer = `${c.first_name} ${c.last_name || ''} — ${c.title} at ${companyName(c.company_id)}. Health ${c.health_score}. ${ds.length} deal(s), ${ts.length} ticket(s), ${acts.length} recent activities.`;
      bullets = [...acts.map(a => `${a.type}: ${a.subject}`), ...ds.map(d => `deal: ${d.title} · ${money(d.value)} · ${d.status}`)];
      basis = 'Composed from recorded activities, deals and tickets. The records are the source of truth.';
    } else if (intent === 'tickets') {
      const rows = db.tickets.filter(t => !['resolved', 'closed'].includes(t.status));
      const late = rows.filter(t => t.sla_due_at && new Date(t.sla_due_at) < new Date());
      answer = rows.length ? `${rows.length} ticket${rows.length === 1 ? '' : 's'} still open, ${late.length} past the deadline.` : 'No open tickets.';
      bullets = rows.slice(0, 6).map(r => `${r.number} · ${r.subject} · ${r.priority} · ${memberName(r.assignee_id)}`);
      basis = 'Tickets not resolved or closed, ordered by priority.';
    } else {
      const d = dashboard();
      answer = `Open pipeline: ${money(d.kpi.pipeline_value)} across ${d.kpi.open_deals} deals. Signed this quarter: ${money(d.kpi.won_value)} from ${d.kpi.won_count} deals.`;
      bullets = db.deals.filter(x => x.status === 'open').slice(0, 6).map(r => `${r.title} · ${companyName(r.company_id)} · ${money(r.value)} · ${r.probability}%`);
      basis = 'Weighted value = deal value × stage probability. An estimate, not a commitment.';
    }

    const run = { id: uid('ar'), prompt: message, provider: 'local', model: 'rules + browser data', status: 'succeeded', latency_ms: 12, created_at: now() };
    db.aiRuns.unshift(run);
    save();

    return {
      runId: run.id, intent, mode: 'local', answer, bullets, basis,
      model: 'rules + browser data', records: bullets.length, proposedActions: proposed, degraded: false
    };
  }

  /* ------------------------------------------------------------------ routes -- */
  function listResource(resource, q) {
    const db = load();
    const table = TABLE[resource];
    if (!table) throw httpError(404, 'Unknown resource');
    let rows = (db[table] || []).map(r => enrich(resource, r));

    if (resource === 'notifications') rows = rows.filter(n => true);

    const filters = FILTERS[resource] || {};
    Object.entries(filters).forEach(([param, field]) => {
      const v = q.get(param);
      if (v && v !== 'all') rows = rows.filter(r => String(r[field]) === String(v));
    });
    const term = q.get('q');
    if (term) {
      const fields = SEARCH_FIELDS[resource] || [];
      const lower = term.toLowerCase();
      rows = rows.filter(r => fields.some(f => String(r[f] || '').toLowerCase().includes(lower)));
    }
    const sortParam = q.get('sort');
    const [sortField, dir] = sortParam ? sortParam.split(':') : [SORTS[resource], 'desc'];
    rows.sort((a, b) => {
      const av = a[sortField], bv = b[sortField];
      if (av === bv) return 0;
      if (av === null || av === undefined) return 1;
      if (bv === null || bv === undefined) return -1;
      return (av > bv ? 1 : -1) * (dir === 'asc' ? 1 : -1);
    });
    const limit = Math.min(Number(q.get('limit')) || 50, 200);
    const offset = Number(q.get('offset')) || 0;
    return { data: rows.slice(offset, offset + limit), total: rows.length, limit, offset };
  }

  function httpError(status, message) {
    return Object.assign(new Error(message), { status });
  }

  function createResource(resource, body) {
    const db = load();
    const table = TABLE[resource];
    const allowed = WRITABLE[resource] || [];
    const row = { id: uid(resource.slice(0, 2)) };
    allowed.forEach(k => { if (body[k] !== undefined) row[k] = body[k]; });
    if (resource === 'deals') {
      const stage = stageOf(row.stage_id) || db.pipelines[0].stages[0];
      row.stage_id = stage.id;
      row.probability = row.probability ?? stage.probability;
      row.status = stage.is_won ? 'won' : stage.is_lost ? 'lost' : 'open';
      row.stage_changed_at = now();
      row.pipeline_id = row.pipeline_id || db.pipelines[0].id;
      row.owner_id = row.owner_id || 'mb-1';
    }
    if (resource === 'tasks') { row.status = row.status || 'open'; row.assignee_id = row.assignee_id || 'mb-1'; }
    if (['leads', 'contacts', 'companies'].includes(resource)) row.owner_id = row.owner_id || 'mb-1';
    if (resource === 'tickets') {
      row.status = row.status || 'open';
      if (!row.sla_due_at) {
        const hours = row.priority === 'critical' ? 4 : row.priority === 'high' ? 8 : 24;
        row.sla_due_at = new Date(Date.now() + hours * 3600000).toISOString();
      }
      row.number = row.number || 'TKT-' + Math.floor(1000 + Math.random() * 9000);
      row.assignee_id = row.assignee_id || 'mb-4';
    }
    if (resource === 'leads') row.created_at = row.created_at || now();
    if (!row.created_at) row.created_at = now();
    db[table].unshift(row);
    audit(`${resource}.created`, resource, row.id);
    if (resource === 'leads') runWorkflows('lead.created', row);
    if (resource === 'deals') runWorkflows('deal.created', row);
    save();
    return enrich(resource, row);
  }

  function updateResource(resource, id, body) {
    const db = load();
    const table = TABLE[resource];
    const row = (db[table] || []).find(r => r.id === id);
    if (!row) throw httpError(404, 'Not found');
    const allowed = WRITABLE[resource] || [];
    const before = { ...row };
    allowed.forEach(k => { if (body[k] !== undefined) row[k] = body[k]; });
    if (resource === 'tickets' && body.status === 'resolved' && !row.resolved_at) row.resolved_at = now();
    audit(`${resource}.updated`, resource, id, { before: { status: before.status }, after: { status: row.status } });
    save();
    return enrich(resource, row);
  }

  function deleteResource(resource, id) {
    const db = load();
    const table = TABLE[resource];
    const idx = (db[table] || []).findIndex(r => r.id === id);
    if (idx === -1) throw httpError(404, 'Not found');
    db[table].splice(idx, 1);
    audit(`${resource}.deleted`, resource, id);
    save();
    return { ok: true };
  }

  function convertLead(id, body) {
    const db = load();
    const lead = db.leads.find(l => l.id === id);
    if (!lead) throw httpError(404, 'Lead not found');
    if (lead.converted_contact_id) throw httpError(409, 'This lead has already been converted');

    let company = db.companies.find(c => c.name.toLowerCase() === String(lead.company_name || '').toLowerCase());
    if (!company && lead.company_name) {
      company = { id: uid('co'), name: lead.company_name, industry: 'Unspecified', owner_id: lead.owner_id, health_score: 60, created_at: now() };
      db.companies.unshift(company);
    }
    const parts = String(lead.name).trim().split(' ');
    const owner = lead.owner_id || 'mb-1';
    const contact = {
      id: uid('ct'), company_id: company ? company.id : null, first_name: parts[0], last_name: parts.slice(1).join(' '),
      email: lead.email, phone: lead.phone, title: '', owner_id: owner, health_score: 60,
      tags: ['converted'], consent: { email: true, whatsapp: false, calls: true }, created_at: now()
    };
    db.contacts.unshift(contact);

    const stage = body.stageId ? stageOf(body.stageId) : db.pipelines[0].stages[0];
    const deal = {
      id: uid('dl'), title: body.dealTitle || `${lead.company_name || lead.name} — new opportunity`,
      company_id: company ? company.id : null, contact_id: contact.id, stage_id: stage.id,
      value: Number(body.dealValue ?? lead.estimated_value ?? 0), probability: stage.probability,
      expected_close_date: dateOnly(30), owner_id: owner, status: 'open',
      stage_changed_at: now(), created_at: now()
    };
    db.deals.unshift(deal);
    lead.status = 'converted';
    lead.converted_contact_id = contact.id;
    lead.converted_deal_id = deal.id;
    db.activities.unshift({
      id: uid('ac'), type: 'note', subject: 'Lead converted', body: `Converted from lead ${lead.name}.`,
      contact_id: contact.id, company_id: company ? company.id : null, deal_id: deal.id,
      owner_id: owner, occurred_at: now()
    });
    audit('lead.converted', 'lead', lead.id);
    runWorkflows('lead.status_changed', lead);
    save();
    return { lead, contact, company, deal };
  }

  function moveStage(id, stageId) {
    const db = load();
    const deal = db.deals.find(d => d.id === id);
    if (!deal) throw httpError(404, 'Deal not found');
    const stage = stageOf(stageId);
    if (!stage) throw httpError(404, 'Stage not found');
    const before = { stage_id: deal.stage_id, status: deal.status };
    deal.stage_id = stage.id;
    deal.probability = stage.probability;
    deal.status = stage.is_won ? 'won' : stage.is_lost ? 'lost' : 'open';
    deal.stage_changed_at = now();
    audit('deal.stage_changed', 'deal', id, { before, after: { stage_id: stage.id, status: deal.status } });
    runWorkflows('deal.stage_changed', deal);
    if (deal.status === 'won') runWorkflows('deal.won', deal);
    save();
    return enrich('deals', deal);
  }

  function contact360(id) {
    const db = load();
    const contact = db.contacts.find(c => c.id === id);
    if (!contact) throw httpError(404, 'Contact not found');
    const deals = db.deals.filter(d => d.contact_id === id).map(d => enrich('deals', d));
    return {
      contact: {
        ...contact, company_name: companyName(contact.company_id),
        industry: (byId(db.companies, contact.company_id) || {}).industry || '',
        owner_name: memberName(contact.owner_id)
      },
      activities: db.activities.filter(a => a.contact_id === id).sort((a, b) => new Date(b.occurred_at) - new Date(a.occurred_at)),
      deals,
      tickets: db.tickets.filter(t => t.contact_id === id).map(t => enrich('tickets', t)),
      tasks: db.tasks.filter(t => t.related_id === id).map(t => enrich('tasks', t)),
      invoices: db.invoices.filter(i => i.contact_id === id),
      lifetime: deals.filter(d => d.status === 'won').reduce((a, d) => a + Number(d.value), 0)
    };
  }

  function search(term) {
    const db = load();
    const t = String(term || '').toLowerCase();
    const out = [];
    db.leads.forEach(l => { if (String(l.name).toLowerCase().includes(t) || String(l.company_name || '').toLowerCase().includes(t)) out.push({ type: 'lead', id: l.id, title: l.name, subtitle: l.company_name }); });
    db.contacts.forEach(c => { const n = `${c.first_name} ${c.last_name || ''}`; if (n.toLowerCase().includes(t) || String(c.email || '').toLowerCase().includes(t)) out.push({ type: 'contact', id: c.id, title: n, subtitle: companyName(c.company_id) }); });
    db.companies.forEach(c => { if (String(c.name).toLowerCase().includes(t)) out.push({ type: 'company', id: c.id, title: c.name, subtitle: c.industry }); });
    db.deals.forEach(d => { if (String(d.title).toLowerCase().includes(t)) out.push({ type: 'deal', id: d.id, title: d.title, subtitle: companyName(d.company_id) }); });
    db.tickets.forEach(x => { if (String(x.subject).toLowerCase().includes(t) || String(x.number).toLowerCase().includes(t)) out.push({ type: 'ticket', id: x.id, title: x.subject, subtitle: x.number }); });
    return out.slice(0, 20);
  }

  /* --------------------------------------------------------------- the shim -- */
  async function api(path, opts = {}) {
    const db = load();
    const [rawPath, rawQuery] = String(path).split('?');
    const q = new URLSearchParams(rawQuery || '');
    const method = (opts.method || (opts.body ? 'POST' : 'GET')).toUpperCase();
    const body = opts.body || {};
    const parts = rawPath.replace(/^\/api\/?/, '').split('/').filter(Boolean);

    // Small delay so loading states behave like the real thing.
    await new Promise(r => setTimeout(r, 90));

    const notFound = () => { throw httpError(404, 'Not found'); };

    if (parts[0] === 'health') return { ok: true, db: 'browser storage', time: now(), aiProvider: 'local-rules' };

    if (parts[0] === 'auth') {
      if (parts[1] === 'me') {
        return {
          user: { id: db.user.id, email: db.user.email, fullName: db.user.full_name, isPlatformAdmin: false },
          org: db.org,
          role: { key: db.user.role_key, name: db.user.role_name },
          perms: ['*'],
          memberships: [{ orgId: db.org.id, orgName: db.org.name, roleKey: db.user.role_key, roleName: db.user.role_name, plan: db.org.plan }],
          subscription: db.subscription,
          counts: { seats: db.members.filter(m => m.status === 'active').length, leads: db.leads.length, deals: db.deals.length }
        };
      }
      if (parts[1] === 'login') return { ok: true };
      if (parts[1] === 'logout') return { ok: true };
      if (parts[1] === 'switch-org') return { ok: true, orgId: db.org.id };
      if (parts[1] === 'register') {
        const fresh = seed();
        fresh.org.name = body.orgName || 'My workspace';
        fresh.org.industry = body.industry || 'Unspecified';
        fresh.user.full_name = body.fullName || 'New user';
        fresh.user.email = body.email || 'you@example.com';
        fresh.members = [fresh.members[0]];
        fresh.members[0].full_name = fresh.user.full_name;
        fresh.members[0].email = fresh.user.email;
        // A new workspace starts empty, exactly like the server build.
        ['companies', 'contacts', 'leads', 'deals', 'activities', 'tasks', 'tickets', 'products',
          'quotations', 'invoices', 'projects', 'workflows', 'customFields'].forEach(k => { fresh[k] = []; });
        fresh.notifications = [];
        fresh.audit = [];
        DB = fresh; save();
        return { user: { id: fresh.user.id, email: fresh.user.email }, org: fresh.org };
      }
      if (parts[1] === 'invite') {
        const member = {
          id: uid('mb'), full_name: body.fullName || String(body.email || '').split('@')[0],
          email: body.email, role_name: (body.roleKey || 'sales'), role_key: body.roleKey || 'sales',
          status: 'invited', title: '', permissions: [], joined_at: now()
        };
        db.members.push(member);
        audit('member.invited', 'member', member.id);
        save();
        return {
          member, inviteToken: Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2),
          emailSent: false,
          note: 'This single-file build has no mail server, so nothing was emailed. Share the token yourself.'
        };
      }
      notFound();
    }

    if (parts[0] === 'dashboard') return dashboard();
    if (parts[0] === 'pipelines') return { data: db.pipelines };
    if (parts[0] === 'search') return { data: search(q.get('q')) };
    if (parts[0] === 'audit-logs') {
      const limit = Number(q.get('limit')) || 100;
      return { data: db.audit.slice(0, limit) };
    }

    if (parts[0] === 'ai') {
      if (parts[1] === 'copilot') return copilot(body.message || '');
      if (parts[1] === 'runs') return { data: db.aiRuns.slice(0, 20) };
      if (parts[1] === 'actions') {
        const action = db.aiActions.find(a => a.id === parts[2]);
        if (!action) throw httpError(404, 'Action not found');
        if (action.status !== 'proposed') throw httpError(409, `Action already ${action.status}`);
        if (parts[3] === 'reject') { action.status = 'rejected'; save(); return action; }
        if (action.action === 'create_followup_tasks') {
          (action.payload.taskIds || []).forEach(tid => {
            const src = db.tasks.find(t => t.id === tid);
            if (!src) return;
            db.tasks.unshift({
              id: uid('ts'), title: `Follow up: ${src.title}`, notes: 'Created from an approved copilot suggestion.',
              priority: 'high', status: 'open', assignee_id: src.assignee_id, due_date: dateOnly(2),
              related_type: src.related_type, related_id: src.related_id
            });
          });
        }
        action.status = 'applied';
        action.applied_at = now();
        audit('ai.action_applied', 'ai_action', action.id);
        save();
        return action;
      }
    }

    if (parts[0] === 'workflows') {
      if (parts[1] === 'meta') {
        return {
          triggers: ['lead.created', 'lead.status_changed', 'deal.created', 'deal.stage_changed', 'deal.won', 'contact.created', 'ticket.created'],
          actions: ['create_task', 'notify', 'update_field', 'log_activity', 'send_email']
        };
      }
      if (parts[1] === 'runs') {
        if (parts[2] && parts[3] === 'steps') return { data: db.workflowSteps[parts[2]] || [] };
        return { data: db.workflowRuns.slice(0, 50) };
      }
      if (parts[2] === 'test') {
        const wf = db.workflows.find(w => w.id === parts[1]);
        if (!wf) throw httpError(404, 'Workflow not found');
        const before = db.workflowRuns.length;
        runWorkflows(wf.trigger.event, { id: 'test', name: 'Test record', title: 'Test deal', source: 'website', owner_id: 'mb-1' });
        return db.workflowRuns[0] || { status: 'skipped' };
      }
      // fall through to generic handling for list/create/patch
    }

    if (parts[0] === 'leads' && parts[2] === 'convert') return convertLead(parts[1], body);
    if (parts[0] === 'deals' && parts[2] === 'stage') return moveStage(parts[1], body.stageId);
    if (parts[0] === 'contacts' && parts[2] === '360') return contact360(parts[1]);

    // generic resources
    const resource = parts[0];
    if (TABLE[resource]) {
      if (method === 'GET' && parts.length === 1) return listResource(resource, q);
      if (method === 'GET' && parts.length === 2) {
        const row = (db[TABLE[resource]] || []).find(r => r.id === parts[1]);
        if (!row) notFound();
        return enrich(resource, row);
      }
      if (method === 'POST' && parts.length === 1) return createResource(resource, body);
      if (method === 'PATCH' && parts.length === 2) return updateResource(resource, parts[1], body);
      if (method === 'DELETE' && parts.length === 2) return deleteResource(resource, parts[1]);
    }

    notFound();
  }

  // Public surface: the bridge calls handle(); the sidebar calls reset().
  window.AnvayaEngine = {
    handle: api,
    reset() {
      if (confirm('Reset this workspace back to the original sample data?')) {
        localStorage.removeItem(KEY);
        DB = null;
        location.reload();
      }
    },
    info() {
      try {
        const bytes = new Blob([localStorage.getItem(KEY) || '']).size;
        return (bytes / 1024).toFixed(0) + ' KB saved in this browser';
      } catch (e) { return 'browser storage unavailable'; }
    }
  };
})();
