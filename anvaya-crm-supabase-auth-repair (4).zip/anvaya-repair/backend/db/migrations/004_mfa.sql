-- ============================================================================
-- Anvaya CRM — 004 multi-factor authentication
--
-- Additive only: no existing column is dropped or retyped, so V5 data and
-- accounts keep working untouched.
-- ============================================================================

-- --------------------------------------------------------------------- MFA ---
alter table users add column if not exists mfa_secret        text;
alter table users add column if not exists mfa_enabled_at    timestamptz;
alter table users add column if not exists mfa_backup_codes  text[] not null default '{}';
alter table users add column if not exists mfa_last_used_at  timestamptz;

-- A session created before the second factor is not usable until it is proven.
alter table sessions add column if not exists mfa_ok boolean not null default true;

-- Organisation-level enforcement lives in organisations.settings->>'require_mfa'.

