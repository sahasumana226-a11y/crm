-- Additive compatibility for databases previously provisioned from the legacy
-- supabase/anvaya-supabase.sql bundle. CREATE TABLE IF NOT EXISTS does not add
-- columns to an existing table, so this migration aligns legacy tables with
-- the canonical backend schema without dropping or rewriting customer data.

alter table activities add column if not exists ticket_id uuid references tickets(id) on delete set null;
alter table activities add column if not exists created_by uuid references users(id);

alter table ai_runs add column if not exists user_id uuid references users(id);
alter table ai_runs add column if not exists agent text not null default 'copilot';
alter table ai_runs add column if not exists response text;
alter table ai_runs add column if not exists status text not null default 'succeeded'
  check (status in ('running', 'succeeded', 'failed'));
alter table ai_runs add column if not exists tokens_in int not null default 0;
alter table ai_runs add column if not exists tokens_out int not null default 0;
alter table ai_runs add column if not exists error text;

alter table audit_logs add column if not exists ip text;

alter table companies add column if not exists country text default 'India';
alter table companies add column if not exists address jsonb not null default '{}';
alter table companies add column if not exists parent_id uuid references companies(id) on delete set null;
alter table companies add column if not exists deleted_at timestamptz;

alter table contacts add column if not exists deleted_at timestamptz;
alter table deals add column if not exists deleted_at timestamptz;
alter table integrations add column if not exists last_error text;

alter table invoice_items add column if not exists qty numeric(14,2) not null default 1;
alter table invoice_items add column if not exists line_total numeric(16,2) not null default 0;
alter table invoice_items add column if not exists position int not null default 0;

alter table invoices add column if not exists quotation_id uuid references quotations(id) on delete set null;
alter table invoices add column if not exists notes text;
alter table invoices add column if not exists created_by uuid references users(id);

alter table leads add column if not exists deleted_at timestamptz;

alter table members add column if not exists workspace_id uuid references workspaces(id) on delete set null;
alter table members add column if not exists department text;
alter table members add column if not exists invited_by uuid references users(id);
alter table members add column if not exists invited_at timestamptz;
alter table members add column if not exists joined_at timestamptz;

alter table notifications add column if not exists link text;
alter table payments add column if not exists provider_ref text;
alter table payments add column if not exists status text not null default 'succeeded'
  check (status in ('pending', 'succeeded', 'failed', 'refunded'));

alter table products add column if not exists description text;
alter table products add column if not exists uom text default 'unit';
alter table products add column if not exists is_active boolean not null default true;

alter table quotation_items add column if not exists qty numeric(14,2) not null default 1;
alter table quotation_items add column if not exists discount numeric(14,2) not null default 0;
alter table quotation_items add column if not exists line_total numeric(16,2) not null default 0;
alter table quotation_items add column if not exists position int not null default 0;

alter table quotations add column if not exists contact_id uuid references contacts(id) on delete set null;
alter table quotations add column if not exists discount_total numeric(16,2) not null default 0;
alter table quotations add column if not exists notes text;
alter table quotations add column if not exists version int not null default 1;
alter table quotations add column if not exists approved_at timestamptz;
alter table quotations add column if not exists created_by uuid references users(id);

alter table tasks add column if not exists recurrence text;

alter table tickets add column if not exists sla_policy text not null default 'standard';
alter table tickets add column if not exists first_response_at timestamptz;
alter table tickets add column if not exists created_by uuid references users(id);

alter table users add column if not exists phone text;
alter table users add column if not exists avatar_initials text;
alter table users add column if not exists email_verified_at timestamptz;
alter table users add column if not exists mfa_secret text;
alter table users add column if not exists is_platform_admin boolean not null default false;
alter table users add column if not exists last_login_at timestamptz;

alter table workflow_runs add column if not exists workflow_version int not null default 1;
alter table workflow_runs add column if not exists trigger_entity text;
alter table workflow_runs add column if not exists trigger_id uuid;
alter table workflow_runs add column if not exists error text;

alter table workspaces add column if not exists settings jsonb not null default '{}';

-- Backfill workspace membership only where an organisation has exactly one
-- default workspace. Ambiguous memberships remain NULL and cannot authenticate
-- until an administrator explicitly assigns the correct workspace.
update members m
   set workspace_id = w.id
  from workspaces w
 where m.workspace_id is null
   and w.org_id = m.org_id
   and w.is_default = true
   and (select count(*) from workspaces w2 where w2.org_id = m.org_id) = 1;

create index if not exists members_workspace_user_idx on members (workspace_id, user_id);
create index if not exists companies_parent_idx on companies (parent_id) where parent_id is not null;

-- Legacy schema constrained users.status to active/suspended. Expand it so
-- administrators can explicitly disable accounts as well.
alter table users drop constraint if exists users_status_check;
alter table users add constraint users_status_check
  check (status in ('active', 'disabled', 'suspended'));
