-- ============================================================================
-- Anvaya CRM — 005 documents and finance
--
-- Additive only. Existing invoices, quotations and payments keep their rows and
-- their meaning; new columns are nullable or defaulted so V5 data reads the
-- same after the migration.
-- ============================================================================

-- ------------------------------------------------- document numbering -------
create table if not exists document_sequences (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null check (doc_type in ('quotation','invoice','receipt','credit_note','proposal')),
  prefix      text not null,
  next_number int not null default 1,
  padding     int not null default 4,
  unique (org_id, doc_type)
);

-- Every issued document is snapshotted, so a reprint in 2030 shows what the
-- customer was actually sent, not today's edited record.
create table if not exists document_versions (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  doc_type    text not null,
  entity_id   uuid not null,
  number      text not null,
  version     int not null default 1,
  snapshot    jsonb not null default '{}',
  totals      jsonb not null default '{}',
  issued_by   uuid references users(id),
  issued_at   timestamptz not null default now(),
  unique (org_id, doc_type, entity_id, version)
);
create index if not exists document_versions_entity on document_versions (org_id, doc_type, entity_id, version desc);

-- ------------------------------------------------------------- quotations ----
alter table quotations add column if not exists number        text;
alter table quotations add column if not exists tax_mode      text not null default 'cgst_sgst';
alter table quotations add column if not exists place_of_supply text;
alter table quotations add column if not exists notes         text;
alter table quotations add column if not exists terms         text;

-- --------------------------------------------------------------- invoices ----
alter table invoices add column if not exists number         text;
alter table invoices add column if not exists subtotal       numeric(16,2) not null default 0;
alter table invoices add column if not exists tax_total      numeric(16,2) not null default 0;
alter table invoices add column if not exists discount_total numeric(16,2) not null default 0;
alter table invoices add column if not exists currency       char(3) not null default 'INR';
alter table invoices add column if not exists tax_mode       text not null default 'cgst_sgst';
alter table invoices add column if not exists place_of_supply text;
alter table invoices add column if not exists notes          text;
alter table invoices add column if not exists terms          text;
alter table invoices add column if not exists reminder_sent_at timestamptz;
alter table invoices add column if not exists credited_amount numeric(16,2) not null default 0;

-- A due date already exists; make overdue detectable without a scan of text.
create index if not exists invoices_due on invoices (org_id, due_date) where status <> 'paid';

-- --------------------------------------------------------------- payments ----
alter table payments add column if not exists invoice_id     uuid references invoices(id) on delete set null;
alter table payments add column if not exists currency       char(3) not null default 'INR';
alter table payments add column if not exists provider       text not null default 'manual';
alter table payments add column if not exists provider_ref   text;
alter table payments add column if not exists reference      text;
alter table payments add column if not exists notes          text;
alter table payments add column if not exists recorded_by    uuid references users(id);
alter table payments add column if not exists idempotency_key text;
create unique index if not exists payments_idem on payments (org_id, idempotency_key)
  where idempotency_key is not null;

create table if not exists payment_links (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid references invoices(id) on delete cascade,
  contact_id  uuid references contacts(id) on delete set null,
  token       text not null unique,
  amount      numeric(16,2) not null,
  currency    char(3) not null default 'INR',
  provider    text not null default 'manual',
  status      text not null default 'active' check (status in ('active','paid','expired','cancelled')),
  expires_at  timestamptz,
  paid_at     timestamptz,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now()
);

create table if not exists refunds (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  payment_id  uuid not null references payments(id) on delete cascade,
  amount      numeric(16,2) not null check (amount > 0),
  reason      text,
  status      text not null default 'pending' check (status in ('pending','processed','failed')),
  provider_ref text,
  created_by  uuid references users(id),
  created_at  timestamptz not null default now(),
  processed_at timestamptz
);

create table if not exists credit_notes (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references organisations(id) on delete cascade,
  invoice_id  uuid references invoices(id) on delete set null,
  contact_id  uuid references contacts(id) on delete set null,
  number      text not null,
  amount      numeric(16,2) not null check (amount > 0),
  reason      text,
  status      text not null default 'issued' check (status in ('issued','applied','void')),
  issued_at   timestamptz not null default now(),
  created_by  uuid references users(id)
);

-- --------------------------------------------------------------- webhooks ----
create table if not exists payment_events (
  id           uuid primary key default gen_random_uuid(),
  org_id       uuid not null references organisations(id) on delete cascade,
  provider     text not null,
  event_id     text not null,
  type         text not null,
  payload      jsonb not null default '{}',
  status       text not null default 'received' check (status in ('received','processed','failed','ignored')),
  error        text,
  received_at  timestamptz not null default now(),
  processed_at timestamptz,
  unique (provider, event_id)
);

-- --------------------------------------------------------------------- RLS ---
do $$
declare spec record;
begin
  for spec in select * from (values
      ('document_sequences','quotation',true),
      ('document_versions','quotation',false),
      ('payment_links','payment',true),
      ('refunds','payment',true),
      ('credit_notes','invoice',true),
      ('payment_events','payment',false)
    ) as v(tbl, perm, can_delete)
  loop
    execute format('alter table %I enable row level security', spec.tbl);
    execute format('alter table %I force row level security', spec.tbl);
    execute format('drop policy if exists %I on %I', spec.tbl || '_sel', spec.tbl);
    execute format('create policy %I on %I for select using (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_sel', spec.tbl, spec.perm || '.read');
    execute format('drop policy if exists %I on %I', spec.tbl || '_ins', spec.tbl);
    execute format('create policy %I on %I for insert with check (org_id = app.current_org() and app.has_perm(%L))',
      spec.tbl || '_ins', spec.tbl, spec.perm || '.write');
    execute format('drop policy if exists %I on %I', spec.tbl || '_upd', spec.tbl);
    execute format('create policy %I on %I for update using (org_id = app.current_org() and app.has_perm(%L)) with check (org_id = app.current_org())',
      spec.tbl || '_upd', spec.tbl, spec.perm || '.write');
    if spec.can_delete then
      execute format('drop policy if exists %I on %I', spec.tbl || '_del', spec.tbl);
      execute format('create policy %I on %I for delete using (org_id = app.current_org() and app.has_perm(%L))',
        spec.tbl || '_del', spec.tbl, spec.perm || '.delete');
    end if;
  end loop;
end $$;
