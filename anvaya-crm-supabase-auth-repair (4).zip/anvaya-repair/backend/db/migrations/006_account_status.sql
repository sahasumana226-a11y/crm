-- Additive account lifecycle flag; existing accounts remain active.
alter table users
  add column if not exists status text not null default 'active';

alter table users drop constraint if exists users_status_check;
alter table users add constraint users_status_check
  check (status in ('active', 'disabled', 'suspended'));

create index if not exists sessions_user_active_idx
  on sessions (user_id, expires_at)
  where revoked_at is null;

-- Prevent case-variant duplicate accounts during concurrent registration.
create unique index if not exists users_email_lower_uidx on users (lower(email));
