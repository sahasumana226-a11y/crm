import { initDb, migrate, databaseDiagnostics, closeDb } from '../src/db.js';

async function main() {
  await initDb();
  const applied = await migrate();
  const diagnostics = await databaseDiagnostics();
  if (diagnostics.schemaStatus !== 'valid') {
    throw new Error(`Schema verification failed: ${diagnostics.missingSchema.join(', ')}`);
  }
  console.log(JSON.stringify({
    status: 'verified',
    driver: diagnostics.driver,
    provider: diagnostics.provider,
    appliedMigrations: applied,
    migrationStatus: diagnostics.migrationStatus,
    schemaStatus: diagnostics.schemaStatus
  }, null, 2));
}

main().catch(err => {
  console.error('[migrate] failed', { code: err.code || 'MIGRATION_FAILED', message: err.message });
  process.exitCode = 1;
}).finally(async () => {
  await closeDb().catch(() => {});
});
