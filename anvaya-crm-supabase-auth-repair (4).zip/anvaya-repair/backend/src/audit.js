// Audit trail. Written on the system connection so application users can
// neither forge nor delete their own history (see 002_rls.sql).

import { q } from './db.js';

export async function writeAudit(ctx, { action, entity, entityId, before, after, ip }) {
  try {
    await q(
      `insert into audit_logs (org_id, actor_id, actor_name, action, entity, entity_id, before, after, ip)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
      [
        ctx.orgId, ctx.userId, ctx.fullName || ctx.email, action, entity || null, entityId || null,
        before ? JSON.stringify(before) : null,
        after ? JSON.stringify(after) : null,
        ip || null
      ]
    );
  } catch (err) {
    // Auditing must never break the request, but it must be visible in logs.
    console.error('[audit] failed:', err.message);
  }
}

export async function listAudit(ctx, { limit = 100, offset = 0 } = {}) {
  const rows = await q(
    `select id, actor_name, action, entity, entity_id, created_at, ip
       from audit_logs where org_id = $1 order by created_at desc limit $2 offset $3`,
    [ctx.orgId, Math.min(limit, 200), offset]
  );
  return rows;
}
