// ============================================================================
// Finance: payments, payment links, refunds, credit notes, invoice balances.
//
// Provider-independent. 'manual' always works (cash, bank transfer, UPI
// reference). Card gateways are adapters that only activate when their keys are
// configured — nothing pretends a gateway is live.
//
// Rule enforced here and nowhere else: invoice balances are computed on the
// server from payments minus refunds minus credit notes. The client never sends
// a total.
// ============================================================================

import crypto from 'node:crypto';
import { q, one, asUser } from './db.js';
import { requireAuth, requirePerm } from './auth.js';
import { writeAudit } from './audit.js';
import { computeTotals, nextNumber } from './documents.js';

let httpFetch = (...args) => fetch(...args);
export function __setFinanceFetch(fn) { httpFetch = fn; }

const PROVIDERS = {
  manual: { label: 'Manual / offline', configured: () => true, keys: [] },
  razorpay: {
    label: 'Razorpay',
    keys: ['RAZORPAY_KEY_ID', 'RAZORPAY_KEY_SECRET', 'PAYMENT_WEBHOOK_SECRET'],
    configured: () => Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET)
  },
  stripe: {
    label: 'Stripe',
    keys: ['STRIPE_SECRET_KEY', 'PAYMENT_WEBHOOK_SECRET'],
    configured: () => Boolean(process.env.STRIPE_SECRET_KEY)
  }
};

export function providers() {
  return Object.entries(PROVIDERS).map(([key, p]) => ({
    key, label: p.label, configured: p.configured(),
    missing: p.keys.filter((k) => !process.env[k])
  }));
}

/* ------------------------------------------------------------- balances ---- */
export async function recalculateInvoice(ctx, invoiceId) {
  return asUser(ctx, async (t) => {
    const invoice = await t.one(`select * from invoices where id = $1`, [invoiceId]);
    if (!invoice) return null;

    const paidRow = await t.one(
      `select coalesce(sum(amount),0) as paid from payments
        where invoice_id = $1 and status = 'succeeded'`, [invoiceId]);
    const refundRow = await t.one(
      `select coalesce(sum(r.amount),0) as refunded from refunds r
         join payments p on p.id = r.payment_id
        where p.invoice_id = $1 and r.status = 'processed'`, [invoiceId]);
    const creditRow = await t.one(
      `select coalesce(sum(amount),0) as credited from credit_notes
        where invoice_id = $1 and status <> 'void'`, [invoiceId]);

    const paid = Number(paidRow.paid) - Number(refundRow.refunded);
    const credited = Number(creditRow.credited);
    const amount = Number(invoice.total || 0);
    const outstanding = Math.max(Math.round((amount - paid - credited) * 100) / 100, 0);

    // The status vocabulary is the one the V5 schema already enforces.
    const today = new Date();
    const due = invoice.due_date ? new Date(invoice.due_date) : null;
    let status;
    if (outstanding <= 0.009) status = 'paid';
    else if (paid > 0) status = 'partially_paid';
    else if (due && due < today) status = 'overdue';
    else status = invoice.status === 'draft' ? 'draft' : 'sent';

    await t.q(
      `update invoices set amount_paid = $2, credited_amount = $3, status = $4, updated_at = now() where id = $1`,
      [invoiceId, Math.max(paid, 0), credited, status]);

    return { amount, paid: Math.max(paid, 0), credited, outstanding, status, currency: invoice.currency || 'INR' };
  });
}

/* ------------------------------------------------------------- payments ---- */
export async function recordPayment(ctx, body) {
  const { invoiceId, amount, method = 'bank_transfer', provider = 'manual', reference, notes, receivedAt, idempotencyKey } = body || {};
  if (!invoiceId) throw Object.assign(new Error('Choose the invoice this payment settles'), { status: 400 });
  const value = Number(amount);
  if (!Number.isFinite(value) || value <= 0) throw Object.assign(new Error('A payment needs a positive amount'), { status: 400 });
  if (!PROVIDERS[provider]) throw Object.assign(new Error('Unknown payment provider'), { status: 400 });

  const invoice = await asUser(ctx, (t) => t.one(`select * from invoices where id = $1`, [invoiceId]));
  if (!invoice) throw Object.assign(new Error('Invoice not found'), { status: 404 });

  if (idempotencyKey) {
    const existing = await asUser(ctx, (t) => t.one(
      `select * from payments where idempotency_key = $1`, [idempotencyKey]));
    if (existing) return { payment: existing, duplicate: true, balance: await recalculateInvoice(ctx, invoiceId) };
  }

  const row = await asUser(ctx, (t) => t.one(
    `insert into payments (org_id, invoice_id, amount, currency, method, provider, reference, notes,
                           status, received_at, recorded_by, idempotency_key)
     values ($1,$2,$3,$4,$5,$6,$7,$8,'succeeded',$9,$10,$11) returning *`,
    [ctx.orgId, invoiceId, value, invoice.currency || 'INR', method, provider, reference || null,
      notes || null, receivedAt || new Date(), ctx.userId, idempotencyKey || null]));

  const balance = await recalculateInvoice(ctx, invoiceId);

  if (invoice.contact_id) {
    await asUser(ctx, (t) => t.q(
      `insert into activities (org_id, type, subject, body, contact_id, company_id, occurred_at)
       values ($1,'note',$2,$3,$4,$5, now())`,
      [ctx.orgId, `Payment received — ${(invoice.number || 'invoice')}`, `${balance.currency} ${value.toLocaleString('en-IN')} by ${method}`,
        invoice.contact_id, invoice.company_id]));
  }
  await writeAudit(ctx, { action: 'payment.recorded', entity: 'payment', entityId: row.id, after: { invoiceId, amount: value, provider } });
  return { payment: row, balance };
}

/** POST /api/invoices with line items — number, totals and balance in one go. */
export async function createInvoiceWithItems(ctx, body) {
  const { items = [], contactId, companyId, quotationId, dueDate, issueDate, taxMode = 'cgst_sgst',
    discount = 0, notes, terms, currency = 'INR', placeOfSupply } = body || {};
  if (!items.length) throw Object.assign(new Error('An invoice needs at least one line item'), { status: 400 });

  const totals = computeTotals(items, { discount, taxMode, currency });
  const number = await nextNumber(ctx, 'invoice');
  const due = dueDate || new Date(Date.now() + 15 * 86400000).toISOString().slice(0, 10);

  const invoice = await asUser(ctx, async (t) => {
    const row = await t.one(
      `insert into invoices (org_id, quotation_id, contact_id, company_id, number, status, issue_date, due_date,
                             total, subtotal, tax_total, discount_total, currency, tax_mode, place_of_supply,
                             notes, terms, amount_paid)
       values ($1,$2,$3,$4,$5,'sent',$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,0) returning *`,
      [ctx.orgId, quotationId || null, contactId || null, companyId || null, number,
        issueDate || new Date().toISOString().slice(0, 10), due, totals.total, totals.subtotal,
        totals.tax_total, totals.discount_total, currency, taxMode, placeOfSupply || null, notes || null, terms || null]);

    for (const l of totals.lines) {
      await t.q(
        `insert into invoice_items (org_id, invoice_id, description, qty, unit_price, tax_rate, line_total, position)
         values ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [ctx.orgId, row.id, l.description, l.quantity, l.unit_price, l.tax_rate, l.taxable, l.position]);
    }
    return row;
  });

  await writeAudit(ctx, { action: 'invoice.created', entity: 'invoice', entityId: invoice.id, after: { number, total: totals.total } });
  return { invoice, totals, balance: await recalculateInvoice(ctx, invoice.id) };
}

/* --------------------------------------------------------- payment links --- */
export async function createPaymentLink(ctx, invoiceId) {
  const invoice = await asUser(ctx, (t) => t.one(`select * from invoices where id = $1`, [invoiceId]));
  if (!invoice) throw Object.assign(new Error('Invoice not found'), { status: 404 });
  const balance = await recalculateInvoice(ctx, invoiceId);
  if (balance.outstanding <= 0) throw Object.assign(new Error('This invoice is already settled'), { status: 409 });

  const provider = PROVIDERS.razorpay.configured() ? 'razorpay'
    : PROVIDERS.stripe.configured() ? 'stripe' : 'manual';
  const token = crypto.randomBytes(18).toString('base64url');

  let remoteUrl = null;
  if (provider === 'razorpay') {
    const auth = Buffer.from(`${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`).toString('base64');
    const res = await httpFetch('https://api.razorpay.com/v1/payment_links', {
      method: 'POST',
      headers: { authorization: `Basic ${auth}`, 'content-type': 'application/json' },
      body: JSON.stringify({ amount: Math.round(balance.outstanding * 100), currency: invoice.currency || 'INR', reference_id: invoice.number })
    });
    if (!res.ok) throw Object.assign(new Error(`Razorpay refused the link (${res.status})`), { status: 502 });
    remoteUrl = (await res.json()).short_url;
  } else if (provider === 'stripe') {
    const res = await httpFetch('https://api.stripe.com/v1/payment_links', {
      method: 'POST',
      headers: { authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ 'line_items[0][price_data][currency]': (invoice.currency || 'INR').toLowerCase(), 'line_items[0][price_data][product_data][name]': `Invoice ${invoice.number}`, 'line_items[0][price_data][unit_amount]': String(Math.round(balance.outstanding * 100)), 'line_items[0][quantity]': '1' }).toString()
    });
    if (!res.ok) throw Object.assign(new Error(`Stripe refused the link (${res.status})`), { status: 502 });
    remoteUrl = (await res.json()).url;
  }

  const row = await asUser(ctx, (t) => t.one(
    `insert into payment_links (org_id, invoice_id, contact_id, token, amount, currency, provider, expires_at, created_by)
     values ($1,$2,$3,$4,$5,$6,$7, now() + interval '30 days', $8) returning *`,
    [ctx.orgId, invoiceId, invoice.contact_id, token, balance.outstanding, invoice.currency || 'INR', provider, ctx.userId]));

  const base = process.env.PUBLIC_APP_URL || process.env.PUBLIC_API_URL || '';
  return {
    link: remoteUrl || `${base}/pay/${token}`,
    provider,
    amount: balance.outstanding,
    note: provider === 'manual'
      ? 'No gateway is configured, so this is an internal link you can share; mark the payment manually when it arrives.'
      : null
  };
}

/* ---------------------------------------------------------------- refunds --- */
export async function refundPayment(ctx, paymentId, body) {
  const { amount, reason } = body || {};
  const payment = await asUser(ctx, (t) => t.one(`select * from payments where id = $1`, [paymentId]));
  if (!payment) throw Object.assign(new Error('Payment not found'), { status: 404 });

  const already = await asUser(ctx, (t) => t.one(
    `select coalesce(sum(amount),0) as refunded from refunds where payment_id = $1 and status = 'processed'`,
    [paymentId]));
  const remaining = Number(payment.amount) - Number(already.refunded);
  const value = Number(amount || remaining);
  if (!Number.isFinite(value) || value <= 0) throw Object.assign(new Error('Refund amount must be positive'), { status: 400 });
  if (value > remaining + 0.009) {
    throw Object.assign(new Error(`Only ${remaining.toFixed(2)} of this payment can still be refunded`), { status: 400 });
  }

  const row = await asUser(ctx, (t) => t.one(
    `insert into refunds (org_id, payment_id, amount, reason, status, created_by, processed_at)
     values ($1,$2,$3,$4,'processed',$5, now()) returning *`,
    [ctx.orgId, paymentId, value, reason || null, ctx.userId]));

  const balance = payment.invoice_id ? await recalculateInvoice(ctx, payment.invoice_id) : null;
  await writeAudit(ctx, { action: 'refund.recorded', entity: 'payment', entityId: paymentId, after: { amount: value } });
  return { refund: row, balance };
}

/* ----------------------------------------------------------- credit note --- */
export async function issueCreditNote(ctx, invoiceId, body) {
  const { amount, reason } = body || {};
  const invoice = await asUser(ctx, (t) => t.one(`select * from invoices where id = $1`, [invoiceId]));
  if (!invoice) throw Object.assign(new Error('Invoice not found'), { status: 404 });
  const value = Number(amount);
  if (!Number.isFinite(value) || value <= 0) throw Object.assign(new Error('A credit note needs a positive amount'), { status: 400 });

  const number = await nextNumber(ctx, 'credit_note');
  const row = await asUser(ctx, (t) => t.one(
    `insert into credit_notes (org_id, invoice_id, contact_id, number, amount, reason, created_by)
     values ($1,$2,$3,$4,$5,$6,$7) returning *`,
    [ctx.orgId, invoiceId, invoice.contact_id, number, value, reason || null, ctx.userId]));

  const balance = await recalculateInvoice(ctx, invoiceId);
  await writeAudit(ctx, { action: 'credit_note.issued', entity: 'invoice', entityId: invoiceId, after: { number, amount: value } });
  return { creditNote: row, balance };
}

/* -------------------------------------------------------------- webhooks --- */
export async function handlePaymentWebhook(provider, req) {
  const p = PROVIDERS[provider];
  if (!p) return { status: 404, body: { error: 'Unknown provider' } };
  const secret = process.env.PAYMENT_WEBHOOK_SECRET;
  if (!secret) {
    return { status: 503, body: { error: 'PAYMENT_WEBHOOK_SECRET is not set, so the signature cannot be verified' } };
  }

  const raw = req.rawBody ? req.rawBody.toString('utf8') : JSON.stringify(req.body || {});
  const provided = provider === 'razorpay'
    ? req.headers['x-razorpay-signature']
    : req.headers['stripe-signature'] || req.headers['x-anvaya-signature'];
  const expected = crypto.createHmac('sha256', secret).update(raw).digest('hex');
  const a = Buffer.from(String(provided || ''));
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return { status: 401, body: { error: 'Bad signature' } };
  }

  const body = req.body || {};
  const eventId = String(body.id || body.event_id || body.eventId || crypto.createHash('sha256').update(raw).digest('hex').slice(0, 32));
  const type = String(body.event || body.type || 'payment.unknown');
  const orgId = body.org_id || req.query.org;

  const seen = await one(`select id, status from payment_events where provider = $1 and event_id = $2`, [provider, eventId]);
  if (seen?.status === 'processed') return { status: 200, body: { ok: true, duplicate: true } };

  await one(
    `insert into payment_events (org_id, provider, event_id, type, payload)
     values ($1,$2,$3,$4,$5) on conflict (provider, event_id) do nothing`,
    [orgId, provider, eventId, type, JSON.stringify(body)]);

  const row = await one(`select id from payment_events where provider = $1 and event_id = $2`, [provider, eventId]);

  try {
    const invoiceId = body.invoice_id || body.payload?.payment?.entity?.notes?.invoice_id || null;
    const amount = Number(body.amount || body.payload?.payment?.entity?.amount || 0) / (body.amount ? 1 : 100);
    if (invoiceId && amount > 0) {
      // A webhook has no session. Run it as the workspace's first active member
      // so RLS and the audit trail still have a real actor.
      const actor = await one(
        `select m.user_id, m.id as member_id from members m
          where m.org_id = $1 and m.status = 'active' order by m.created_at limit 1`, [orgId]);
      if (actor) {
        await recordPayment(
          { orgId, userId: actor.user_id, memberId: actor.member_id, perms: ['*'], fullName: `${provider} webhook` },
          { invoiceId, amount, method: 'gateway', provider, reference: eventId, idempotencyKey: `${provider}:${eventId}` }
        );
      }
    }
    await one(`update payment_events set status = 'processed', processed_at = now() where id = $1`, [row.id]);
  } catch (err) {
    await one(`update payment_events set status = 'failed', error = $2 where id = $1`, [row.id, err.message]);
    return { status: 500, body: { error: 'Stored but not applied', detail: err.message } };
  }
  return { status: 200, body: { ok: true } };
}

/* ------------------------------------------------------------------ mount --- */
export function mountFinance(app, { wrap, bad }) {
  app.get('/api/finance/providers', requireAuth, wrap(async (req, res) => {
    res.json({ data: providers() });
  }));

  app.post('/api/invoices', requireAuth, requirePerm('invoice.write'), wrap(async (req, res) => {
    res.status(201).json(await createInvoiceWithItems(req.ctx, req.body));
  }));

  app.get('/api/invoices/:id/finance', requireAuth, requirePerm('invoice.read'), wrap(async (req, res) => {
    const balance = await recalculateInvoice(req.ctx, req.params.id);
    if (!balance) throw bad('Invoice not found', 404);
    const [payments, refunds, notes] = await Promise.all([
      asUser(req.ctx, (t) => t.q(`select * from payments where invoice_id = $1 order by received_at desc`, [req.params.id])),
      asUser(req.ctx, (t) => t.q(
        `select r.* from refunds r join payments p on p.id = r.payment_id where p.invoice_id = $1 order by r.created_at desc`, [req.params.id])),
      asUser(req.ctx, (t) => t.q(`select * from credit_notes where invoice_id = $1 order by issued_at desc`, [req.params.id]))
    ]);
    res.json({ balance, payments, refunds, creditNotes: notes });
  }));

  app.post('/api/invoices/:id/payments', requireAuth, requirePerm('payment.write'), wrap(async (req, res) => {
    res.status(201).json(await recordPayment(req.ctx, { ...req.body, invoiceId: req.params.id }));
  }));

  app.post('/api/invoices/:id/payment-link', requireAuth, requirePerm('invoice.write'), wrap(async (req, res) => {
    res.status(201).json(await createPaymentLink(req.ctx, req.params.id));
  }));

  app.post('/api/invoices/:id/credit-note', requireAuth, requirePerm('invoice.write'), wrap(async (req, res) => {
    res.status(201).json(await issueCreditNote(req.ctx, req.params.id, req.body));
  }));

  app.post('/api/payments/:id/refund', requireAuth, requirePerm('payment.write'), wrap(async (req, res) => {
    res.status(201).json(await refundPayment(req.ctx, req.params.id, req.body));
  }));

  app.get('/api/payments', requireAuth, requirePerm('payment.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select p.*, i.number as invoice_number, c.first_name || ' ' || c.last_name as contact_name
         from payments p
         left join invoices i on i.id = p.invoice_id
         left join contacts c on c.id = i.contact_id
        order by p.received_at desc limit 200`));
    res.json({ data: rows });
  }));

  app.get('/api/finance/summary', requireAuth, requirePerm('invoice.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select status, count(*)::int as invoices, coalesce(sum(total),0) as billed,
              coalesce(sum(total - amount_paid - credited_amount),0) as outstanding
         from invoices group by status`));
    const collected = await asUser(req.ctx, (t) => t.one(
      `select coalesce(sum(amount),0) as collected from payments
        where status = 'succeeded' and received_at >= date_trunc('month', now())`));
    const overdue = await asUser(req.ctx, (t) => t.q(
      `select id, number, contact_id, total, amount_paid, due_date from invoices
        where status <> 'paid' and due_date < current_date order by due_date limit 20`));
    res.json({ byStatus: rows, collectedThisMonth: collected.collected, overdue });
  }));

  app.post('/api/webhooks/payments/:provider', wrap(async (req, res) => {
    const out = await handlePaymentWebhook(req.params.provider, req);
    res.status(out.status).json(out.body);
  }));
}
