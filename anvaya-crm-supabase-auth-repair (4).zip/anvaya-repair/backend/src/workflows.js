// Workflow engine.
//
// Trigger -> conditions -> actions -> approval -> execution.
// Runs as the triggering user, so a workflow can never read or write outside
// that user's permissions. Every run and every step is logged.

import { asUser, q, one } from './db.js';
import { writeAudit } from './audit.js';

export const TRIGGER_EVENTS = [
  'lead.created', 'lead.status_changed',
  'deal.created', 'deal.stage_changed', 'deal.won',
  'contact.created', 'ticket.created', 'invoice.overdue',
  'task.overdue', 'customer.inactive', 'schedule', 'webhook'
];

export const ACTION_TYPES = ['create_task', 'notify', 'update_field', 'log_activity', 'send_email', 'call_webhook'];

const OPS = {
  eq: (a, b) => String(a) === String(b),
  neq: (a, b) => String(a) !== String(b),
  gt: (a, b) => Number(a) > Number(b),
  lt: (a, b) => Number(a) < Number(b),
  gte: (a, b) => Number(a) >= Number(b),
  lte: (a, b) => Number(a) <= Number(b),
  contains: (a, b) => String(a || '').toLowerCase().includes(String(b).toLowerCase()),
  in: (a, b) => (Array.isArray(b) ? b : String(b).split(',')).map(String).includes(String(a)),
  is_empty: (a) => a === null || a === undefined || a === ''
};

export function evaluateConditions(conditions, record) {
  if (!Array.isArray(conditions) || !conditions.length) return { pass: true, detail: [] };
  const detail = conditions.map(c => {
    const op = OPS[c.op] || OPS.eq;
    const value = record[c.field];
    const pass = op(value, c.value);
    return { field: c.field, op: c.op, expected: c.value, actual: value, pass };
  });
  return { pass: detail.every(d => d.pass), detail };
}

/** Run one workflow against one record. */
export async function runWorkflow(ctx, workflow, record, triggerEntity, triggerId) {
  const started = Date.now();
  const cond = evaluateConditions(workflow.conditions, record || {});

  const run = await asUser(ctx, (t) => t.one(
    `insert into workflow_runs (org_id, workflow_id, workflow_version, trigger_entity, trigger_id, status, context)
     values ($1,$2,$3,$4,$5,$6,$7) returning *`,
    [ctx.orgId, workflow.id, workflow.version, triggerEntity, triggerId,
      cond.pass ? 'running' : 'skipped', JSON.stringify({ conditions: cond.detail })]
  ));

  if (!cond.pass) {
    await asUser(ctx, (t) => t.q(
      `update workflow_runs set status='skipped', finished_at=now() where id=$1`, [run.id]
    ));
    return { runId: run.id, status: 'skipped', steps: [] };
  }

  const steps = [];
  let status = 'succeeded';

  for (const [i, action] of (workflow.actions || []).entries()) {
    try {
      const out = await executeAction(ctx, action, record, triggerEntity, triggerId);
      steps.push({ index: i, type: action.type, status: out.status || 'succeeded', output: out });
      await asUser(ctx, (t) => t.q(
        `insert into workflow_steps (org_id, run_id, step_index, node_type, status, output)
         values ($1,$2,$3,$4,$5,$6)`,
        [ctx.orgId, run.id, i, action.type, out.status || 'succeeded', JSON.stringify(out)]
      ));
      if (out.status === 'awaiting_approval') status = 'awaiting_approval';
    } catch (err) {
      status = 'failed';
      steps.push({ index: i, type: action.type, status: 'failed', error: err.message });
      await asUser(ctx, (t) => t.q(
        `insert into workflow_steps (org_id, run_id, step_index, node_type, status, error)
         values ($1,$2,$3,$4,'failed',$5)`,
        [ctx.orgId, run.id, i, action.type, err.message]
      ));
      break;
    }
  }

  await asUser(ctx, (t) => t.q(
    `update workflow_runs set status=$2, finished_at=now() where id=$1`, [run.id, status]
  ));
  await asUser(ctx, (t) => t.q(
    `update workflows set run_count = run_count + 1, last_run_at = now() where id = $1`, [workflow.id]
  ));
  await writeAudit(ctx, {
    action: `workflow.${status}`, entity: 'workflow', entityId: workflow.id,
    after: { runId: run.id, trigger: workflow.trigger, ms: Date.now() - started }
  });

  return { runId: run.id, status, steps };
}

async function executeAction(ctx, action, record, entity, entityId) {
  switch (action.type) {
    case 'create_task': {
      const row = await asUser(ctx, (t) => t.one(
        `insert into tasks (org_id, title, notes, due_date, priority, assignee_id, related_type, related_id, created_by)
         values ($1,$2,$3, current_date + ($4 || ' days')::interval, $5,$6,$7,$8,$9) returning id, title`,
        [
          ctx.orgId,
          String(action.title || 'Follow up').replace(/\{\{(\w+)\}\}/g, (_, k) => record?.[k] ?? ''),
          action.notes || null,
          Number(action.dueInDays ?? 2),
          action.priority || 'medium',
          action.assigneeId || record?.owner_id || ctx.memberId,
          entity, entityId, ctx.userId
        ]
      ));
      return { status: 'succeeded', taskId: row.id, title: row.title };
    }
    case 'notify': {
      await asUser(ctx, (t) => t.q(
        `insert into notifications (org_id, user_id, type, title, body, link)
         values ($1,$2,'workflow',$3,$4,$5)`,
        [ctx.orgId, action.userId || ctx.userId, action.title || 'Workflow notification',
          action.body || null, action.link || null]
      ));
      return { status: 'succeeded', notified: action.userId || ctx.userId };
    }
    case 'update_field': {
      const allowed = { leads: 'leads', deals: 'deals', contacts: 'contacts', companies: 'companies', tickets: 'tickets' };
      const table = allowed[action.entity || entity];
      const field = String(action.field || '');
      if (!table || !/^[a-z_][a-z0-9_]*$/.test(field)) throw new Error('Unsupported field update');
      const row = await asUser(ctx, (t) => t.one(
        `update ${table} set ${field} = $2 where id = $1 returning id`, [entityId, action.value]
      ));
      if (!row) throw new Error('Record not found for update');
      return { status: 'succeeded', updated: field, value: action.value };
    }
    case 'log_activity': {
      const row = await asUser(ctx, (t) => t.one(
        `insert into activities (org_id, type, subject, body, contact_id, deal_id, owner_id, created_by)
         values ($1,$2,$3,$4,$5,$6,$7,$8) returning id`,
        [ctx.orgId, action.activityType || 'note', action.subject || 'Workflow activity',
          action.body || null,
          entity === 'contact' ? entityId : record?.contact_id || null,
          entity === 'deal' ? entityId : null,
          ctx.memberId, ctx.userId]
      ));
      return { status: 'succeeded', activityId: row.id };
    }
    case 'send_email': {
      // Never claim an email was sent. Record it as pending approval instead.
      const row = await asUser(ctx, (t) => t.one(
        `insert into ai_actions (org_id, action, target_table, target_id, payload, status)
         values ($1,'send_email',$2,$3,$4,'proposed') returning id`,
        [ctx.orgId, entity, entityId, JSON.stringify({ to: action.to, subject: action.subject, body: action.body })]
      ));
      return { status: 'awaiting_approval', actionId: row.id, note: 'Email queued for human approval' };
    }
    case 'call_webhook': {
      if (!process.env.WEBHOOK_ALLOWLIST) {
        throw new Error('Outbound webhooks are disabled: set WEBHOOK_ALLOWLIST to enable');
      }
      const url = String(action.url || '');
      const allowed = process.env.WEBHOOK_ALLOWLIST.split(',').map(s => s.trim()).filter(Boolean);
      if (!allowed.some(host => { try { return new URL(url).host === host; } catch { return false; } })) {
        throw new Error('Webhook host not in allowlist');
      }
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ event: `${entity}.triggered`, record, at: new Date().toISOString() })
      });
      return { status: res.ok ? 'succeeded' : 'failed', httpStatus: res.status };
    }
    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
}

/** Fire all active workflows subscribed to an event. */
export async function trigger(event, ctx, record, entityId) {
  try {
    const workflows = await asUser(ctx, (t) => t.q(
      `select * from workflows where status = 'active' and trigger->>'event' = $1`, [event]
    ));
    const results = [];
    for (const wf of workflows) {
      results.push({ workflow: wf.name, ...(await runWorkflow(ctx, wf, record, event.split('.')[0], entityId)) });
    }
    return results;
  } catch (err) {
    console.error('[workflow] trigger failed:', err.message);
    return [];
  }
}

export async function listRuns(ctx, workflowId) {
  return asUser(ctx, async (t) => {
    const runs = await t.q(
      `select r.*, w.name as workflow_name from workflow_runs r join workflows w on w.id = r.workflow_id
        where ($1::uuid is null or r.workflow_id = $1) order by r.started_at desc limit 50`,
      [workflowId || null]
    );
    return runs;
  });
}

export async function runSteps(ctx, runId) {
  return asUser(ctx, (t) => t.q(
    `select * from workflow_steps where run_id = $1 order by step_index`, [runId]
  ));
}
