import { createApp } from './app.js';
import { initDb, migrate } from './db.js';

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

const app = createApp();

async function boot() {
  await initDb();

  if (process.env.AUTO_MIGRATE === '1') {
    const files = await migrate();
    console.log(`[db] applied ${files.length} pending migration(s)`);
  }
  if (process.env.NODE_ENV !== 'production' && process.env.SEED_DEMO === '1') {
    await runSeed();
    console.log('[db] explicit development demo seed completed');
  }

  app.listen(PORT, HOST, () => {
    console.log(`Anvaya CRM listening on http://${HOST}:${PORT}`);
    console.log(`AI provider: ${process.env.AI_API_KEY ? 'configured' : 'local rules (no model configured)'}`);
  });
}

boot().catch(err => {
  console.error('Failed to start:', err);
  process.exit(1);
});
