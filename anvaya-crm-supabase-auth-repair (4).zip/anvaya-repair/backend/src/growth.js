// ============================================================================
// Growth features: lead capture, API access, outbound webhooks, saved views.
//
// Everything here is optional infrastructure around the CRM: nothing in the
// core app depends on it, and every endpoint states plainly when it needs
// configuration the operator has not supplied yet.
// ============================================================================

import crypto from 'node:crypto';
import { q, one, asUser } from './db.js';
import { requireAuth, requirePerm } from './auth.js';
import { writeAudit } from './audit.js';
import { trigger } from './workflows.js';

// ---------------------------------------------------------------- helpers ---
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const hmac = (secret, body) => crypto.createHmac('sha256', secret).update(body).digest('hex');
const safeEqual = (a, b) => {
  const A = Buffer.from(String(a));
  const B = Buffer.from(String(b));
  return A.length === B.length && crypto.timingSafeEqual(A, B);
};

const ENTITIES = ['lead', 'contact', 'company', 'deal', 'pipeline', 'activity', 'task', 'ticket',
  'campaign', 'product', 'quotation', 'invoice', 'payment', 'project', 'workflow', 'ai',
  'settings', 'billing', 'integration', 'member', 'workspace', 'notification'];
const READ_PERMS = ENTITIES.map((e) => `${e}.read`);
const WRITE_PERMS = ENTITIES.map((e) => `${e}.write`);

function permsForScope(scope) {
  if (scope === 'admin') return ['*'];
  if (scope === 'write') return [...new Set([...READ_PERMS, ...WRITE_PERMS])];
  return READ_PERMS;
}

/** AES-256-GCM, so provider tokens are never stored in clear text. */
function encryptionKey() {
  const pass = process.env.ENCRYPTION_KEY;
  if (!pass || pass.length < 32) return null;
  return crypto.createHash('sha256').update(pass).digest();   // 32 bytes for aes-256-gcm
}

export function encrypt(plain) {
  const key = encryptionKey();
  if (!key) return null;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  return `${iv.toString('base64')}.${enc.toString('base64')}.${cipher.getAuthTag().toString('base64')}`;
}

export function decrypt(blob) {
  const key = encryptionKey();
  if (!key || !blob) return null;
  try {
    const [ivB, dataB, tagB] = String(blob).split('.');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivB, 'base64'));
    decipher.setAuthTag(Buffer.from(tagB, 'base64'));
    return Buffer.concat([decipher.update(Buffer.from(dataB, 'base64')), decipher.final()]).toString('utf8');
  } catch {
    return null;
  }
}

// ------------------------------------------------------------- rate limit ---
const buckets = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now();
  const entry = buckets.get(key) || { count: 0, reset: now + windowMs };
  if (now > entry.reset) { entry.count = 0; entry.reset = now + windowMs; }
  entry.count += 1;
  buckets.set(key, entry);
  if (buckets.size > 5000) buckets.clear();
  return entry.count <= max;
}

// ------------------------------------------------------------ webhooks out --
const WEBHOOK_EVENTS = [
  'lead.created', 'lead.converted', 'contact.created', 'deal.created',
  'deal.stage_changed', 'deal.won', 'ticket.created', 'invoice.paid'
];

/** Fire every webhook subscribed to an event. Never throws. */
export async function dispatchEvent(orgId, event, payload) {
  try {
    const hooks = await q(
      `select * from webhooks where org_id = $1 and is_active = true
         and (events @> $2::text[] or events @> '{"*"}')`,
      [orgId, [event]]
    );
    for (const hook of hooks) {
      const body = JSON.stringify({ event, at: new Date().toISOString(), data: payload });
      const signature = hmac(hook.secret, body);
      let status = 'failed';
      let code = null;
      let error = null;
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 5000);
        const res = await fetch(hook.url, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-anvaya-event': event,
            'x-anvaya-signature': `sha256=${signature}`
          },
          body,
          signal: controller.signal
        });
        clearTimeout(timer);
        code = res.status;
        status = res.ok ? 'delivered' : 'failed';
        if (!res.ok) error = `HTTP ${res.status}`;
      } catch (err) {
        error = err.name === 'AbortError' ? 'Timed out after 5s' : err.message;
      }
      await q(
        `insert into webhook_deliveries (org_id, webhook_id, event, payload, status, response_code, error)
         values ($1,$2,$3,$4,$5,$6,$7)`,
        [orgId, hook.id, event, body, status, code, error]
      );
      await q(
        `update webhooks set last_status = $2, last_error = $3, last_fired_at = now(),
                failure_count = case when $2 = 'failed' then failure_count + 1 else 0 end
          where id = $1`,
        [hook.id, status, error]
      );
    }
  } catch (err) {
    console.error('[webhooks] dispatch failed:', err.message);
  }
}

// ------------------------------------------------------------------- mount ---
export function mountGrowth(app, { wrap, bad }) {
  /* ======================================================== API key auth == */
  app.use(wrap(async (req, res, next) => {
    const header = req.headers.authorization || '';
    if (!header.startsWith('Bearer ak_')) return next();
    const presented = header.slice(7).trim();
    const row = await one(
      `select k.*, o.name as org_name from api_keys k
         join organisations o on o.id = k.org_id
        where k.key_hash = $1 and k.revoked_at is null`,
      [sha256(presented)]
    );
    if (!row) return res.status(401).json({ error: 'Invalid or revoked API key' });
    q(`update api_keys set last_used_at = now(), request_count = request_count + 1 where id = $1`, [row.id])
      .catch(() => {});
    req.ctx = {
      orgId: row.org_id,
      orgName: row.org_name,
      userId: row.created_by,
      email: 'api-key',
      fullName: `API key · ${row.name}`,
      memberId: null,
      perms: permsForScope((row.scopes || ['read'])[0]),
      apiKey: true,
      memberships: []
    };
    next();
  }));

  /* ============================================================ web forms == */
  app.get('/api/web-forms', requireAuth, requirePerm('settings.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select f.*, (select count(*) from form_submissions s where s.form_id = f.id)::int as submissions
         from web_forms f order by f.created_at desc`
    ));
    res.json({ data: rows });
  }));

  app.post('/api/web-forms', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    const b = req.body || {};
    if (!b.name) throw bad('A form name is required');
    const slug = (b.slug || b.name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40)
      + '-' + crypto.randomBytes(3).toString('hex');
    const row = await asUser(req.ctx, (t) => t.one(
      `insert into web_forms (org_id, name, slug, headline, description, fields, required,
                              success_message, redirect_url, default_source, owner_id, created_by)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) returning *`,
      [req.ctx.orgId, b.name, slug, b.headline || 'Talk to us', b.description || null,
        JSON.stringify(b.fields || ['name', 'email', 'phone', 'company_name', 'message']),
        JSON.stringify(b.required || ['name']), b.successMessage || 'Thank you — we will be in touch shortly.',
        b.redirectUrl || null, b.defaultSource || 'web_form', req.ctx.memberId, req.ctx.userId]
    ));
    await writeAudit(req.ctx, { action: 'web_form.created', entity: 'web_form', entityId: row.id, after: row });
    res.status(201).json(row);
  }));

  app.patch('/api/web-forms/:id', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    const b = req.body || {};
    const row = await asUser(req.ctx, (t) => t.one(
      `update web_forms set name = coalesce($2,name), is_active = coalesce($3,is_active),
              headline = coalesce($4,headline), success_message = coalesce($5,success_message)
        where id = $1 returning *`,
      [req.params.id, b.name ?? null, typeof b.isActive === 'boolean' ? b.isActive : null,
        b.headline ?? null, b.successMessage ?? null]
    ));
    if (!row) throw bad('Form not found', 404);
    res.json(row);
  }));

  app.delete('/api/web-forms/:id', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    await asUser(req.ctx, (t) => t.q(`delete from web_forms where id = $1`, [req.params.id]));
    res.json({ ok: true });
  }));

  /** The snippet an operator pastes into their own site. */
  app.get('/api/web-forms/:id/embed', requireAuth, requirePerm('settings.read'), wrap(async (req, res) => {
    const form = await asUser(req.ctx, (t) => t.one(`select * from web_forms where id = $1`, [req.params.id]));
    if (!form) throw bad('Form not found', 404);
    const base = process.env.PUBLIC_API_URL || `${req.protocol}://${req.get('host')}`;
    const action = `${base}/api/public/forms/${form.slug}`;
    const fields = form.fields || [];
    const labels = {
      name: 'Your name', email: 'Email', phone: 'Phone', company_name: 'Company',
      message: 'How can we help?', city: 'City'
    };
    const inputs = fields.map((f) => f === 'message'
      ? `  <textarea name="message" rows="3" placeholder="${labels[f] || f}"></textarea>`
      : `  <input name="${f}" type="${f === 'email' ? 'email' : f === 'phone' ? 'tel' : 'text'}" placeholder="${labels[f] || f}"${(form.required || []).includes(f) ? ' required' : ''}>`
    ).join('\n');
    const html = `<!-- Anvaya CRM form: ${form.name} -->
<form id="anvaya-form" action="${action}" method="post">
${inputs}
  <input name="_hp" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">
  <button type="submit">${form.headline || 'Send'}</button>
</form>
<p id="anvaya-msg" role="status"></p>
<script>
document.getElementById('anvaya-form').addEventListener('submit', async function (e) {
  e.preventDefault();
  var form = e.target, msg = document.getElementById('anvaya-msg');
  var data = Object.fromEntries(new FormData(form).entries());
  try {
    var res = await fetch(form.action, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(data)
    });
    var body = await res.json();
    msg.textContent = body.message || (res.ok ? 'Thank you.' : 'Something went wrong.');
    if (res.ok) form.reset();
  } catch (err) { msg.textContent = 'Could not reach the server.'; }
});
</script>`;
    res.json({
      slug: form.slug,
      endpoint: action,
      html,
      iframe: `<iframe src="${base}/f/${form.slug}" width="100%" height="420" style="border:0"></iframe>`,
      note: 'Paste the HTML into any page. The endpoint accepts JSON and is rate limited to 10 submissions per IP per hour.'
    });
  }));

  /** Public submission endpoint — no session, no cookie, CORS open. */
  app.options('/api/public/forms/:slug', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'content-type');
    res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
    res.sendStatus(204);
  });

  app.post('/api/public/forms/:slug', wrap(async (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    if (!rateLimit(`form:${ip}`, 10, 3600_000)) {
      return res.status(429).json({ error: 'Too many submissions from this address. Try again later.' });
    }
    const form = await one(
      `select * from web_forms where slug = $1 and is_active = true`, [req.params.slug]
    );
    if (!form) return res.status(404).json({ error: 'Form not found' });

    const body = req.body || {};
    // Honeypot: a bot fills every field it finds. Answer normally, store nothing.
    if (body._hp) return res.json({ ok: true, message: form.success_message });

    const missing = (form.required || []).filter((f) => !String(body[f] || '').trim());
    if (missing.length) return res.status(400).json({ error: `Missing required field: ${missing.join(', ')}` });

    const email = String(body.email || '').trim().toLowerCase();
    const duplicate = email
      ? await one(`select id from leads where org_id = $1 and lower(email) = $2 and created_at > now() - interval '24 hours'`,
        [form.org_id, email])
      : null;

    const lead = await one(
      `insert into leads (org_id, name, company_name, email, phone, source, status, notes, owner_id, custom)
       values ($1,$2,$3,$4,$5,$6,'new',$7,$8,$9) returning *`,
      [form.org_id,
        String(body.name || body.full_name || 'Website enquiry').slice(0, 120),
        body.company_name ? String(body.company_name).slice(0, 120) : null,
        email || null,
        body.phone ? String(body.phone).slice(0, 40) : null,
        form.default_source,
        body.message ? String(body.message).slice(0, 2000) : null,
        form.owner_id,
        JSON.stringify({ form_slug: form.slug, ip })]
    );

    await one(
      `insert into form_submissions (org_id, form_id, lead_id, payload, ip, user_agent, is_duplicate)
       values ($1,$2,$3,$4,$5,$6,$7) returning id`,
      [form.org_id, form.id, lead.id, JSON.stringify(body), ip,
        String(req.headers['user-agent'] || '').slice(0, 200), Boolean(duplicate)]
    );
    await q(`update web_forms set submission_count = submission_count + 1 where id = $1`, [form.id]);

    // Run automations as the form's owner so permissions behave normally.
    const ownerMember = form.owner_id
      || (await one(`select id from members where org_id = $1 and status = 'active' limit 1`, [form.org_id]))?.id;
    const systemCtx = {
      orgId: form.org_id, userId: form.created_by, memberId: ownerMember,
      perms: ['*'], fullName: 'Web form'
    };
    await trigger('lead.created', systemCtx, lead, lead.id);
    await dispatchEvent(form.org_id, 'lead.created', { id: lead.id, name: lead.name, source: lead.source });

    res.status(201).json({
      ok: true,
      message: form.success_message,
      redirectUrl: form.redirect_url || null,
      duplicateOf: duplicate ? duplicate.id : null
    });
  }));

  /* ====================================================== inbound email == */
  /**
   * Point any inbound-email provider at this URL (Postmark, SendGrid, Mailgun,
   * Cloudflare Email Routing). It is verified with an HMAC, not a session.
   */
  app.post('/api/inbound/email', wrap(async (req, res) => {
    const secret = process.env.INBOUND_SECRET;
    if (!secret) {
      return res.status(503).json({
        error: 'Inbound email is not configured',
        detail: 'Set INBOUND_SECRET on the server, then point your provider at this URL.'
      });
    }
    const raw = req.rawBody ? req.rawBody.toString('utf8') : JSON.stringify(req.body || {});
    const signature = req.headers['x-anvaya-signature'] || '';
    if (!safeEqual(signature, `sha256=${hmac(secret, raw)}`)) {
      return res.status(401).json({ error: 'Bad signature' });
    }

    const b = req.body || {};
    const from = String(b.from || b.From || b.sender || '').trim();
    const to = String(b.to || b.To || '').trim();
    const subject = String(b.subject || b.Subject || '(no subject)').slice(0, 300);
    const text = String(b.text || b['body-plain'] || b.TextBody || b.body || '').slice(0, 20000);
    const messageId = String(b.messageId || b['Message-Id'] || b.MessageID || `${from}:${subject}:${text.length}`);

    const address = (from.match(/<([^>]+)>/) || [null, from])[1];
    // Resolution order: explicit INBOUND_ORG_ID, then a matching inbound_domain
    // on the organisation, then a single-workspace fallback. Anything ambiguous
    // is refused rather than guessed.
    const domain = (to.match(/@([^>\s]+)/) || [null, null])[1];
    let org = process.env.INBOUND_ORG_ID
      ? await one(`select id, name from organisations where id = $1`, [process.env.INBOUND_ORG_ID])
      : null;
    if (!org && domain) {
      org = await one(
        `select id, name from organisations where lower(settings->>'inbound_domain') = lower($1) limit 1`,
        [domain]
      );
    }
    if (!org) {
      const all = await q(`select id, name from organisations where deleted_at is null`);
      if (all.length === 1) org = all[0];
      else return res.status(400).json({
        error: 'Cannot tell which workspace this email belongs to',
        detail: 'Set INBOUND_ORG_ID, or store an inbound_domain in the organisation settings.'
      });
    }

    const seen = await one(
      `select id from leads where org_id = $1 and custom->>'inbound_message_id' = $2`, [org.id, messageId]
    );
    if (seen) return res.json({ ok: true, duplicate: true, leadId: seen.id });

    const contact = address
      ? await one(`select id, company_id from contacts where org_id = $1 and lower(email) = lower($2) limit 1`,
        [org.id, address])
      : null;

    let leadId = null;
    if (contact) {
      await one(
        `insert into activities (org_id, type, subject, body, contact_id, company_id, occurred_at)
         values ($1,'email',$2,$3,$4,$5, now()) returning id`,
        [org.id, subject, text, contact.id, contact.company_id]
      );
    } else {
      const lead = await one(
        `insert into leads (org_id, name, email, source, status, notes, custom)
         values ($1,$2,$3,'email','new',$4,$5) returning id`,
        [org.id, address || 'Email enquiry', address || null, text.slice(0, 2000),
          JSON.stringify({ inbound_message_id: messageId, inbound_to: to })]
      );
      leadId = lead.id;
    }

    res.json({ ok: true, matched: Boolean(contact), leadId, messageId });
  }));

  /* ============================================================ api keys == */
  app.get('/api/api-keys', requireAuth, requirePerm('settings.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select id, name, prefix, scopes, last_used_at, request_count, revoked_at, created_at
         from api_keys order by created_at desc`
    ));
    res.json({ data: rows });
  }));

  app.post('/api/api-keys', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    const { name, scope = 'read' } = req.body || {};
    if (!name) throw bad('Give the key a name so you can tell them apart later');
    if (!['read', 'write', 'admin'].includes(scope)) throw bad('Scope must be read, write or admin');
    const secret = `ak_live_${crypto.randomBytes(24).toString('base64url')}`;
    const row = await asUser(req.ctx, (t) => t.one(
      `insert into api_keys (org_id, name, prefix, key_hash, scopes, created_by)
       values ($1,$2,$3,$4,$5,$6) returning id, name, prefix, scopes, created_at`,
      [req.ctx.orgId, name, secret.slice(0, 14), sha256(secret), [scope], req.ctx.userId]
    ));
    await writeAudit(req.ctx, { action: 'api_key.created', entity: 'api_key', entityId: row.id });
    // The key is returned exactly once; only its hash is stored.
    res.status(201).json({ ...row, key: secret, note: 'Copy this now — it cannot be shown again.' });
  }));

  app.delete('/api/api-keys/:id', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    await asUser(req.ctx, (t) => t.q(
      `update api_keys set revoked_at = now() where id = $1`, [req.params.id]
    ));
    await writeAudit(req.ctx, { action: 'api_key.revoked', entity: 'api_key', entityId: req.params.id });
    res.json({ ok: true });
  }));

  /* ============================================================ webhooks == */
  app.get('/api/webhooks', requireAuth, requirePerm('settings.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select w.id, w.url, w.description, w.events, w.is_active, w.last_status, w.last_error,
              w.last_fired_at, w.failure_count, w.created_at,
              (select count(*) from webhook_deliveries d where d.webhook_id = w.id)::int as deliveries
         from webhooks w order by w.created_at desc`
    ));
    res.json({ data: rows, events: WEBHOOK_EVENTS });
  }));

  app.post('/api/webhooks', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    const { url, description, events = ['*'] } = req.body || {};
    // https everywhere, plus plain http on localhost so you can test against
    // your own receiver before pointing at a real endpoint.
    const okUrl = /^https:\/\/.+/i.test(String(url || ''))
      || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//i.test(String(url || ''));
    if (!okUrl) throw bad('Webhook URLs must use https (http is allowed for localhost testing)');
    if (!Array.isArray(events) || !events.length) throw bad('Choose at least one event');
    const secret = `whsec_${crypto.randomBytes(20).toString('hex')}`;
    const row = await asUser(req.ctx, (t) => t.one(
      `insert into webhooks (org_id, url, description, secret, events, created_by)
       values ($1,$2,$3,$4,$5,$6) returning id, url, events, is_active, created_at`,
      [req.ctx.orgId, url, description || null, secret, events, req.ctx.userId]
    ));
    await writeAudit(req.ctx, { action: 'webhook.created', entity: 'webhook', entityId: row.id });
    res.status(201).json({ ...row, secret, note: 'Use this secret to verify x-anvaya-signature on delivery.' });
  }));

  app.delete('/api/webhooks/:id', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    await asUser(req.ctx, (t) => t.q(`delete from webhooks where id = $1`, [req.params.id]));
    res.json({ ok: true });
  }));

  app.get('/api/webhooks/:id/deliveries', requireAuth, requirePerm('settings.read'), wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select id, event, status, response_code, error, attempts, created_at
         from webhook_deliveries where webhook_id = $1 order by created_at desc limit 50`,
      [req.params.id]
    ));
    res.json({ data: rows });
  }));

  /** Send a test delivery so an operator can see it arrive. */
  app.post('/api/webhooks/:id/test', requireAuth, requirePerm('settings.write'), wrap(async (req, res) => {
    await dispatchEvent(req.ctx.orgId, 'webhook.test', { message: 'Test delivery from Anvaya CRM' });
    const last = await asUser(req.ctx, (t) => t.one(
      `select status, response_code, error from webhook_deliveries
        where webhook_id = $1 order by created_at desc limit 1`, [req.params.id]
    ));
    res.json({ ok: true, delivery: last });
  }));

  /* ========================================================= saved views == */
  app.get('/api/saved-views', requireAuth, wrap(async (req, res) => {
    const rows = await asUser(req.ctx, (t) => t.q(
      `select * from saved_views where resource = coalesce($1, resource)
         and (user_id = $2 or is_shared = true) order by created_at`,
      [req.query.resource || null, req.ctx.userId]
    ));
    res.json({ data: rows });
  }));

  app.post('/api/saved-views', requireAuth, wrap(async (req, res) => {
    const { resource, name, filters = {}, sort = null, shared = false } = req.body || {};
    if (!resource || !name) throw bad('A view needs a resource and a name');
    const row = await asUser(req.ctx, (t) => t.one(
      `insert into saved_views (org_id, user_id, resource, name, filters, sort, is_shared)
       values ($1,$2,$3,$4,$5,$6,$7) returning *`,
      [req.ctx.orgId, req.ctx.userId, resource, name, JSON.stringify(filters), sort, shared]
    ));
    res.status(201).json(row);
  }));

  app.delete('/api/saved-views/:id', requireAuth, wrap(async (req, res) => {
    await asUser(req.ctx, (t) => t.q(
      `delete from saved_views where id = $1 and (user_id = $2 or is_shared = true)`,
      [req.params.id, req.ctx.userId]
    ));
    res.json({ ok: true });
  }));

  /* ============================================================ openapi === */
  app.get('/api/openapi.json', wrap(async (req, res) => {
    res.json(openApiSpec(req));
  }));
}

// ------------------------------------------------------------------ spec ----
function openApiSpec(req) {
  const base = process.env.PUBLIC_API_URL || `${req.protocol}://${req.get('host')}`;
  const list = ['leads', 'contacts', 'companies', 'deals', 'tasks', 'activities', 'tickets',
    'products', 'quotations', 'invoices', 'projects', 'campaigns'];
  const paths = {
    '/api/health': { get: { summary: 'Health and mode', responses: { 200: { description: 'OK' } } } },
    '/api/dashboard': { get: { summary: 'Dashboard aggregates', security: [{ bearer: [] }, { cookie: [] }], responses: { 200: { description: 'OK' } } } },
    '/api/search': {
      get: {
        summary: 'Search across records',
        parameters: [{ name: 'q', in: 'query', required: true, schema: { type: 'string' } }],
        security: [{ bearer: [] }, { cookie: [] }],
        responses: { 200: { description: 'OK' } }
      }
    },
    '/api/public/forms/{slug}': {
      post: {
        summary: 'Submit a public lead-capture form',
        parameters: [{ name: 'slug', in: 'path', required: true, schema: { type: 'string' } }],
        requestBody: {
          required: true,
          content: { 'application/json': { schema: { type: 'object', properties: {
            name: { type: 'string' }, email: { type: 'string' }, phone: { type: 'string' },
            company_name: { type: 'string' }, message: { type: 'string' }
          } } } }
        },
        responses: { 201: { description: 'Lead created' }, 429: { description: 'Rate limited' } }
      }
    },
    '/api/inbound/email': {
      post: { summary: 'Inbound email webhook (HMAC signed)', responses: { 200: { description: 'Accepted' }, 401: { description: 'Bad signature' } } }
    },
    '/api/webhooks': {
      get: { summary: 'List webhooks', security: [{ bearer: [] }, { cookie: [] }], responses: { 200: { description: 'OK' } } },
      post: { summary: 'Create a webhook', security: [{ bearer: [] }, { cookie: [] }], responses: { 201: { description: 'Created' } } }
    }
  };
  for (const r of list) {
    paths[`/api/${r}`] = {
      get: {
        summary: `List ${r}`,
        parameters: [
          { name: 'q', in: 'query', schema: { type: 'string' } },
          { name: 'limit', in: 'query', schema: { type: 'integer', maximum: 200 } },
          { name: 'offset', in: 'query', schema: { type: 'integer' } }
        ],
        security: [{ bearer: [] }, { cookie: [] }],
        responses: { 200: { description: 'OK' } }
      },
      post: { summary: `Create ${r}`, security: [{ bearer: [] }, { cookie: [] }], responses: { 201: { description: 'Created' } } }
    };
    paths[`/api/${r}/{id}`] = {
      get: { summary: `Get one ${r}`, security: [{ bearer: [] }, { cookie: [] }], responses: { 200: { description: 'OK' } } },
      patch: { summary: `Update ${r}`, security: [{ bearer: [] }, { cookie: [] }], responses: { 200: { description: 'OK' } } },
      delete: { summary: `Delete ${r}`, security: [{ bearer: [] }, { cookie: [] }], responses: { 200: { description: 'OK' } } }
    };
  }
  return {
    openapi: '3.0.3',
    info: {
      title: 'Anvaya CRM API',
      version: '1.0.0',
      description: 'Cookie session for the app, or `Authorization: Bearer ak_live_…` for integrations. '
        + 'Outbound webhooks carry `x-anvaya-signature: sha256=<hmac of the raw body>`.'
    },
    servers: [{ url: base }],
    components: {
      securitySchemes: {
        bearer: { type: 'http', scheme: 'bearer' },
        cookie: { type: 'apiKey', in: 'cookie', name: 'anvaya_session' }
      }
    },
    paths
  };
}
