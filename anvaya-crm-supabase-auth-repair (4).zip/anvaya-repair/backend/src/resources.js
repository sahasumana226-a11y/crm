// Generic, permission-checked CRUD over the schema.
//
// Every statement runs inside asUser(), so RLS applies as a second line of
// defence: even a bug in the WHERE clause here cannot cross a tenant boundary.

import { asUser } from './db.js';

const OWNER_JOIN = `
  left join members m on m.id = t.owner_id
  left join users u on u.id = m.user_id`;

export const RESOURCES = {
  leads: {
    table: 'leads', perm: 'lead', softDelete: true,
    select: `t.*, coalesce(u.full_name, 'Unassigned') as owner_name, m.id as owner_member_id`,
    from: `leads t ${OWNER_JOIN}`,
    search: ['t.name', 't.company_name', 't.email', 't.phone'],
    filters: { status: 't.status', source: 't.source', owner_id: 't.owner_id' },
    columns: ['name', 'company_name', 'email', 'phone', 'source', 'status', 'score', 'score_reason',
      'owner_id', 'estimated_value', 'currency', 'notes', 'lost_reason', 'custom'],
    sort: 't.created_at desc',
    defaultOrder: ['created_at', 'updated_at', 'name', 'score', 'estimated_value', 'status']
  },
  contacts: {
    table: 'contacts', perm: 'contact', softDelete: true,
    select: `t.*, coalesce(u.full_name,'Unassigned') as owner_name, c.name as company_name,
             (t.first_name || ' ' || coalesce(t.last_name,'')) as full_name`,
    from: `contacts t ${OWNER_JOIN} left join companies c on c.id = t.company_id`,
    search: ['t.first_name', 't.last_name', 't.email', 't.phone', 'c.name'],
    filters: { company_id: 't.company_id', owner_id: 't.owner_id' },
    columns: ['first_name', 'last_name', 'email', 'phone', 'title', 'city', 'company_id', 'owner_id',
      'tags', 'consent', 'health_score', 'custom'],
    sort: 't.created_at desc',
    defaultOrder: ['created_at', 'updated_at', 'first_name', 'health_score']
  },
  companies: {
    table: 'companies', perm: 'company', softDelete: true,
    select: `t.*, coalesce(u.full_name,'Unassigned') as owner_name, p.name as parent_name`,
    from: `companies t ${OWNER_JOIN} left join companies p on p.id = t.parent_id`,
    search: ['t.name', 't.domain', 't.industry', 't.city'],
    filters: { industry: 't.industry', owner_id: 't.owner_id' },
    columns: ['name', 'domain', 'industry', 'size_band', 'annual_revenue', 'phone', 'website', 'city',
      'country', 'address', 'parent_id', 'owner_id', 'health_score', 'tags', 'custom'],
    sort: 't.name asc',
    defaultOrder: ['name', 'created_at', 'annual_revenue', 'health_score']
  },
  deals: {
    table: 'deals', perm: 'deal', softDelete: true,
    select: `t.*, s.name as stage_name, s.position as stage_position, s.probability as stage_probability,
             s.is_won, s.is_lost, co.name as company_name,
             (ct.first_name || ' ' || coalesce(ct.last_name,'')) as contact_name,
             coalesce(u.full_name,'Unassigned') as owner_name,
             extract(day from now() - t.stage_changed_at)::int as days_in_stage`,
    from: `deals t join stages s on s.id = t.stage_id
           left join companies co on co.id = t.company_id
           left join contacts ct on ct.id = t.contact_id ${OWNER_JOIN}`,
    search: ['t.title', 'co.name'],
    filters: { status: 't.status', stage_id: 't.stage_id', pipeline_id: 't.pipeline_id', owner_id: 't.owner_id', company_id: 't.company_id' },
    columns: ['title', 'value', 'currency', 'stage_id', 'pipeline_id', 'company_id', 'contact_id',
      'probability', 'expected_close_date', 'owner_id', 'status', 'lost_reason', 'competitor', 'custom'],
    sort: 't.created_at desc',
    defaultOrder: ['created_at', 'updated_at', 'value', 'expected_close_date']
  },
  tasks: {
    table: 'tasks', perm: 'task', softDelete: false,
    select: `t.*, coalesce(u.full_name,'Unassigned') as assignee_name`,
    from: `tasks t left join members m on m.id = t.assignee_id left join users u on u.id = m.user_id`,
    search: ['t.title', 't.notes'],
    filters: { status: 't.status', priority: 't.priority', assignee_id: 't.assignee_id', related_id: 't.related_id' },
    columns: ['title', 'notes', 'due_date', 'due_time', 'priority', 'status', 'assignee_id',
      'related_type', 'related_id', 'recurrence', 'completed_at'],
    sort: 'case when t.status = \'done\' then 1 else 0 end, t.due_date asc nulls last',
    defaultOrder: ['created_at', 'due_date', 'priority']
  },
  activities: {
    table: 'activities', perm: 'activity', softDelete: false,
    select: `t.*, coalesce(u.full_name,'Unassigned') as owner_name`,
    from: `activities t ${OWNER_JOIN}`,
    search: ['t.subject', 't.body'],
    filters: { type: 't.type', contact_id: 't.contact_id', company_id: 't.company_id', deal_id: 't.deal_id', ticket_id: 't.ticket_id' },
    columns: ['type', 'subject', 'body', 'contact_id', 'company_id', 'deal_id', 'ticket_id',
      'owner_id', 'occurred_at', 'duration_min'],
    sort: 't.occurred_at desc',
    defaultOrder: ['occurred_at', 'created_at']
  },
  tickets: {
    table: 'tickets', perm: 'ticket', softDelete: false,
    select: `t.*, coalesce(u.full_name,'Unassigned') as assignee_name, co.name as company_name,
             (ct.first_name || ' ' || coalesce(ct.last_name,'')) as contact_name,
             case when t.resolved_at is not null then 'met'
                  when t.sla_due_at < now() then 'breached'
                  when t.sla_due_at < now() + interval '4 hours' then 'at_risk'
                  else 'on_track' end as sla_state`,
    from: `tickets t left join members m on m.id = t.assignee_id left join users u on u.id = m.user_id
           left join companies co on co.id = t.company_id
           left join contacts ct on ct.id = t.contact_id`,
    search: ['t.subject', 't.number', 't.description'],
    filters: { status: 't.status', priority: 't.priority', assignee_id: 't.assignee_id', contact_id: 't.contact_id' },
    columns: ['number', 'subject', 'description', 'contact_id', 'company_id', 'deal_id', 'priority',
      'status', 'category', 'assignee_id', 'sla_policy', 'sla_due_at', 'csat', 'resolved_at'],
    sort: `case t.priority when 'critical' then 0 when 'high' then 1 when 'medium' then 2 else 3 end, t.created_at desc`,
    defaultOrder: ['created_at', 'priority', 'status']
  },
  products: {
    table: 'products', perm: 'product', softDelete: false,
    select: 't.*',
    from: 'products t',
    search: ['t.name', 't.sku', 't.category'],
    filters: { category: 't.category', is_active: 't.is_active' },
    columns: ['sku', 'name', 'category', 'description', 'unit_price', 'tax_rate', 'stock_qty',
      'reorder_point', 'uom', 'is_active'],
    sort: 't.name asc', defaultOrder: ['name', 'unit_price', 'stock_qty']
  },
  campaigns: {
    table: 'campaigns', perm: 'campaign', softDelete: false,
    select: 't.*',
    from: 'campaigns t',
    search: ['t.name', 't.subject'],
    filters: { status: 't.status', channel: 't.channel' },
    columns: ['name', 'channel', 'status', 'subject', 'body', 'audience', 'scheduled_at', 'provider'],
    sort: 't.created_at desc', defaultOrder: ['created_at', 'name', 'status']
  },
  quotations: {
    table: 'quotations', perm: 'quotation', softDelete: false,
    select: `t.*, co.name as company_name, d.title as deal_title`,
    from: `quotations t left join companies co on co.id = t.company_id left join deals d on d.id = t.deal_id`,
    search: ['t.number', 'co.name'],
    filters: { status: 't.status', company_id: 't.company_id', deal_id: 't.deal_id' },
    columns: ['number', 'deal_id', 'contact_id', 'company_id', 'status', 'issue_date', 'valid_until',
      'currency', 'subtotal', 'discount_total', 'tax_total', 'total', 'notes', 'terms'],
    sort: 't.created_at desc', defaultOrder: ['created_at', 'total', 'status']
  },
  invoices: {
    table: 'invoices', perm: 'invoice', softDelete: false,
    select: `t.*, co.name as company_name`,
    from: `invoices t left join companies co on co.id = t.company_id`,
    search: ['t.number', 'co.name'],
    filters: { status: 't.status', company_id: 't.company_id' },
    columns: ['number', 'quotation_id', 'deal_id', 'contact_id', 'company_id', 'status', 'issue_date',
      'due_date', 'currency', 'subtotal', 'tax_total', 'total', 'amount_paid', 'notes', 'paid_at'],
    sort: 't.created_at desc', defaultOrder: ['created_at', 'total', 'due_date']
  },
  projects: {
    table: 'projects', perm: 'project', softDelete: false,
    select: `t.*, co.name as company_name, coalesce(u.full_name,'Unassigned') as manager_name`,
    from: `projects t left join companies co on co.id = t.company_id
           left join members m on m.id = t.manager_id left join users u on u.id = m.user_id`,
    search: ['t.name'],
    filters: { status: 't.status', company_id: 't.company_id' },
    columns: ['name', 'deal_id', 'company_id', 'status', 'start_date', 'end_date', 'budget', 'spent',
      'progress', 'manager_id'],
    sort: 't.created_at desc', defaultOrder: ['created_at', 'name', 'progress']
  },
  workflows: {
    table: 'workflows', perm: 'workflow', softDelete: false,
    select: 't.*',
    from: 'workflows t',
    search: ['t.name', 't.description'],
    filters: { status: 't.status' },
    columns: ['name', 'description', 'status', 'trigger', 'conditions', 'actions'],
    sort: 't.created_at desc', defaultOrder: ['created_at', 'name', 'status']
  },
  members: {
    table: 'members', perm: 'member', softDelete: false,
    select: `t.*, u.full_name, u.email, u.last_login_at, r.name as role_name, r.key as role_key,
             r.permissions, w.name as workspace_name`,
    from: `members t join users u on u.id = t.user_id join roles r on r.id = t.role_id
           left join workspaces w on w.id = t.workspace_id`,
    search: ['u.full_name', 'u.email'],
    filters: { status: 't.status', role_id: 't.role_id' },
    columns: ['role_id', 'status', 'title', 'department', 'workspace_id'],
    sort: 'u.full_name asc', defaultOrder: ['joined_at', 'full_name']
  },
  'custom-fields': {
    table: 'custom_fields', perm: 'settings', softDelete: false,
    select: 't.*', from: 'custom_fields t',
    search: ['t.label', 't.key'],
    filters: { entity: 't.entity' },
    columns: ['entity', 'key', 'label', 'type', 'options', 'required', 'position'],
    sort: 't.entity, t.position', defaultOrder: ['position', 'label']
  },
  notifications: {
    table: 'notifications', perm: 'notification', softDelete: false,
    select: 't.*', from: 'notifications t',
    search: ['t.title', 't.body'],
    filters: { type: 't.type' },
    columns: ['type', 'title', 'body', 'link', 'read_at'],
    sort: 't.created_at desc', defaultOrder: ['created_at'],
    scopeToUser: true
  }
};

const IDENT = /^[a-z_][a-z0-9_]*$/;
function assertIdent(name) {
  if (!IDENT.test(name)) throw new Error(`Unsafe identifier: ${name}`);
  return name;
}

function orderBy(res, sortParam) {
  if (!sortParam) return res.sort;
  const [rawField, dirRaw] = String(sortParam).split(':');
  const dir = String(dirRaw || 'asc').toLowerCase() === 'desc' ? 'desc' : 'asc';
  const field = rawField.replace(/^t\./, '');
  if (!res.defaultOrder.includes(field)) return res.sort;
  return `t.${assertIdent(field)} ${dir} nulls last`;
}

function buildWhere(res, ctx, query, params) {
  const where = [];
  if (res.scopeToUser) {
    params.push(ctx.userId);
    where.push(`t.user_id = $${params.length}`);
  }
  if (query.q) {
    params.push(`%${String(query.q).slice(0, 120)}%`);
    const idx = params.length;
    where.push(`(${res.search.map(s => `${s} ilike $${idx}`).join(' or ')})`);
  }
  for (const [key, col] of Object.entries(res.filters || {})) {
    if (query[key] !== undefined && query[key] !== '' && query[key] !== 'all') {
      params.push(query[key]);
      where.push(`${col} = $${params.length}`);
    }
  }
  // Delta sync: only rows changed since the client's cursor. This is what lets
  // a device pull updates instead of re-downloading every table.
  if (query.updated_since) {
    params.push(query.updated_since);
    where.push(`t.updated_at > $${params.length}::timestamptz`);
  }
  if (query.from) { params.push(query.from); where.push(`t.created_at >= $${params.length}`); }
  if (query.to) { params.push(query.to); where.push(`t.created_at < ($${params.length}::date + interval '1 day')`); }
  return where.length ? `where ${where.join(' and ')}` : '';
}

export async function listResource(ctx, key, query = {}) {
  const res = RESOURCES[key];
  if (!res) throw Object.assign(new Error('Unknown resource'), { status: 404 });
  const limit = Math.min(Number(query.limit) || 50, 200);
  const offset = Math.max(Number(query.offset) || 0, 0);

  return asUser(ctx, async (t) => {
    const params = [];
    const where = buildWhere(res, ctx, query, params);
    const totalRow = await t.one(`select count(*)::int as n from ${res.from} ${where}`, params);
    const rows = await t.q(
      `select ${res.select} from ${res.from} ${where} order by ${orderBy(res, query.sort)} limit ${limit} offset ${offset}`,
      params
    );
    return { data: rows, total: totalRow?.n ?? rows.length, limit, offset };
  });
}

export async function getResource(ctx, key, id) {
  const res = RESOURCES[key];
  return asUser(ctx, async (t) => {
    const row = await t.one(`select ${res.select} from ${res.from} where t.id = $1`, [id]);
    return row;
  });
}

function pickColumns(res, body) {
  const out = {};
  for (const col of res.columns) {
    if (Object.prototype.hasOwnProperty.call(body, col)) out[col] = body[col];
  }
  return out;
}

/**
 * Identifiers the schema requires but a human should not type: ticket and
 * quotation numbers, product SKUs. They are generated per organisation, and an
 * explicit value from the client still wins.
 */
const AUTO_IDENTIFIER = {
  tickets: { column: 'number', prefix: 'TKT' },
  quotations: { column: 'number', prefix: 'QTN' },
  invoices: { column: 'number', prefix: 'INV' },
  products: { column: 'sku', prefix: 'SKU' }
};

async function nextIdentifier(t, table, column, prefix) {
  const year = new Date().getFullYear();
  const row = await t.one(
    `select count(*)::int as n from ${assertIdent(table)} where ${assertIdent(column)} like $1`,
    [`${prefix}-${year}-%`]
  );
  let n = (row?.n || 0) + 1;
  // Skip anything already taken, so a manually entered number cannot collide.
  for (let attempt = 0; attempt < 50; attempt += 1) {
    const candidate = `${prefix}-${year}-${String(n).padStart(4, '0')}`;
    const taken = await t.one(
      `select 1 as x from ${assertIdent(table)} where ${assertIdent(column)} = $1 limit 1`, [candidate]);
    if (!taken) return candidate;
    n += 1;
  }
  return `${prefix}-${year}-${Date.now().toString().slice(-6)}`;
}

export async function createResource(ctx, key, body) {
  const res = RESOURCES[key];
  const values = pickColumns(res, body);

  // A form sends null for every field left empty. On insert that would override
  // the column default with null, which fails on any NOT NULL column
  // (estimated_value, probability, score…). Omit them instead and let the
  // database apply its own default.
  for (const [k, v] of Object.entries(values)) {
    if (v === null) delete values[k];
  }
  const auto = AUTO_IDENTIFIER[key];
  if (!Object.keys(values).length && !auto) {
    throw Object.assign(new Error('No writable fields supplied'), { status: 400 });
  }

  return asUser(ctx, async (t) => {
    if (auto && !values[auto.column]) {
      values[auto.column] = await nextIdentifier(t, res.table, auto.column, auto.prefix);
    }
    const cols = ['org_id', ...Object.keys(values)];
    const params = [ctx.orgId, ...Object.values(values)];
    const placeholders = cols.map((_, i) => `$${i + 1}`);
    const row = await t.one(
      `insert into ${res.table} (${cols.map(assertIdent).join(',')}) values (${placeholders.join(',')}) returning *`,
      params
    );
    return row;
  });
}

export async function updateResource(ctx, key, id, body) {
  const res = RESOURCES[key];
  const values = pickColumns(res, body);
  if (!Object.keys(values).length) throw Object.assign(new Error('No writable fields supplied'), { status: 400 });

  return asUser(ctx, async (t) => {
    const sets = Object.keys(values).map((c, i) => `${assertIdent(c)} = $${i + 2}`);
    const row = await t.one(
      `update ${res.table} set ${sets.join(', ')} where id = $1 returning *`,
      [id, ...Object.values(values)]
    );
    if (!row) throw Object.assign(new Error('Not found'), { status: 404 });
    return row;
  });
}

export async function deleteResource(ctx, key, id) {
  const res = RESOURCES[key];
  return asUser(ctx, async (t) => {
    if (res.softDelete) {
      const row = await t.one(`update ${res.table} set deleted_at = now() where id = $1 returning id`, [id]);
      return row;
    }
    const row = await t.one(`delete from ${res.table} where id = $1 returning id`, [id]);
    return row;
  });
}
