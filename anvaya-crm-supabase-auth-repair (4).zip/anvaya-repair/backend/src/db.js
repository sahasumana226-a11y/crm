// Single PostgreSQL access layer. Production is Supabase PostgreSQL only.
// PGlite is an explicit local-development mode; it is never an automatic fallback.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PKG_ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
let client = null;
let initPromise = null;

function loadLocalEnv() {
  if (process.env.DATABASE_URL || process.env.NODE_ENV === 'production') return;
  for (const envPath of [path.join(PKG_ROOT, '../.env'), path.join(PKG_ROOT, '.env'), path.join(process.cwd(), '.env')]) {
    if (!fs.existsSync(envPath)) continue;
    for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([\w.-]+)\s*=\s*(.*?)\s*$/);
      if (!m || m[1].startsWith('#') || process.env[m[1]]) continue;
      process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
    }
    break;
  }
}
loadLocalEnv();

export function getSanitizedDatabaseUrl() {
  const raw = String(process.env.DATABASE_URL || '').trim().replace(/^["']|["']$/g, '');
  if (!raw) return '';
  try {
    const url = new URL(raw);
    if (!['postgres:', 'postgresql:'].includes(url.protocol)) return '';
    return url.toString();
  } catch {
    return '';
  }
}

const positiveInt = (value, fallback, min, max) => {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? Math.max(min, Math.min(parsed, max)) : fallback;
};
const TRANSIENT_CODES = new Set([
  'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EHOSTUNREACH', 'ENETUNREACH',
  'EAI_AGAIN', '57P01', '57P02', '57P03', '53300'
]);
const permanent = (err) => ['28P01', '28000', '3D000', '42501', '22P02'].includes(err?.code);
const transient = (err) => TRANSIENT_CODES.has(err?.code) || (!err?.code && /timeout|socket|network|connection terminated/i.test(err?.message || ''));

function pgAdapter(pool) {
  return {
    driver: 'pg',
    query: (sql, params) => pool.query(sql, params),
    exec: (sql) => pool.query(sql),
    async transaction(fn) {
      const conn = await pool.connect();
      try {
        await conn.query('begin');
        const out = await fn({
          query: (sql, params) => conn.query(sql, params),
          exec: (sql) => conn.query(sql)
        });
        await conn.query('commit');
        return out;
      } catch (err) {
        try { await conn.query('rollback'); } catch {}
        throw err;
      } finally {
        conn.release();
      }
    },
    close: () => pool.end()
  };
}

function pgliteAdapter(db) {
  return {
    driver: 'pglite',
    query: (sql, params) => db.query(sql, params),
    exec: (sql) => db.exec(sql),
    transaction: (fn) => db.transaction(fn),
    close: () => db.close()
  };
}

function projectRefFromUrl(parsedUrl) {
  return parsedUrl.hostname.match(/^db\.([^.]+)\.supabase\.co$/)?.[1] ||
    decodeURIComponent(parsedUrl.username).match(/^postgres\.([^.]+)$/)?.[1] || '';
}

async function initialize() {
  const url = getSanitizedDatabaseUrl();
  const testShim = process.env.PG_SHIM === '1' && process.env.NODE_ENV !== 'production';
  if (process.env.NODE_ENV === 'production') {
    if (!url) {
      const err = new Error('DATABASE_URL is required; production database fallback is disabled');
      err.code = 'DB_CONFIG_MISSING';
      throw err;
    }
    const parsedUrl = new URL(url);
    const host = parsedUrl.hostname.toLowerCase();
    if (!host.endsWith('.supabase.co') && !host.endsWith('.supabase.com')) {
      const err = new Error('Production DATABASE_URL must point to the configured Supabase PostgreSQL project');
      err.code = 'DB_PROVIDER_INVALID';
      throw err;
    }
    const detectedRef = projectRefFromUrl(parsedUrl);
    const expectedRef = process.env.SUPABASE_PROJECT_REF || '';
    if (!detectedRef && !expectedRef) {
      const err = new Error('Set SUPABASE_PROJECT_REF when the Supabase connection URI does not identify its project');
      err.code = 'DB_PROJECT_UNCONFIRMED';
      throw err;
    }
    if (detectedRef && expectedRef && detectedRef !== expectedRef) {
      const err = new Error('DATABASE_URL does not match SUPABASE_PROJECT_REF');
      err.code = 'DB_PROJECT_MISMATCH';
      throw err;
    }
  }
  if (url || testShim) {
    const { Pool } = testShim ? await import('../tests/pg-shim.mjs') : await import('pg');
    const pool = new Pool({
      ...(url ? { connectionString: url } : {}),
      max: positiveInt(process.env.DB_POOL_SIZE, 3, 1, 10),
      min: 0,
      idleTimeoutMillis: 10000,
      connectionTimeoutMillis: positiveInt(process.env.DB_CONNECTION_TIMEOUT_MS, 7000, 1000, 30000),
      query_timeout: positiveInt(process.env.DB_QUERY_TIMEOUT_MS, 15000, 1000, 60000),
      allowExitOnIdle: true,
      ssl: process.env.DATABASE_SSL === '0' && process.env.NODE_ENV !== 'production'
        ? false : { rejectUnauthorized: process.env.DATABASE_SSL_VERIFY !== '0' }
    });
    pool.on('error', err => {
      console.error('[db] idle pool client error', { code: err.code || 'POOL_ERROR' });
    });
    try {
      let lastError;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          await pool.query('select 1 as ok, current_database() as database_name, current_user as database_user');
          const adapter = pgAdapter(pool);
          console.info('[db] PostgreSQL connection verified', { driver: 'pg' });
          return adapter;
        } catch (err) {
          lastError = err;
          if (permanent(err) || !transient(err) || attempt === 2) break;
          const delay = Math.min(250 * (2 ** attempt) + Math.floor(Math.random() * 200), 1500);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
      throw lastError;
    } catch (err) {
      try { await pool.end(); } catch {}
      throw err;
    }
  }

  if (process.env.NODE_ENV === 'production' || !(process.env.DB_MODE === 'pglite' || (process.env.NODE_ENV === 'test' && process.env.DB_MEMORY === '1'))) {
    const err = new Error('DATABASE_URL is required; production database fallback is disabled');
    err.code = 'DB_CONFIG_MISSING';
    throw err;
  }
  const { PGlite } = await import('@electric-sql/pglite');
  const dbPath = process.env.DB_MEMORY === '1' ? undefined
    : (process.env.DB_PATH || path.join(PKG_ROOT, '.data', 'anvaya'));
  if (dbPath) fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  const local = dbPath ? new PGlite(dbPath) : new PGlite();
  await local.waitReady;
  await local.exec(`do $$ begin
    if not exists (select 1 from pg_roles where rolname = 'app_user') then create role app_user nologin; end if;
    if not exists (select 1 from pg_roles where rolname = 'authenticated') then create role authenticated nologin; end if;
  end $$;`);
  return pgliteAdapter(local);
}

export async function initDb() {
  if (client) return client;
  if (!initPromise) {
    initPromise = initialize().then(value => {
      client = value;
      return value;
    }).catch(err => {
      initPromise = null; // a later request may recover from a transient outage
      throw err;
    });
  }
  return initPromise;
}

export function db() {
  if (!client) throw new Error('initDb() must be awaited before db()');
  return client;
}
async function ready() { return client || initDb(); }

export async function q(sql, params = []) {
  const c = await ready();
  return (await c.query(sql, params)).rows;
}
export async function one(sql, params = []) {
  return (await q(sql, params))[0] || null;
}
export async function tx(fn) {
  const c = await ready();
  return c.transaction(async t => fn({
    q: async (sql, params = []) => (await t.query(sql, params)).rows,
    one: async (sql, params = []) => (await t.query(sql, params)).rows[0] || null
  }));
}

export async function asUser(ctx, fn) {
  const userRole = process.env.DB_USER_ROLE || 'authenticated';
  if (!/^[a-z_][a-z0-9_]*$/i.test(userRole)) {
    const err = new Error('DB_USER_ROLE must be a valid PostgreSQL role identifier');
    err.code = 'DB_CONFIG_INVALID';
    throw err;
  }
  if (!ctx?.orgId || !ctx?.userId) throw new Error('asUser requires orgId and userId');
  const c = await ready();
  const perms = (ctx.perms || []).join(',');
  return c.transaction(async t => {
    if (c.driver === 'pg') await t.query(`set local role ${userRole}`);
    await t.query(`select set_config('app.org_id', $1, true)`, [ctx.orgId]);
    await t.query(`select set_config('app.user_id', $1, true)`, [ctx.userId]);
    await t.query(`select set_config('app.perms', $1, true)`, [perms]);
    return fn({
      q: async (sql, params = []) => (await t.query(sql, params)).rows,
      one: async (sql, params = []) => (await t.query(sql, params)).rows[0] || null,
      exec: async sql => t.exec(sql)
    });
  });
}

export function driver() { return client?.driver || null; }
export async function closeDb() {
  if (client?.close) await client.close();
  client = null;
  initPromise = null;
}

export async function migrate(dir = path.join(PKG_ROOT, 'db', 'migrations')) {
  const c = await ready();
  const files = filesInDirectory(dir);
  await c.query(`create table if not exists anvaya_schema_migrations (
    version text primary key, applied_at timestamptz not null default now()
  )`);
  const applied = new Set((await c.query('select version from anvaya_schema_migrations')).rows.map(x => x.version));
  const completed = [];
  for (const file of files) {
    if (applied.has(file)) continue;
    const sql = fs.readFileSync(path.join(dir, file), 'utf8');
    await c.transaction(async t => {
      await t.exec(sql);
      await t.query('insert into anvaya_schema_migrations (version) values ($1)', [file]);
    }).catch(err => { throw new Error(`Migration ${file} failed (${err.code || 'UNKNOWN'}): ${err.message}`); });
    completed.push(file);
  }
  return completed;
}

export async function databaseDiagnostics() {
  const c = await ready();
  const live = await c.query(`select now() as checked_at, current_database() as database_name,
    current_user as database_user, current_setting('server_version') as server_version`);
  const required = {
    users: ['id', 'email', 'password_hash', 'status', 'mfa_enabled_at'],
    sessions: ['id', 'user_id', 'token_hash', 'expires_at', 'revoked_at', 'mfa_ok'],
    organisations: ['id', 'name', 'slug', 'settings', 'deleted_at'],
    workspaces: ['id', 'org_id', 'name', 'settings', 'is_default'],
    members: ['id', 'org_id', 'user_id', 'role_id', 'workspace_id', 'status', 'joined_at'],
    roles: ['id', 'org_id', 'key', 'permissions'],
    pipelines: ['id', 'org_id', 'name'],
    stages: ['id', 'org_id', 'pipeline_id', 'name']
  };
  const schemaRows = await c.query(`select table_name, column_name from information_schema.columns
    where table_schema = 'public' and table_name = any($1::text[])`, [Object.keys(required)]);
  const actual = new Map();
  for (const row of schemaRows.rows) {
    if (!actual.has(row.table_name)) actual.set(row.table_name, new Set());
    actual.get(row.table_name).add(row.column_name);
  }
  const missing = [];
  for (const [table, columns] of Object.entries(required)) {
    if (!actual.has(table)) missing.push(`${table}:table`);
    else for (const column of columns) if (!actual.get(table).has(column)) missing.push(`${table}.${column}`);
  }
  if (actual.has('members') && actual.get('members').has('status') && actual.get('members').has('workspace_id')) {
    const orphanedMemberships = Number((await c.query(
      `select count(*)::int as n from members where status='active' and workspace_id is null`
    )).rows[0].n);
    if (orphanedMemberships) missing.push(`members.active_without_workspace:${orphanedMemberships}`);
  }

  const foreignKeys = await c.query(`select tc.table_name, kcu.column_name, ccu.table_name as referenced_table
    from information_schema.table_constraints tc
    join information_schema.key_column_usage kcu
      on tc.constraint_name=kcu.constraint_name and tc.table_schema=kcu.table_schema
    join information_schema.constraint_column_usage ccu
      on ccu.constraint_name=tc.constraint_name and ccu.table_schema=tc.table_schema
    where tc.constraint_type='FOREIGN KEY' and tc.table_schema='public'`);
  const relationships = new Set(foreignKeys.rows.map(x => `${x.table_name}.${x.column_name}->${x.referenced_table}`));
  for (const relation of [
    'members.user_id->users', 'members.org_id->organisations',
    'members.role_id->roles', 'members.workspace_id->workspaces',
    'sessions.user_id->users'
  ]) if (!relationships.has(relation)) missing.push(`${relation}:foreign_key`);

  let migrationRows = [];
  try { migrationRows = (await c.query('select version from anvaya_schema_migrations order by version')).rows; } catch {}
  let policyCount = 0;
  let rlsEnabled = false;
  let roleExists = false;
  let roleHasPrivileges = false;
  try {
    policyCount = Number((await c.query(`select count(*)::int as n from pg_policies where schemaname='public'`)).rows[0].n);
    rlsEnabled = Number((await c.query(`select count(*)::int as n from pg_class cl
      join pg_namespace ns on ns.oid=cl.relnamespace
      where ns.nspname='public' and cl.relname = any($1::text[]) and cl.relrowsecurity`,
      [['organisations', 'users', 'sessions', 'workspaces', 'members', 'roles']])).rows[0].n) >= 6;
    const role = process.env.DB_USER_ROLE || 'authenticated';
    const roleRow = await c.query(`select exists(select 1 from pg_roles where rolname=$1) as exists,
      has_table_privilege($1, 'public.leads', 'select') as can_read,\n      has_table_privilege($1, 'public.leads', 'insert,update,delete') as can_write`, [role]);
    roleExists = roleRow.rows[0].exists;
    roleHasPrivileges = roleRow.rows[0].can_read && roleRow.rows[0].can_write;
  } catch {}
  const latestMigration = filesInDirectory(path.join(PKG_ROOT, 'db', 'migrations')).at(-1);
  const configuredRef = process.env.SUPABASE_PROJECT_REF || '';
  const databaseUrl = getSanitizedDatabaseUrl();
  const detectedRef = databaseUrl ? projectRefFromUrl(new URL(databaseUrl)) : '';
  const projectStatus = configuredRef && detectedRef
    ? (detectedRef === configuredRef ? 'matched' : 'mismatch')
    : configuredRef ? 'configured' : (detectedRef ? 'detected' : 'not-confirmed');
  const migrationStatus = migrationRows.length === 0 ? 'untracked' :
    filesInDirectory(path.join(PKG_ROOT, 'db', 'migrations')).every(file => migrationRows.some(x => x.version === file)) ? 'current' : 'pending';
  return {
    provider: databaseUrl && /\.supabase\.(co|com)$/i.test(new URL(databaseUrl).hostname) ? 'supabase-postgres' : 'postgresql',
    projectStatus,
    driver: c.driver,
    connectionStatus: 'connected',
    database: live.rows[0].database_name,
    checkedAt: live.rows[0].checked_at,
    schemaStatus: missing.length ? 'incomplete' : 'valid',
    missingSchema: missing,
    migrationStatus,
    migrations: migrationRows.map(x => x.version),
    rlsStatus: rlsEnabled && policyCount > 0 ? 'enabled' : 'incomplete',
    roleStatus: roleExists && roleHasPrivileges ? 'valid' : 'invalid',
    authenticationStatus: missing.some(x => x.startsWith('users') || x.startsWith('sessions')) ? 'incomplete' : 'available',
    workspaceStatus: missing.some(x => /^(organisations|workspaces|members|roles)(:|\.|.*foreign_key)/.test(x)) ? 'incomplete' : 'available',
    rlsPolicyCount: policyCount
  };
}

function filesInDirectory(dir) {
  return fs.readdirSync(dir).filter(f => /^\d+_[\w-]+\.sql$/.test(f)).sort();
}
