import { initDb, one } from '../src/db.js';
import { verifyPassword } from '../src/auth.js';

async function testAuth() {
  await initDb();
  const user = await one('select * from users where lower(email) = lower($1)', ['sneha@brightline.in']);
  if (!user) {
    console.log('User not found!');
    return;
  }
  const ok = verifyPassword('AnvayaDemo2026', user.password_hash);
  console.log('User found:', user.email);
  console.log('Password verification result:', ok);
}
testAuth().catch(console.error);
