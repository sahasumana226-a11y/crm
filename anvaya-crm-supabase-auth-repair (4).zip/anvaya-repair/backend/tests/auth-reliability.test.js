import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { boot, shutdown, registerOrg, client } from './helpers.js';
import { one, q } from '../src/db.js';

before(async () => { await boot(); });
after(async () => { await shutdown(); });

describe('authentication and workspace reliability', () => {
  test('registration persists the owner workspace and a usable database session', async () => {
    const { api, email, org } = await registerOrg({ name: 'Persistent Workspace Co' });
    const me = await api('/api/auth/me');
    assert.equal(me.status, 200);
    assert.equal(me.body.user.email, email);
    assert.equal(me.body.org.id, org.id);
    assert.ok(me.body.workspace.id, 'active workspace id is returned');
    const member = await one(
      `select m.workspace_id, r.key as role_key
         from members m join roles r on r.id=m.role_id
        where m.user_id=(select id from users where email=$1) and m.org_id=$2`,
      [email, org.id]
    );
    assert.equal(member.workspace_id, me.body.workspace.id);
    assert.equal(member.role_key, 'owner');
  });

  test('disabled accounts cannot sign in or reuse an existing session', async () => {
    const { api, email, password } = await registerOrg({ name: 'Disabled Account Co' });
    await q(`update users set status='disabled' where email=$1`, [email]);
    const existingSession = await api('/api/auth/me');
    assert.equal(existingSession.status, 401);
    const fresh = client();
    const login = await fresh('/api/auth/login', { body: { email, password } });
    assert.equal(login.status, 401);
  });

  test('health reports live schema, migration, RLS and role state', async () => {
    const res = await client()('/api/health');
    assert.equal(res.status, 200);
    assert.equal(res.body.connectionStatus, 'connected');
    assert.equal(res.body.schemaStatus, 'valid');
    assert.equal(res.body.migrationStatus, 'current');
    assert.equal(res.body.rlsStatus, 'enabled');
    assert.equal(res.body.diagnostics.roleStatus, 'valid');
  });
});
