// V6 increment: MFA, documents, finance.
// Everything here runs against the real app and the real database.

process.env.ENCRYPTION_KEY = 'test-encryption-key-32-characters-long';

import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { boot, shutdown, registerOrg, client } from './helpers.js';
import { totp } from '../src/mfa.js';

before(async () => { await boot(); });
after(async () => { await shutdown(); });

/* ============================================================== MFA ======= */
describe('multi-factor authentication', () => {
  test('is off until a code proves the authenticator was set up', async () => {
    const { api } = await registerOrg({ name: 'MFA Co' });
    const before = await api('/api/auth/mfa/status');
    assert.equal(before.body.enabled, false);

    const setup = await api('/api/auth/mfa/setup', { method: 'POST' });
    assert.equal(setup.status, 200);
    assert.match(setup.body.otpauthUrl, /^otpauth:\/\/totp\//);
    assert.ok(setup.body.secret.length >= 16);

    // Still disabled: generating a secret is not the same as enrolling.
    const midway = await api('/api/auth/mfa/status');
    assert.equal(midway.body.enabled, false);

    const wrong = await api('/api/auth/mfa/enable', { body: { code: '000000' } });
    assert.equal(wrong.status, 400);
  });

  test('a wrong code at sign-in leaves the session unusable', async () => {
    const { api, email, password } = await registerOrg({ name: 'MFA Login Co' });
    const setup = await api('/api/auth/mfa/setup', { method: 'POST' });
    const secret = setup.body.secret;
    const enable = await api('/api/auth/mfa/enable', { body: { code: totp(secret) } });
    assert.equal(enable.status, 200);
    assert.equal(enable.body.backupCodes.length, 10);

    const fresh = client();
    const login = await fresh('/api/auth/login', { body: { email, password } });
    assert.equal(login.body.mfaRequired, true);

    const blocked = await fresh('/api/leads');
    assert.equal(blocked.status, 401, 'the session must not work before the second factor');

    const badCode = await fresh('/api/auth/mfa/verify', { body: { code: '123456' } });
    assert.equal(badCode.status, 401);

    const good = await fresh('/api/auth/mfa/verify', { body: { code: totp(secret) } });
    assert.equal(good.status, 200);

    const allowed = await fresh('/api/leads');
    assert.equal(allowed.status, 200);
  });

  test('a backup code works exactly once', async () => {
    const { api, email, password } = await registerOrg({ name: 'MFA Backup Co' });
    const setup = await api('/api/auth/mfa/setup', { method: 'POST' });
    const enabled = await api('/api/auth/mfa/enable', { body: { code: totp(setup.body.secret) } });
    const code = enabled.body.backupCodes[0];

    const first = client();
    await first('/api/auth/login', { body: { email, password } });
    const used = await first('/api/auth/mfa/verify', { body: { code } });
    assert.equal(used.status, 200);
    assert.equal(used.body.usedBackupCode, true);

    const second = client();
    await second('/api/auth/login', { body: { email, password } });
    const reused = await second('/api/auth/mfa/verify', { body: { code } });
    assert.equal(reused.status, 401, 'the same backup code cannot be used twice');
  });

  test('turning MFA off requires the password', async () => {
    const { api, password } = await registerOrg({ name: 'MFA Off Co' });
    const setup = await api('/api/auth/mfa/setup', { method: 'POST' });
    await api('/api/auth/mfa/enable', { body: { code: totp(setup.body.secret) } });

    const noPassword = await api('/api/auth/mfa/disable', { body: {} });
    assert.equal(noPassword.status, 401);

    const ok = await api('/api/auth/mfa/disable', { body: { password } });
    assert.equal(ok.status, 200);
    const status = await api('/api/auth/mfa/status');
    assert.equal(status.body.enabled, false);
  });
});

/* ========================================================== documents ===== */
describe('document generation', () => {
  const items = [
    { description: 'Installation — 40 cameras', quantity: 40, unit_price: 2500, tax_rate: 18 },
    { description: 'NVR 32 channel', quantity: 1, unit_price: 48000, tax_rate: 18 }
  ];

  test('an invoice is numbered and its totals are computed on the server', async () => {
    const { api } = await registerOrg({ name: 'Docs Co' });
    const res = await api('/api/invoices', { body: { items, dueDate: '2026-12-31' } });
    assert.equal(res.status, 201);

    const { invoice, totals } = res.body;
    assert.match(invoice.number, /^INV-\d{4}-\d{4}$/);
    // 40 x 2500 = 100,000 + 48,000 = 148,000 subtotal; 18% tax = 26,640
    assert.equal(totals.subtotal, 148000);
    assert.equal(totals.tax_total, 26640);
    assert.equal(totals.total, 174640);
    assert.equal(Number(invoice.total), 174640);
    assert.equal(res.body.balance.status, 'sent');
  });

  test('GST is split into CGST and SGST, or charged as IGST', async () => {
    const { api } = await registerOrg({ name: 'GST Co' });
    const intra = await api('/api/invoices', { body: { items: [{ description: 'Service', quantity: 1, unit_price: 1000, tax_rate: 18 }], taxMode: 'cgst_sgst' } });
    const labels = intra.body.totals.tax_breakup.map((t) => t.label);
    assert.deepEqual(labels, ['CGST 9%', 'SGST 9%']);
    assert.equal(intra.body.totals.tax_total, 180);

    const inter = await api('/api/invoices', { body: { items: [{ description: 'Service', quantity: 1, unit_price: 1000, tax_rate: 18 }], taxMode: 'igst' } });
    assert.deepEqual(inter.body.totals.tax_breakup.map((t) => t.label), ['IGST 18%']);
  });

  test('a discount reduces the taxable value and the tax with it', async () => {
    const { api } = await registerOrg({ name: 'Discount Co' });
    const res = await api('/api/invoices', {
      body: { items: [{ description: 'Kit', quantity: 1, unit_price: 10000, tax_rate: 18 }], discount: 1000 }
    });
    assert.equal(res.body.totals.subtotal, 10000);
    assert.equal(res.body.totals.discount_total, 1000);
    assert.equal(res.body.totals.tax_total, 1620);   // 18% of 9,000
    assert.equal(res.body.totals.total, 10620);
  });

  test('issuing a document assigns a number, snapshots it, and renders a PDF', async () => {
    const { api } = await registerOrg({ name: 'PDF Co' });
    const created = await api('/api/invoices', { body: { items } });
    const id = created.body.invoice.id;

    const issued = await api(`/api/documents/invoice/${id}/issue`, { method: 'POST' });
    assert.equal(issued.status, 200);
    assert.equal(issued.body.version, 1);
    assert.match(issued.body.number, /^INV-/);

    const versions = await api(`/api/documents/invoice/${id}/versions`);
    assert.equal(versions.body.data.length, 1);

    const pdf = await fetch(`${(await boot())}/api/documents/invoice/${id}.pdf`, {
      headers: { cookie: Object.entries(api.jar).map(([k, v]) => `${k}=${v}`).join('; ') }
    });
    assert.equal(pdf.status, 200);
    assert.equal(pdf.headers.get('content-type'), 'application/pdf');
    const buf = Buffer.from(await pdf.arrayBuffer());
    assert.equal(buf.subarray(0, 5).toString(), '%PDF-', 'the file is a real PDF');
    assert.ok(buf.length > 2000, 'and has content');
  });

  test('branding is stored per organisation and used in the document', async () => {
    const { api } = await registerOrg({ name: 'Brand Co' });
    const saved = await api('/api/branding', {
      method: 'PATCH',
      body: { legalName: 'Brightline Security Solutions Pvt Ltd', gstin: '29ABCDE1234F1Z5', city: 'Bengaluru', terms: 'Payment within 15 days.' }
    });
    assert.equal(saved.status, 200);
    const read = await api('/api/branding');
    assert.equal(read.body.gstin, '29ABCDE1234F1Z5');
  });
});

/* ============================================================ finance ===== */
describe('payments and invoice balances', () => {
  async function invoiceOf(api, amount = 10000) {
    const res = await api('/api/invoices', {
      body: { items: [{ description: 'Work', quantity: 1, unit_price: amount, tax_rate: 0 }], dueDate: '2026-12-31' }
    });
    return res.body.invoice;
  }

  test('partial payments move the invoice through unpaid, partial and paid', async () => {
    const { api } = await registerOrg({ name: 'Pay Co' });
    const invoice = await invoiceOf(api, 10000);

    const first = await api(`/api/invoices/${invoice.id}/payments`, {
      body: { amount: 4000, method: 'upi', reference: 'UPI-9931' }
    });
    assert.equal(first.status, 201);
    assert.equal(first.body.balance.outstanding, 6000);
    assert.equal(first.body.balance.status, 'partially_paid');

    const second = await api(`/api/invoices/${invoice.id}/payments`, { body: { amount: 6000, method: 'bank_transfer' } });
    assert.equal(second.body.balance.outstanding, 0);
    assert.equal(second.body.balance.status, 'paid');

    const finance = await api(`/api/invoices/${invoice.id}/finance`);
    assert.equal(finance.body.payments.length, 2);
    assert.equal(finance.body.balance.paid, 10000);
  });

  test('the same idempotency key never records twice', async () => {
    const { api } = await registerOrg({ name: 'Idem Co' });
    const invoice = await invoiceOf(api, 5000);
    const body = { amount: 5000, method: 'cash', idempotencyKey: 'gateway-evt-1' };

    const a = await api(`/api/invoices/${invoice.id}/payments`, { body });
    const b = await api(`/api/invoices/${invoice.id}/payments`, { body });
    assert.equal(a.status, 201);
    assert.equal(b.body.duplicate, true);

    const finance = await api(`/api/invoices/${invoice.id}/finance`);
    assert.equal(finance.body.payments.length, 1);
  });

  test('a refund puts the balance back and cannot exceed the payment', async () => {
    const { api } = await registerOrg({ name: 'Refund Co' });
    const invoice = await invoiceOf(api, 8000);
    const pay = await api(`/api/invoices/${invoice.id}/payments`, { body: { amount: 8000, method: 'upi' } });
    const paymentId = pay.body.payment.id;

    const tooMuch = await api(`/api/payments/${paymentId}/refund`, { body: { amount: 9000 } });
    assert.equal(tooMuch.status, 400);

    const refund = await api(`/api/payments/${paymentId}/refund`, { body: { amount: 3000, reason: 'Returned NVR' } });
    assert.equal(refund.status, 201);
    assert.equal(refund.body.balance.outstanding, 3000);
    assert.equal(refund.body.balance.status, 'partially_paid');
  });

  test('a credit note reduces what the customer owes', async () => {
    const { api } = await registerOrg({ name: 'Credit Co' });
    const invoice = await invoiceOf(api, 12000);
    const note = await api(`/api/invoices/${invoice.id}/credit-note`, { body: { amount: 2000, reason: 'Rate correction' } });
    assert.equal(note.status, 201);
    assert.match(note.body.creditNote.number, /^CRN-/);
    assert.equal(note.body.balance.outstanding, 10000);
  });

  test('overdue invoices are identified, not guessed', async () => {
    const { api } = await registerOrg({ name: 'Overdue Co' });
    await api('/api/invoices', {
      body: { items: [{ description: 'Old work', quantity: 1, unit_price: 1000, tax_rate: 0 }], dueDate: '2020-01-01' }
    });
    const summary = await api('/api/finance/summary');
    assert.equal(summary.status, 200);
    assert.ok(summary.body.overdue.length >= 1);
  });

  test('a payment link is created, and says plainly when no gateway is configured', async () => {
    const { api } = await registerOrg({ name: 'Link Co' });
    const invoice = await invoiceOf(api, 7500);
    const link = await api(`/api/invoices/${invoice.id}/payment-link`, { method: 'POST' });
    assert.equal(link.status, 201);
    assert.equal(link.body.provider, 'manual');
    assert.match(link.body.link, /\/pay\//);
    assert.ok(link.body.note.includes('No gateway is configured'));

    const providers = await api('/api/finance/providers');
    const manual = providers.body.data.find((p) => p.key === 'manual');
    const razorpay = providers.body.data.find((p) => p.key === 'razorpay');
    assert.equal(manual.configured, true);
    assert.equal(razorpay.configured, false);
    assert.ok(razorpay.missing.includes('RAZORPAY_KEY_ID'));
  });

  test('a gateway webhook must be signed, and is applied once', async () => {
    delete process.env.PAYMENT_WEBHOOK_SECRET;
    const unsigned = await client()('/api/webhooks/payments/razorpay', { body: { id: 'evt-1' } });
    assert.equal(unsigned.status, 503, 'without a secret nothing can be verified');

    process.env.PAYMENT_WEBHOOK_SECRET = 'whsec_test';
    const { api, org } = await registerOrg({ name: 'Webhook Co' });
    const invoice = await invoiceOf(api, 2500);

    const payload = { id: 'evt-abc', event: 'payment.captured', org_id: org.id, invoice_id: invoice.id, amount: 2500 };
    const body = JSON.stringify(payload);
    const sig = crypto.createHmac('sha256', process.env.PAYMENT_WEBHOOK_SECRET).update(body).digest('hex');

    const anon = client();
    const bad = await anon('/api/webhooks/payments/razorpay', { body: payload, headers: { 'x-razorpay-signature': 'deadbeef' } });
    assert.equal(bad.status, 401);

    const good = await anon('/api/webhooks/payments/razorpay', { body: payload, headers: { 'x-razorpay-signature': sig } });
    assert.equal(good.status, 200);

    const finance = await api(`/api/invoices/${invoice.id}/finance`);
    assert.equal(finance.body.balance.status, 'paid');
    assert.equal(finance.body.payments.length, 1);

    const replay = await anon('/api/webhooks/payments/razorpay', { body: payload, headers: { 'x-razorpay-signature': sig } });
    assert.equal(replay.body.duplicate, true);
    const after = await api(`/api/invoices/${invoice.id}/finance`);
    assert.equal(after.body.payments.length, 1, 'a replayed event does not double-charge');
  });
});
