import { initDb, q } from '../src/db.js';

async function test() {
  await initDb();
  console.log('Testing db insert...');
  try {
    const res = await q('insert into users (email, password_hash, full_name) values ($1, $2, $3) returning id', ['test@test.com', 'hash', 'Test User']);
    console.log('Insert test user passed:', res[0].id);
    await q('delete from users where email = $1', ['test@test.com']);
  } catch (err) {
    console.error('Insert test user failed:', err);
  }
}
test();
