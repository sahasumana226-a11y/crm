// Tests for the growth surface: lead capture, API keys, webhooks,
// saved views, and the integration plumbing (with a stubbed provider).

process.env.ENCRYPTION_KEY = 'test-encryption-key-32-characters-long';

import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import { once } from 'node:events';
import { boot, shutdown, registerOrg, client } from './helpers.js';
import { q } from '../src/db.js';
import { __setFetch } from '../src/integrations.js';

before(async () => { await boot(); });
after(async () => { await shutdown(); });

describe('web-to-lead capture', () => {
  test('a public form creates a lead, with no session and no cookie', async () => {
    const owner = await registerOrg({ name: 'Capture Co' });
    const form = await owner.api('/api/web-forms', {
      body: { name: 'Website enquiry', required: ['name', 'email'], defaultSource: 'web_form' }
    });
    assert.equal(form.status, 201);
    const slug = form.body.slug;

    const anon = client(); // never logs in
    const submit = await anon(`/api/public/forms/${slug}`, {
      body: { name: 'Priya Nair', email: 'priya@example.test', phone: '+91 90000 00000', message: 'Need 14 outlets covered' }
    });
    assert.equal(submit.status, 201);
    assert.equal(submit.body.ok, true);

    const leads = await owner.api('/api/leads?q=Priya');
    assert.equal(leads.body.total, 1);
    assert.equal(leads.body.data[0].source, 'web_form');

    const forms = await owner.api('/api/web-forms');
    assert.equal(forms.body.data[0].submissions, 1);
  });

  test('required fields are enforced and the honeypot is silently dropped', async () => {
    const owner = await registerOrg({ name: 'Honeypot Co' });
    const form = await owner.api('/api/web-forms', {
      body: { name: 'Strict form', required: ['name', 'email'] }
    });
    const anon = client();

    const missing = await anon(`/api/public/forms/${form.body.slug}`, { body: { name: 'Only a name' } });
    assert.equal(missing.status, 400);

    const bot = await anon(`/api/public/forms/${form.body.slug}`, {
      body: { name: 'Bot', email: 'bot@example.test', _hp: 'gotcha' }
    });
    assert.equal(bot.status, 200, 'bots get a normal-looking answer');
    const leads = await owner.api('/api/leads');
    assert.equal(leads.body.total, 0, 'but nothing is stored');
  });

  test('submissions are rate limited per address', async () => {
    const owner = await registerOrg({ name: 'Rate Co' });
    const form = await owner.api('/api/web-forms', { body: { name: 'Rate form', required: ['name'] } });
    const anon = client();
    let limited = false;
    for (let i = 0; i < 12; i += 1) {
      const res = await anon(`/api/public/forms/${form.body.slug}`, { body: { name: `Person ${i}` } });
      if (res.status === 429) { limited = true; break; }
    }
    assert.ok(limited, 'the 11th submission in an hour should be refused');
  });

  test('the embed snippet posts to the right endpoint', async () => {
    const owner = await registerOrg({ name: 'Embed Co' });
    const form = await owner.api('/api/web-forms', { body: { name: 'Embed form' } });
    const embed = await owner.api(`/api/web-forms/${form.body.id}/embed`);
    assert.equal(embed.status, 200);
    assert.match(embed.body.html, /\/api\/public\/forms\//);
    assert.match(embed.body.html, /_hp/, 'honeypot field is included');
  });
});

describe('email-to-lead', () => {
  test('without INBOUND_SECRET the endpoint says so instead of failing oddly', async () => {
    delete process.env.INBOUND_SECRET;
    const api = client();
    const res = await api('/api/inbound/email', { body: { from: 'x@example.test' } });
    assert.equal(res.status, 503);
    assert.match(res.body.error, /not configured/i);
  });

  test('a signed email becomes a lead, and a repeat of the same message is ignored', async () => {
    process.env.INBOUND_SECRET = 'inbound-test-secret';
    const owner = await registerOrg({ name: 'Inbound Co' });
    process.env.INBOUND_ORG_ID = owner.org.id;   // documents how a server targets one workspace
    const payload = {
      from: 'Enquiry <newbuyer@example.test>',
      to: 'sales@inboundco.test',
      subject: 'Need CCTV for two warehouses',
      text: 'Please quote for 40 cameras.',
      messageId: 'msg-abc-123'
    };
    const body = JSON.stringify(payload);
    const sig = crypto.createHmac('sha256', process.env.INBOUND_SECRET).update(body).digest('hex');

    const anon = client();
    const bad = await anon('/api/inbound/email', {
      body: payload, headers: { 'x-anvaya-signature': 'sha256=deadbeef' }
    });
    assert.equal(bad.status, 401);

    const good = await anon('/api/inbound/email', {
      body: payload, headers: { 'x-anvaya-signature': `sha256=${sig}` }
    });
    assert.equal(good.status, 200);
    assert.ok(good.body.leadId);

    const again = await anon('/api/inbound/email', {
      body: payload, headers: { 'x-anvaya-signature': `sha256=${sig}` }
    });
    assert.equal(again.body.duplicate, true, 'same Message-ID is not processed twice');

    const leads = await owner.api('/api/leads?q=newbuyer');
    assert.equal(leads.body.total, 1);
    assert.equal(leads.body.data[0].source, 'email');
  });
});

describe('API keys', () => {
  test('a key is shown once, works as a bearer token, and honours its scope', async () => {
    const owner = await registerOrg({ name: 'Key Co' });
    await owner.api('/api/leads', { body: { name: 'Existing Lead' } });

    const created = await owner.api('/api/api-keys', { body: { name: 'Zapier', scope: 'read' } });
    assert.equal(created.status, 201);
    const key = created.body.key;
    assert.ok(key.startsWith('ak_live_'));

    const external = client();
    const withKey = (method, path, body) => external(path, {
      method, body, headers: { authorization: `Bearer ${key}` }
    });

    const list = await withKey('GET', '/api/leads');
    assert.equal(list.status, 200);
    assert.equal(list.body.total, 1);

    const write = await withKey('POST', '/api/leads', { name: 'Should fail' });
    assert.equal(write.status, 403, 'read scope cannot write');

    const badKey = await external('/api/leads', { headers: { authorization: 'Bearer ak_live_nope' } });
    assert.equal(badKey.status, 401);

    await owner.api(`/api/api-keys/${created.body.id}`, { method: 'DELETE' });
    const afterRevoke = await withKey('GET', '/api/leads');
    assert.equal(afterRevoke.status, 401, 'revoked keys stop working immediately');
  });
});

describe('outbound webhooks', () => {
  test('a created record is delivered with an HMAC signature', async () => {
    const owner = await registerOrg({ name: 'Hook Co' });
    let received = null;
    const receiver = http.createServer((req, res) => {
      let body = '';
      req.on('data', (c) => { body += c; });
      req.on('end', () => {
        received = { body, headers: req.headers };
        res.writeHead(200); res.end('ok');
      });
    });
    receiver.listen(0);
    await once(receiver, 'listening');
    const port = receiver.address().port;

    const hook = await owner.api('/api/webhooks', {
      body: { url: `http://127.0.0.1:${port}/hook`, events: ['lead.created'], description: 'test' }
    });
    assert.equal(hook.status, 201);
    const secret = hook.body.secret;

    await owner.api('/api/leads', { body: { name: 'Webhook Lead', company_name: 'Hook Co' } });
    await new Promise((r) => setTimeout(r, 400));

    assert.ok(received, 'the receiver was called');
    const expected = crypto.createHmac('sha256', secret).update(received.body).digest('hex');
    assert.equal(received.headers['x-anvaya-signature'], `sha256=${expected}`);
    assert.equal(received.headers['x-anvaya-event'], 'lead.created');

    const deliveries = await owner.api(`/api/webhooks/${hook.body.id}/deliveries`);
    assert.equal(deliveries.body.data[0].status, 'delivered');
    receiver.close();
  });

  test('non-https endpoints are refused', async () => {
    const owner = await registerOrg({ name: 'Hook Guard Co' });
    const res = await owner.api('/api/webhooks', { body: { url: 'http://evil.example.com/hook', events: ['*'] } });
    assert.equal(res.status, 400);
  });
});

describe('saved views', () => {
  test('a view stores filters and comes back for the same user', async () => {
    const owner = await registerOrg({ name: 'Views Co' });
    const made = await owner.api('/api/saved-views', {
      body: { resource: 'leads', name: 'Hot leads', filters: { status: 'qualified' } }
    });
    assert.equal(made.status, 201);
    const list = await owner.api('/api/saved-views?resource=leads');
    assert.equal(list.body.data.length, 1);
    assert.equal(list.body.data[0].filters.status, 'qualified');
  });
});

describe('integration plumbing', () => {
  test('unconfigured providers report exactly what is missing', async () => {
    delete process.env.GOOGLE_CLIENT_ID;
    delete process.env.GOOGLE_CLIENT_SECRET;
    const owner = await registerOrg({ name: 'Integrations Co' });

    const list = await owner.api('/api/integrations');
    assert.equal(list.status, 200);
    const gmail = list.body.data.find((d) => d.provider === 'gmail');
    assert.equal(gmail.configured, false);
    assert.deepEqual(gmail.missingEnv, ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET']);
    assert.equal(gmail.status, 'disconnected');

    const connect = await owner.api('/api/integrations/gmail/connect', { method: 'POST' });
    assert.equal(connect.status, 409);
    assert.match(connect.body.error, /not configured/i);
  });

  test('a configured provider completes the flow and syncs with de-duplication', async () => {
    process.env.GOOGLE_CLIENT_ID = 'test-client';
    process.env.GOOGLE_CLIENT_SECRET = 'test-secret';
    const owner = await registerOrg({ name: 'Sync Co' });
    await owner.api('/api/contacts', { body: { first_name: 'Kavita', email: 'kavita@example.test' } });

    const connect = await owner.api('/api/integrations/gmail/connect', { method: 'POST' });
    assert.equal(connect.status, 200);
    assert.match(connect.body.authUrl, /accounts\.google\.com/);
    assert.match(connect.body.authUrl, /state=/);

    // Pull the nonce the server stored, then play the provider's part.
    const row = (await q(
      `select org_id, config->>'state' as state from integrations where provider = 'gmail' order by created_at desc limit 1`
    ))[0];
    assert.ok(row.state);

    __setFetch(async (url) => {
      if (String(url).includes('oauth2.googleapis.com')) {
        return { ok: true, json: async () => ({ access_token: 'tok', refresh_token: 'ref', expires_in: 3600 }) };
      }
      if (String(url).includes('messages?') || String(url).includes('/messages?')) {
        return { ok: true, json: async () => ({ messages: [{ id: 'm1' }, { id: 'm2' }] }) };
      }
      if (String(url).includes('/messages/m')) {
        return {
          ok: true,
          json: async () => ({
            internalDate: String(Date.now()),
            snippet: 'Quote attached',
            payload: { headers: [
              { name: 'Subject', value: 'Re: AMC renewal' },
              { name: 'From', value: 'Kavita <kavita@example.test>' }
            ] }
          })
        };
      }
      return { ok: false, status: 404, json: async () => ({}) };
    });

    const callback = await client()(`/api/integrations/callback?code=abc&state=${row.org_id}:${row.state}`);
    assert.equal(callback.status, 200);

    const after = await owner.api('/api/integrations');
    assert.equal(after.body.data.find((d) => d.provider === 'gmail').status, 'connected');

    const first = await owner.api('/api/integrations/gmail/sync', { method: 'POST' });
    assert.equal(first.status, 200);
    assert.equal(first.body.created, 2, 'two messages became two activities');

    const second = await owner.api('/api/integrations/gmail/sync', { method: 'POST' });
    assert.equal(second.body.created, 0, 'the same messages are not imported twice');

    const activities = await owner.api('/api/activities?type=email');
    assert.ok(activities.body.total >= 2);
  });
});

describe('api surface', () => {
  test('an OpenAPI document is published for Zapier, Make and Postman', async () => {
    const api = client();
    const res = await api('/api/openapi.json');
    assert.equal(res.status, 200);
    assert.equal(res.body.openapi, '3.0.3');
    assert.ok(res.body.paths['/api/leads']);
    assert.ok(res.body.paths['/api/public/forms/{slug}']);
    assert.ok(res.body.components.securitySchemes.bearer);
  });

  test('health advertises the optional capabilities', async () => {
    const api = client();
    const res = await api('/api/health');
    assert.equal(res.body.mode, 'server');
    assert.ok(res.body.capabilities.includes('web-forms'));
    assert.ok(res.body.capabilities.includes('api-keys'));
  });
});
