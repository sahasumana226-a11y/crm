import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { boot, shutdown, registerOrg, client, uniqueEmail } from './helpers.js';

before(async () => { await boot(); });
after(async () => { await shutdown(); });

describe('auth and organisation bootstrap', () => {
  test('health endpoint reports the database is reachable', async () => {
    const api = client();
    const res = await api('/api/health');
    assert.equal(res.status, 200);
    assert.equal(res.body.ok, true);
  });

  test('registration creates an org, owner role, pipeline and session', async () => {
    const { api } = await registerOrg({ name: 'Nimbus Systems' });
    const me = await api('/api/auth/me');
    assert.equal(me.status, 200);
    assert.equal(me.body.org.name, 'Nimbus Systems');
    assert.equal(me.body.role.key, 'owner');
    assert.ok(me.body.perms.includes('*'), 'owner should hold the wildcard permission');

    const pipelines = await api('/api/pipelines');
    assert.equal(pipelines.status, 200);
    assert.equal(pipelines.body.data.length, 1);
    assert.equal(pipelines.body.data[0].stages.length, 6);
  });

  test('weak passwords are rejected', async () => {
    const api = client();
    const res = await api('/api/auth/register', {
      body: { email: uniqueEmail('weak'), password: 'short', fullName: 'X Y', orgName: 'Weak Co' }
    });
    assert.equal(res.status, 400);
    assert.match(res.body.error, /at least 10 characters/);
  });

  test('duplicate email cannot register twice', async () => {
    const email = uniqueEmail('dup');
    await registerOrg({ email, name: 'First Co' });
    const api = client();
    const res = await api('/api/auth/register', {
      body: { email, password: 'TestPassword123', fullName: 'Someone', orgName: 'Second Co' }
    });
    assert.equal(res.status, 409);
  });

  test('login fails with a wrong password and succeeds with the right one', async () => {
    const email = uniqueEmail('login');
    const { password } = await registerOrg({ email });
    const api = client();
    const bad = await api('/api/auth/login', { body: { email, password: 'WrongPassword123' } });
    assert.equal(bad.status, 401);

    const good = await api('/api/auth/login', { body: { email, password } });
    assert.equal(good.status, 200);
    const me = await api('/api/auth/me');
    assert.equal(me.status, 200);
  });

  test('unauthenticated requests are refused', async () => {
    const api = client();
    const res = await api('/api/leads');
    assert.equal(res.status, 401);
  });

  test('logout invalidates the session', async () => {
    const { api } = await registerOrg({ name: 'Logout Co' });
    assert.equal((await api('/api/auth/me')).status, 200);
    await api('/api/auth/logout', { method: 'POST' });
    assert.equal((await api('/api/auth/me')).status, 401);
  });
});

describe('core CRM workflow: lead -> qualify -> convert -> deal -> follow-up', () => {
  test('the full workflow runs end to end', async () => {
    const { api } = await registerOrg({ name: 'Workflow Co' });

    // 1. create a lead
    const created = await api('/api/leads', {
      body: {
        name: 'Rahul Menon', company_name: 'Meridian Retail', email: 'rahul@meridian.test',
        phone: '+91 98450 00000', source: 'website', estimated_value: 250000, status: 'new'
      }
    });
    assert.equal(created.status, 201);
    const leadId = created.body.id;
    assert.equal(created.body.status, 'new');

    // 2. qualify it
    const qualified = await api(`/api/leads/${leadId}`, { method: 'PATCH', body: { status: 'qualified', score: 82 } });
    assert.equal(qualified.status, 200);
    assert.equal(qualified.body.status, 'qualified');

    // 3. convert: contact + company + deal + activity
    const converted = await api(`/api/leads/${leadId}/convert`, { body: { dealTitle: 'CCTV rollout', dealValue: 250000 } });
    assert.equal(converted.status, 200);
    assert.ok(converted.body.contact.id);
    assert.ok(converted.body.deal.id);
    assert.ok(converted.body.company.id, 'a company is created from the lead');
    assert.equal(converted.body.lead.status, 'converted');
    assert.equal(converted.body.lead.converted_deal_id, converted.body.deal.id);

    // 4. deal starts in the first stage
    const deals = await api('/api/deals');
    const deal = deals.body.data.find(d => d.id === converted.body.deal.id);
    assert.equal(deal.stage_name, 'Discovery');
    assert.equal(deal.status, 'open');

    // 5. move it through the pipeline to won
    const pipelines = await api('/api/pipelines');
    const stages = pipelines.body.data[0].stages;
    const negotiation = stages.find(s => s.name === 'Negotiation');
    const won = stages.find(s => s.is_won);

    const moved = await api(`/api/deals/${deal.id}/stage`, { method: 'PATCH', body: { stageId: negotiation.id } });
    assert.equal(moved.status, 200);
    assert.equal(moved.body.probability, negotiation.probability);

    const closed = await api(`/api/deals/${deal.id}/stage`, { method: 'PATCH', body: { stageId: won.id } });
    assert.equal(closed.body.status, 'won');
    assert.equal(closed.body.probability, 100);

    // 6. schedule a follow-up task linked to the deal
    const task = await api('/api/tasks', {
      body: {
        title: 'Kick-off call with Rahul', priority: 'high', status: 'open',
        due_date: new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10),
        related_type: 'deal', related_id: deal.id
      }
    });
    assert.equal(task.status, 201);

    // 7. the customer 360 view assembles the whole story
    const c360 = await api(`/api/contacts/${converted.body.contact.id}/360`);
    assert.equal(c360.status, 200);
    assert.equal(c360.body.deals.length, 1);
    assert.ok(c360.body.activities.length >= 1, 'conversion writes an activity');
    assert.equal(Number(c360.body.lifetime), 250000);

    // 8. the audit trail recorded the moves
    const audit = await api('/api/audit-logs');
    assert.equal(audit.status, 200);
    const actions = audit.body.data.map(a => a.action);
    assert.ok(actions.includes('leads.created'));
    assert.ok(actions.includes('lead.converted'));
    assert.ok(actions.includes('deal.stage_changed'));
  });

  test('converting the same lead twice is refused', async () => {
    const { api } = await registerOrg({ name: 'Twice Co' });
    const lead = await api('/api/leads', { body: { name: 'A Person', company_name: 'Acme' } });
    await api(`/api/leads/${lead.body.id}/convert`, { body: {} });
    const again = await api(`/api/leads/${lead.body.id}/convert`, { body: {} });
    assert.equal(again.status, 409);
  });
});

describe('workflow automation', () => {
  test('a website lead triggers the seeded-style automation and creates a task', async () => {
    const { api } = await registerOrg({ name: 'Automation Co' });

    const wf = await api('/api/workflows', {
      body: {
        name: 'Website lead first response',
        status: 'active',
        trigger: { event: 'lead.created', entity: 'lead' },
        conditions: [{ field: 'source', op: 'eq', value: 'website' }],
        actions: [
          { type: 'create_task', title: 'First response to {{name}}', dueInDays: 1, priority: 'high' },
          { type: 'notify', title: 'New website lead' }
        ]
      }
    });
    assert.equal(wf.status, 201);

    const before = await api('/api/tasks');
    const beforeCount = before.body.total;

    await api('/api/leads', { body: { name: 'Web Enquiry', source: 'website', company_name: 'Inbound Ltd' } });

    const afterTasks = await api('/api/tasks');
    assert.equal(afterTasks.body.total, beforeCount + 1);
    assert.match(afterTasks.body.data[0].title, /First response to Web Enquiry/);

    const runs = await api('/api/workflows/runs');
    assert.equal(runs.status, 200);
    assert.equal(runs.body.data.length, 1);
    assert.equal(runs.body.data[0].status, 'succeeded');

    const steps = await api(`/api/workflows/runs/${runs.body.data[0].id}/steps`);
    assert.equal(steps.body.data.length, 2);
    assert.deepEqual(steps.body.data.map(s => s.node_type), ['create_task', 'notify']);
  });

  test('conditions that do not match skip the run', async () => {
    const { api } = await registerOrg({ name: 'Skip Co' });
    await api('/api/workflows', {
      body: {
        name: 'Referral only', status: 'active',
        trigger: { event: 'lead.created', entity: 'lead' },
        conditions: [{ field: 'source', op: 'eq', value: 'referral' }],
        actions: [{ type: 'create_task', title: 'Call {{name}}' }]
      }
    });
    const before = await api('/api/tasks');
    await api('/api/leads', { body: { name: 'Website Person', source: 'website' } });
    const afterTasks = await api('/api/tasks');
    assert.equal(afterTasks.body.total, before.body.total);

    const runs = await api('/api/workflows/runs');
    assert.equal(runs.body.data[0].status, 'skipped');
  });

  test('a send_email action waits for approval instead of claiming delivery', async () => {
    const { api } = await registerOrg({ name: 'Approval Co' });
    await api('/api/workflows', {
      body: {
        name: 'Won follow-up', status: 'active',
        trigger: { event: 'deal.won', entity: 'deal' },
        conditions: [],
        actions: [{ type: 'send_email', to: 'customer', subject: 'Thanks', body: 'Hello' }]
      }
    });
    const lead = await api('/api/leads', { body: { name: 'Deal Person', company_name: 'Won Co' } });
    const conv = await api(`/api/leads/${lead.body.id}/convert`, { body: {} });
    const stages = (await api('/api/pipelines')).body.data[0].stages;
    const won = stages.find(s => s.is_won);
    await api(`/api/deals/${conv.body.deal.id}/stage`, { method: 'PATCH', body: { stageId: won.id } });

    const runs = await api('/api/workflows/runs');
    assert.equal(runs.body.data[0].status, 'awaiting_approval');
  });
});

describe('copilot', () => {
  test('answers from records without a model configured, and says which mode it used', async () => {
    const { api } = await registerOrg({ name: 'Copilot Co' });
    await api('/api/leads', {
      body: { name: 'Hot Lead', company_name: 'Big Co', status: 'qualified', score: 90, estimated_value: 900000 }
    });

    const res = await api('/api/ai/copilot', { body: { message: 'Show me all qualified leads from this month' } });
    assert.equal(res.status, 200);
    assert.equal(res.body.mode, 'local');
    assert.match(res.body.answer, /qualified/i);
    assert.ok(Array.isArray(res.body.bullets));
    assert.ok(res.body.basis.length > 0, 'the answer explains how it was derived');
    assert.ok(res.body.runId);
  });

  test('a proposed write is stored and only applied on approval', async () => {
    const { api } = await registerOrg({ name: 'Action Co' });
    const overdue = await api('/api/tasks', {
      body: { title: 'Overdue call', priority: 'high', status: 'open', due_date: '2020-01-01' }
    });
    assert.equal(overdue.status, 201);

    const res = await api('/api/ai/copilot', { body: { message: 'Create follow-up tasks for overdue opportunities' } });
    assert.equal(res.body.proposedActions.length, 1);
    const actionId = res.body.proposedActions[0].id;
    assert.equal(res.body.proposedActions[0].status, 'proposed');

    const beforeCount = (await api('/api/tasks')).body.total;
    const approved = await api(`/api/ai/actions/${actionId}/approve`, { method: 'POST' });
    assert.equal(approved.status, 200);
    assert.equal(approved.body.status, 'applied');
    const afterCount = (await api('/api/tasks')).body.total;
    assert.equal(afterCount, beforeCount + 1);

    const reject = await api(`/api/ai/actions/${actionId}/reject`, { method: 'POST' });
    assert.equal(reject.status, 409, 'an applied action cannot be re-decided');
  });
});

describe('analytics', () => {
  test('dashboard numbers are computed from records, not hardcoded', async () => {
    const { api } = await registerOrg({ name: 'Numbers Co' });
    const empty = await api('/api/dashboard');
    assert.equal(empty.status, 200);
    assert.equal(Number(empty.body.kpi.pipeline_value), 0);

    const lead = await api('/api/leads', { body: { name: 'P', company_name: 'C', estimated_value: 500000 } });
    const conv = await api(`/api/leads/${lead.body.id}/convert`, { body: { dealValue: 750000 } });

    const dash = await api('/api/dashboard');
    assert.equal(Number(dash.body.kpi.pipeline_value), 750000);
    assert.equal(dash.body.kpi.open_deals, 1);

    const stages = (await api('/api/pipelines')).body.data[0].stages;
    await api(`/api/deals/${conv.body.deal.id}/stage`, {
      method: 'PATCH', body: { stageId: stages.find(s => s.is_won).id }
    });
    const after = await api('/api/dashboard');
    assert.equal(Number(after.body.kpi.pipeline_value), 0);
    assert.equal(Number(after.body.kpi.won_value), 750000);
  });
});
