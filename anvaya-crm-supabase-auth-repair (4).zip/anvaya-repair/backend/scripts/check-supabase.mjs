#!/usr/bin/env node
// Production schema doctor. Reads DATABASE_URL only from the process environment.
import { initDb, databaseDiagnostics, closeDb } from '../src/db.js';

async function main() {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required.');
  await initDb();
  const report = await databaseDiagnostics();
  console.log(JSON.stringify({
    provider: report.provider,
    driver: report.driver,
    connectionStatus: report.connectionStatus,
    schemaStatus: report.schemaStatus,
    missingSchema: report.missingSchema,
    migrationStatus: report.migrationStatus,
    rlsStatus: report.rlsStatus,
    rlsPolicyCount: report.rlsPolicyCount,
    roleStatus: report.roleStatus,
    authenticationStatus: report.authenticationStatus,
    workspaceStatus: report.workspaceStatus
  }, null, 2));
  if (report.driver !== 'pg' || report.schemaStatus !== 'valid' ||
      report.migrationStatus !== 'current' || report.rlsStatus !== 'enabled' ||
      report.roleStatus !== 'valid') process.exitCode = 1;
}

main().catch(err => {
  console.error('[supabase-doctor] failed', { code: err.code || 'DOCTOR_FAILED', message: err.message });
  process.exitCode = 1;
}).finally(async () => {
  await closeDb().catch(() => {});
});
