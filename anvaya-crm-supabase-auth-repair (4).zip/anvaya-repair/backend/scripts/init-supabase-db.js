// Safe compatibility entry point. Uses DATABASE_URL only; never resets schema or seeds demo identities.
import { initDb, migrate, databaseDiagnostics, closeDb } from '../src/db.js';

async function main() {
  if (!process.env.DATABASE_URL) throw new Error('Set DATABASE_URL in the environment before running this command.');
  await initDb();
  const applied = await migrate();
  const report = await databaseDiagnostics();
  if (report.schemaStatus !== 'valid' || report.migrationStatus !== 'current' ||
      report.rlsStatus !== 'enabled' || report.roleStatus !== 'valid') {
    throw new Error('Database migration completed but production verification did not pass.');
  }
  console.log(JSON.stringify({ status: 'verified', appliedMigrations: applied, driver: report.driver }, null, 2));
}

main().catch(err => {
  console.error('[supabase] setup failed', { code: err.code || 'SETUP_FAILED', message: err.message });
  process.exitCode = 1;
}).finally(async () => {
  await closeDb().catch(() => {});
});
