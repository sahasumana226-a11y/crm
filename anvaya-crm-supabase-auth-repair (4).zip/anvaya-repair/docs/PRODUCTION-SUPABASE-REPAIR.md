# Anvaya CRM production database and authentication repair

## Architecture decisions

- Supabase PostgreSQL is the only production database. `DATABASE_URL` is mandatory in production.
- The `pg` pool is created once per warm serverless instance and shared by concurrent requests. The default pool maximum is 3 connections per instance; set `DB_POOL_SIZE` conservatively against the Supabase pooler connection budget.
- A failed PostgreSQL initialization does not create a local database, mutate environment variables, or cache a failed promise. A later invocation can retry.
- PGlite is available only when explicitly selected for local development (`DB_MODE=pglite`) or the isolated test harness. Never set `DB_MODE` in Vercel.
- Versioned files in `backend/db/migrations/` are canonical. The legacy `supabase/*.sql` bootstrap bundle and setup scripts are retained for reference but must not be run as a competing schema installer.
- Migrations are run as a release step (`npm run migrate`), not from a Vercel request handler. Each file is recorded in `anvaya_schema_migrations` in the same transaction as its DDL.
- The frontend's demo engine is opt-in only: set `<meta name="anvaya-demo" content="true">` in a local development copy to use it. Production ships `false`. Auth and health requests are never cached, queued, or sent to the demo engine.

## Supabase setup

1. In Supabase Dashboard, open **Project Settings → Database → Connection string → URI**.
2. For Vercel/serverless, choose the **Transaction pooler** connection string (normally port `6543`). Use the exact username and hostname shown for the project. URL-encode special characters in the database password.
3. Set the connection string only as the server-side `DATABASE_URL` environment variable. Do not prefix it with `VITE_` and do not put it in browser files.
4. Keep TLS enabled. The pool defaults to TLS; `DATABASE_SSL=0` is intentionally ignored in production.
5. Ensure the database role used by `DATABASE_URL` can run the versioned migrations. The app's request role defaults to `authenticated`; set `DB_USER_ROLE` only if the Supabase role and grants have been deliberately configured.
6. Run migrations once from a trusted release environment with network access to the Supabase project:

   ```bash
   cd backend
   npm ci
   npm run migrate
   ```

7. Confirm `GET /api/health` returns HTTP 200 and JSON with `driver: "pg"`, `connectionStatus: "connected"`, `schemaStatus: "valid"`, `migrationStatus: "current"`, `rlsStatus: "enabled"`, and `roleStatus: "valid"`.

Migrations `006_account_status.sql` and `007_legacy_schema_compat.sql` add the account lifecycle status, case-insensitive unique email index, and missing columns/relationships from the older 29-table SQL bundle. Existing account rows default to `active`; legacy workspace membership is backfilled only when exactly one default workspace exists for the organisation. Ambiguous memberships are left untouched and fail the health check until assigned explicitly. If the index creation fails because legacy data contains case-variant duplicate emails, stop and reconcile those identities manually before retrying; do not merge or delete customer records automatically.

## Vercel environment

Configure these under **Project → Settings → Environment Variables** for the environments that actually deploy:

| Variable | Requirement |
|---|---|
| `DATABASE_URL` | Required; Supabase transaction pooler URI |
| `SUPABASE_PROJECT_REF` | Set to the intended project ref if it cannot be derived from the URI username/host |
| `NODE_ENV` | `production` |
| `DB_USER_ROLE` | Usually `authenticated`; verify the Supabase role grants |
| `DB_POOL_SIZE` | Optional; default `3` per serverless instance |
| `DB_CONNECTION_TIMEOUT_MS` | Optional; default `7000` |
| `DB_QUERY_TIMEOUT_MS` | Optional; default `15000` |
| `ENCRYPTION_KEY` | Required by encrypted integration/token features; generate a strong 32+ character value |
| `CORS_ORIGIN` | Optional comma-separated exact origins only, if frontend and API are hosted on different origins |\n| `COOKIE_SAME_SITE` | Optional; default `lax`. Use `none` only for a genuinely cross-site frontend over HTTPS |

Do not set `DB_MODE=pglite`, `DB_MEMORY`, `PG_SHIM`, or `DATABASE_SSL=0` in Vercel. Environment changes require a new deployment. `.env` files are for local development and are not uploaded automatically by Vercel.

## Release and verification sequence

1. Set Vercel environment variables.
2. From a secure release environment, run `npm run migrate` against the same Supabase project.
3. Deploy the frontend and serverless API.
4. Verify `/api/health`; a 503 or a non-current migration/RLS/role status is a release blocker.
5. Test a new registration using a unique test email; verify the user, organisation, workspace, owner membership, role, pipeline, stages, subscription and session in Supabase.
6. Test sign-in, refresh, a new browser session, workspace restoration, invalid credentials and logout.
7. Test cross-organisation access with two distinct test accounts.
8. Remove test accounts and their test organisations only through a reviewed, explicit cleanup procedure.

The API's public health response exposes only safe status fields. Database passwords, complete connection strings, password hashes and session tokens are never returned.

## Operational limitations

- The code changes can be syntax-checked locally, but a real Supabase connection, migration, RLS grants and Vercel environment cannot be verified without access to the target project.
- The in-process rate limiter is per serverless instance. For high-volume public registration/login, add a shared edge/WAF or distributed rate-limit service.
- Existing case-variant duplicate user emails, schema drift, unavailable Supabase projects, incorrect pooler credentials, and missing role grants require operator action; the application now fails closed instead of creating a local substitute.
