# Supabase-only architecture note

This project currently uses the Express backend with PostgreSQL-backed scrypt password authentication and persistent HTTP-only cookie sessions.

A migration to Supabase Auth/PostgREST/Edge Functions would be a separate architectural project. It is intentionally not partially enabled here: mixing Supabase Auth with the existing session system would create competing identities and risk existing customer access.

For the current production architecture, configure `DATABASE_URL` and apply only `backend/db/migrations/`. See `docs/PRODUCTION-SUPABASE-REPAIR.md`.
