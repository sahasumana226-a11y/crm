# Connecting Anvaya CRM to Supabase

Anvaya uses one production identity and data path: the Express API, its PostgreSQL driver (`pg`), and Supabase PostgreSQL. Supabase Auth is not enabled as a parallel login system.

## 1. Create the database connection

In Supabase Dashboard, open **Project Settings → Database → Connection string → URI**. For Vercel/serverless, select the **Transaction pooler** URI (normally port `6543`). Use the exact host and username displayed for the project. URL-encode special characters in the password.

Set the full URI as the server-side `DATABASE_URL` environment variable. Never put it in a `VITE_` variable, browser source, or a public repository.

## 2. Apply the canonical schema

The only canonical migration source is `backend/db/migrations/`. From a trusted release environment with access to the database:

```bash
cd backend
npm ci
npm run migrate
```

Do not execute the legacy `supabase/anvaya-supabase.sql` bundle or its component scripts. Do not run any reset/setup script that drops or recreates the `public` schema. The migration runner is additive and versioned.

## 3. Configure Vercel

Set `DATABASE_URL`, `NODE_ENV=production`, and (normally) `DB_USER_ROLE=authenticated` in **Vercel → Project → Settings → Environment Variables**. Optional `DB_POOL_SIZE` defaults to 3. See `docs/PRODUCTION-SUPABASE-REPAIR.md` for the complete list.

Do not set `DB_MODE=pglite`, `DB_MEMORY`, or `PG_SHIM` in Vercel. The backend requires a real Supabase PostgreSQL connection in production.

## 4. Verify

After the migration and deployment, call:

```bash
curl -i https://YOUR-APP-DOMAIN/api/health
```

A production-ready response must be HTTP 200 and report `driver: "pg"`, `connectionStatus: "connected"`, `schemaStatus: "valid"`, `migrationStatus: "current"`, `rlsStatus: "enabled"`, and `roleStatus: "valid"`. A 503 is a deliberate fail-closed response; inspect the safe status fields and server logs.

## Credential hygiene

The source archive supplied for this repair contained a `.env` file and legacy utility scripts with embedded database credentials. Those files/scripts have been removed or replaced in the repaired archive. Treat the credentials from the original archive as exposed and rotate the Supabase database password before deploying. Review Vercel environment variables and update them with the newly rotated value. Do not paste secrets into chat or commit them to source control.
