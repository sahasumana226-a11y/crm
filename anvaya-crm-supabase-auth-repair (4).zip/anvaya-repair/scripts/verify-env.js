import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.join(__dirname, '..');
const backendEnvPath = path.join(rootDir, 'backend', '.env');
const rootEnvPath = path.join(rootDir, '.env');

console.log('==================================================');
console.log('Environment Verification Tool (scripts/verify-env.js)');
console.log('==================================================\n');

function checkEnvFile(filePath, label) {
  console.log(`[1] Checking existence of ${label} (${filePath})...`);
  if (!fs.existsSync(filePath)) {
    console.warn(`    ⚠️  Warning: ${label} file does NOT exist at path.`);
    return null;
  }
  console.log(`    ✅ Success: ${label} file exists.`);
  
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const envVars = {};
    for (const line of content.split('\n')) {
      const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
      if (match && !match[1].startsWith('#')) {
        let val = match[2] || '';
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        envVars[match[1]] = val;
      }
    }
    return envVars;
  } catch (err) {
    console.error(`    ❌ Error reading ${label}:`, err.message);
    return null;
  }
}

const backendVars = checkEnvFile(backendEnvPath, 'backend/.env');
console.log('');
const rootVars = checkEnvFile(rootEnvPath, 'root .env');

console.log('\n[2] Verifying DATABASE_URL format...');
const dbUrl = (backendVars && backendVars.DATABASE_URL) || (rootVars && rootVars.DATABASE_URL) || process.env.DATABASE_URL;

if (!dbUrl) {
  console.error('    ❌ Error: DATABASE_URL is not defined in .env files or process.env!');
} else {
  console.log('    ✅ Success: DATABASE_URL found.');
  const masked = dbUrl.replace(/:[^:@]+@/, ':****@');
  console.log(`    📋 Masked URL: ${masked}`);

  const pgRegex = /^postgres(?:ql)?:\/\/([^:]+:[^@]+@)?([^:\/]+)(?::([0-9]+))?(\/[^\?]+)?(\?.*)?$/i;
  if (pgRegex.test(dbUrl)) {
    console.log('    ✅ Success: DATABASE_URL is properly formatted as a PostgreSQL connection string.');
  } else {
    console.warn('    ⚠️  Warning: DATABASE_URL format does not strictly match standard postgresql:// schema.');
  }
}

console.log('\n[3] Verifying Node process environment accessibility...');
if (process.env.DATABASE_URL) {
  console.log('    ✅ Success: DATABASE_URL is accessible in process.env.');
} else {
  console.warn('    ⚠️  Warning: DATABASE_URL is NOT currently loaded in process.env (Node runtime).');
}

console.log('\n==================================================');
console.log('Verification completed.');
console.log('==================================================');
