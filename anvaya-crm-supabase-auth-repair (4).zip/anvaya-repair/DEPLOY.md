# Anvaya CRM — production deployment

## Supported production architecture

- Frontend: existing static Anvaya CRM UI, served from Vercel `dist/`.
- API: Express app through the Vercel serverless entry point `api/index.js`.
- Database: Supabase PostgreSQL through the `pg` driver.
- Authentication: existing scrypt password hashes, database-backed opaque sessions, HTTP-only cookies.
- Migrations: versioned SQL in `backend/db/migrations/`, applied as a release step.

Production never falls back to PGlite, browser storage authentication, or simulated workspaces.

## 1. Supabase

1. Create or select the intended Supabase project.
2. Open **Project Settings → Database → Connection string → URI**.
3. Select the **Transaction pooler** connection string for Vercel/serverless (normally port `6543`).
4. Keep the database password server-side and URL-encode special characters.
5. From a trusted release environment, set `DATABASE_URL` and run:

   ```bash
   npm ci
   npm run migrate
   ```

6. Do not run legacy `supabase/*.sql` bundles, destructive setup scripts, or database reset commands. `backend/db/migrations/` is the canonical schema.

## 2. Vercel environment variables

Configure these for Production (and Preview if required):

- `DATABASE_URL` — Supabase transaction pooler URI; required.
- `NODE_ENV=production`
- `DB_USER_ROLE=authenticated` — confirm this role exists and has the grants installed by the RLS migration.
- `DB_POOL_SIZE=3` — optional per-instance pool maximum.
- `ENCRYPTION_KEY` — strong random value of at least 32 characters for encrypted integration credentials.
- `CORS_ORIGIN` — exact comma-separated origin allow-list only if frontend and API use different origins.
- `COOKIE_SAME_SITE=lax` — default. Use `none` only for a genuinely cross-site frontend over HTTPS.

Never set `DB_MODE=pglite`, `DB_MEMORY`, or `PG_SHIM` in Vercel. Do not expose secrets in frontend variables.

## 3. Deploy

Deploy the repository root. `vercel.json` routes `/api/*` to `api/index.js` and all other routes to the existing frontend. `.vercelignore` must retain both `api/` and `backend/` source files; excluding either breaks the serverless function import graph.

The build step only assembles static frontend files. It does not attempt to connect to Supabase or run migrations. This prevents build-time network conditions from being mistaken for a successful database release.

## 4. Verify production

Run:

```bash
curl -i https://YOUR-APP-DOMAIN/api/health
```

A healthy response is HTTP 200 with `driver=pg`, `connectionStatus=connected`, `schemaStatus=valid`, `migrationStatus=current`, `rlsStatus=enabled`, and `roleStatus=valid`.

Then test with a new, unique account:
- register and confirm the API returns 201;
- verify user, organisation, workspace, owner membership, role, pipeline, stages and session in Supabase;
- refresh and reopen the browser; confirm `/api/auth/me` restores the same workspace;
- reject an incorrect password;
- log out and confirm the session row is revoked;
- verify two organisations cannot read each other's CRM records.

A health 503 or a schema/migration/RLS/role failure is a release blocker. The endpoint intentionally avoids reporting a cached successful connection.

## 5. Credential rotation

The original uploaded archive included a `.env` file and several legacy scripts with embedded database credentials. They have been removed or replaced in the repaired archive. Rotate the Supabase database password before deployment, then update `DATABASE_URL` in Vercel and any trusted release environment. Never commit `.env` or share the new value in chat.

For detailed notes, see `docs/PRODUCTION-SUPABASE-REPAIR.md`.
