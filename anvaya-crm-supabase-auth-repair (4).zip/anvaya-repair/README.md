# Anvaya CRM V6

Anvaya CRM is a multi-tenant CRM with an existing static frontend, an Express API, and a PostgreSQL persistence layer. The production UI is preserved; authentication and workspace data are served by the backend.

## Production architecture

- Frontend: `index.html`, `app.js`, `styles.css` and the existing CRM modules.
- API: `api/index.js` → `backend/src/app.js` (Vercel serverless).
- Database: Supabase PostgreSQL through `pg`. Production requires `DATABASE_URL`; no PGlite or browser-auth fallback is permitted.
- Authentication: existing scrypt password hashes, database-backed sessions, hashed session tokens, HTTP-only cookies.
- Schema: `backend/db/migrations/` is the only canonical migration source.

## Run locally

1. Copy `backend/.env.example` to `backend/.env`.
2. For an isolated local demo only, leave `DB_MODE=pglite` enabled. For a real Supabase test, set `DATABASE_URL` and `DB_USER_ROLE=authenticated`.
3. Install and apply the schema:

   ```bash
   cd backend
   npm ci
   npm run migrate
   npm start
   ```

4. Open `http://localhost:4000`.

The demo engine is not loaded by default. To enable it for local-only UI exploration, explicitly change the local `index.html` setting to `<meta name="anvaya-demo" content="true">`. Never enable this in a production deployment. Do not use demo credentials for real customer data.

## Deploy to Vercel + Supabase

1. Create/select a Supabase project and copy its **Transaction pooler** connection URI (normally port `6543`).
2. From a trusted release environment, set `DATABASE_URL` and run `cd backend && npm ci && npm run migrate`.
3. Configure Vercel environment variables: `DATABASE_URL`, `NODE_ENV=production`, `DB_USER_ROLE=authenticated`, and `ENCRYPTION_KEY` for encrypted integrations. See `docs/PRODUCTION-SUPABASE-REPAIR.md`.
4. Deploy the repository root. `.vercelignore` must include the `api/` function and `backend/` source tree. `vercel.json` routes API requests to `api/index.js`.
5. Verify `GET /api/health` returns HTTP 200 with `driver=pg`, connected database, current migrations, enabled RLS and valid role permissions.
6. Test registration, workspace creation, sign-in, refresh persistence, logout and tenant isolation before enabling real users.

The frontend build does not run database migrations. Migrations are a deliberate release step, never a side effect of a Vercel build or an API request.

## Security notes

- Keep `.env` files out of source control and deployment artifacts.
- Never expose `DATABASE_URL`, service-role keys, session tokens or password hashes to browser code.
- Rotate credentials that were previously embedded in project files before deploying this repaired source.
- Do not execute legacy SQL bundles under `supabase/`; use only `backend/db/migrations/`.
- Do not run destructive schema reset scripts. The former unsafe reset/setup utilities have been removed.

See [`DEPLOY.md`](DEPLOY.md) and [`docs/PRODUCTION-SUPABASE-REPAIR.md`](docs/PRODUCTION-SUPABASE-REPAIR.md) for detailed deployment and verification steps.

## Existing product scope

The CRM interface, navigation, dashboards, leads, contacts, companies, deals, tasks, activities, tickets, campaigns, projects, finance, documents, workflows, integrations, reporting and mobile layouts remain in the source. The repair is limited to database lifecycle, authentication, workspace context, deployment packaging and their supporting documentation.
