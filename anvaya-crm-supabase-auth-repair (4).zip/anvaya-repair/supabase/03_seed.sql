-- ============================================================================
-- Anvaya CRM for Supabase — 03 seed
--
-- Creates one usable workspace: an organisation, the nine role templates, a
-- default pipeline with six stages, and the settings the app expects.
--
-- 1. Change the two values in the DO block below.
-- 2. Run it after 00, 01 and 02.
-- 3. It is safe to run once per workspace; it does nothing if the slug exists.
-- ============================================================================

do $$
declare
  v_email   text := 'you@yourcompany.com';   -- <-- the account that owns this workspace
  v_org     text := 'Your Company';
  v_slug    text := 'your-company';
  v_user    uuid;
  v_org_id  uuid;
  v_role    uuid;
begin
  if exists (select 1 from organisations where slug = v_slug) then
    raise notice 'Workspace % already exists — nothing to do', v_slug;
    return;
  end if;

  -- The user must already exist. On Supabase Auth, create the account first
  -- (Authentication → Users) and this finds it by email.
  select id into v_user from users where lower(email) = lower(v_email) limit 1;
  if v_user is null then
    -- Not an error: the account may not exist yet. The rest of the file is
    -- already applied; run this section again once the user is created.
    raise notice 'No user with email % yet. Create the account, then re-run section 04.', v_email;
    return;
  end if;

  insert into organisations (name, slug, currency, timezone)
  values (v_org, v_slug, 'INR', 'Asia/Kolkata')
  returning id into v_org_id;

  insert into workspaces (org_id, name, slug, is_default)
  values (v_org_id, 'Main', 'main', true);

  -- Role templates, identical to the ones the application ships with.
  insert into roles (org_id, key, name, description, permissions) values
      (v_org_id, 'owner', 'Owner', 'Full access including billing, roles and deletion', '{*}'::text[]),
      (v_org_id, 'admin', 'Org admin', 'Everything except ownership transfer and workspace deletion', '{activity.delete,activity.read,activity.write,ai.delete,ai.read,ai.write,billing.delete,billing.read,billing.write,campaign.delete,campaign.read,campaign.write,company.delete,company.read,company.write,contact.delete,contact.read,contact.write,deal.delete,deal.read,deal.write,integration.delete,integration.read,integration.write,invoice.delete,invoice.read,invoice.write,lead.delete,lead.read,lead.write,member.delete,member.read,member.write,notification.delete,notification.read,notification.write,payment.delete,payment.read,payment.write,pipeline.delete,pipeline.read,pipeline.write,product.delete,product.read,product.write,project.delete,project.read,project.write,quotation.delete,quotation.read,quotation.write,settings.delete,settings.read,settings.write,task.delete,task.read,task.write,ticket.delete,ticket.read,ticket.write,workflow.delete,workflow.read,workflow.write,workspace.delete,workspace.read,workspace.write,audit.read,report.read}'::text[]),
      (v_org_id, 'manager', 'Manager', 'Team records, approvals and every report', '{activity.delete,activity.read,activity.write,ai.read,ai.write,campaign.read,campaign.write,company.delete,company.read,company.write,contact.delete,contact.read,contact.write,deal.delete,deal.read,deal.write,invoice.read,invoice.write,lead.delete,lead.read,lead.write,member.read,notification.read,notification.write,pipeline.read,pipeline.write,product.read,project.delete,project.read,project.write,quotation.read,quotation.write,report.read,settings.read,task.delete,task.read,task.write,ticket.delete,ticket.read,ticket.write,workflow.read,workflow.write,audit.read,report.read}'::text[]),
      (v_org_id, 'sales', 'Sales representative', 'Own pipeline, contacts and quotations', '{activity.read,activity.write,ai.read,ai.write,company.read,company.write,contact.read,contact.write,deal.read,deal.write,lead.read,lead.write,member.read,notification.read,notification.write,pipeline.read,product.read,project.read,quotation.read,quotation.write,task.read,task.write,ticket.read,report.read}'::text[]),
      (v_org_id, 'support', 'Support agent', 'Tickets, customer records and knowledge base', '{activity.read,activity.write,ai.read,ai.write,company.read,contact.read,contact.write,deal.read,member.read,notification.read,notification.write,project.read,task.read,task.write,ticket.delete,ticket.read,ticket.write}'::text[]),
      (v_org_id, 'marketing', 'Marketing', 'Campaigns, segments and lead capture', '{activity.read,activity.write,ai.read,ai.write,campaign.delete,campaign.read,campaign.write,contact.read,contact.write,lead.read,lead.write,member.read,notification.read,notification.write,product.read,task.read,task.write,report.read}'::text[]),
      (v_org_id, 'finance', 'Finance', 'Quotations, invoices and payments', '{company.read,contact.read,deal.read,invoice.delete,invoice.read,invoice.write,member.read,notification.read,notification.write,payment.read,payment.write,product.read,quotation.read,quotation.write,report.read}'::text[]),
      (v_org_id, 'field', 'Field employee', 'Assigned visits, tasks and customer context', '{activity.read,activity.write,company.read,contact.read,deal.read,member.read,notification.read,notification.write,task.read,task.write,ticket.read,ticket.write}'::text[]),
      (v_org_id, 'readonly', 'Read-only', 'View and export where permitted, no writes', '{lead.read,contact.read,company.read,deal.read,pipeline.read,activity.read,task.read,ticket.read,campaign.read,product.read,quotation.read,invoice.read,payment.read,project.read,workflow.read,ai.read,settings.read,billing.read,integration.read,member.read,workspace.read,notification.read,report.read}'::text[]);

  select id into v_role from roles where org_id = v_org_id and key = 'owner';
  insert into members (org_id, user_id, role_id, status, title)
  values (v_org_id, v_user, v_role, 'active', 'Owner');

  insert into pipelines (org_id, name, is_default)
  values (v_org_id, 'Sales pipeline', true);

  insert into stages (org_id, pipeline_id, name, position, probability, is_won, is_lost)
  select v_org_id, p.id, s.name, s.position, s.probability, s.is_won, s.is_lost
    from pipelines p,
         (values ('Discovery', 1, 20, false, false),
                 ('Site survey', 2, 35, false, false),
                 ('Proposal sent', 3, 55, false, false),
                 ('Negotiation', 4, 75, false, false),
                 ('Closed won', 5, 100, true, false),
                 ('Closed lost', 6, 0, false, true)) as s(name, position, probability, is_won, is_lost)
   where p.org_id = v_org_id;

  insert into subscriptions (org_id, plan, status, seats)
  values (v_org_id, 'professional', 'active', 5)
  on conflict do nothing;

  insert into document_sequences (org_id, doc_type, prefix)
  values (v_org_id, 'quotation', 'QTN'),
         (v_org_id, 'invoice', 'INV'),
         (v_org_id, 'credit_note', 'CRN'),
         (v_org_id, 'receipt', 'RCT')
  on conflict do nothing;

  raise notice 'Workspace % created for %', v_org, v_email;
end $$;
