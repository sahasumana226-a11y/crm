# Supabase SQL files — legacy reference only

**Do not execute the SQL bundle or the numbered files in this directory for a new or repaired installation.**

The canonical production schema is maintained exclusively in `backend/db/migrations/`. Apply it through the application migration runner:

```bash
cd backend
npm ci
npm run migrate
```

This runner:
- requires an explicit `DATABASE_URL`;
- uses the shared PostgreSQL driver;
- applies only unapplied, versioned migrations;
- records each migration in `anvaya_schema_migrations`;
- wraps each migration and its ledger entry in a transaction;
- exits non-zero on any migration or schema verification failure;
- never resets the `public` schema or seeds demo users.

Files in this directory are retained for historical reference and may represent an older schema revision. They must not be mixed with `backend/db/migrations/`. Do not run `supabase/anvaya-supabase.sql`, `01_schema.sql`, `02_rls.sql`, or `03_seed.sql` against a live database alongside the canonical migration runner.

The backend uses its own scrypt password authentication and HTTP-only cookie sessions. Do not run `04_optional_supabase_auth.sql` or introduce a second Supabase Auth identity system as part of this deployment.

See `docs/PRODUCTION-SUPABASE-REPAIR.md` for Supabase and Vercel configuration.
